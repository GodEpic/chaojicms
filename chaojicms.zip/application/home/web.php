<?php
class app
{
	public $G;
	public function __construct(&$G){
		$this->G = $G;
		$this->routes = $this->G->loadclass('routes');
		$this->dbpdo = $this->G->loadclass('dbpdo');
		$this->tpl = $this->G->loadclass('tpl');
		$this->files = $this->G->loadclass('files');
		$this->search = $this->G->loadclass('search');
		$this->category = $this->G->loadclass('category');
		$this->apps = $this->G->loadclass('apps');
		$this->article = $this->G->loadclass('article');
		$this->navmenu = $this->G->loadclass('navmenu');
		$this->tags = $this->G->loadclass('tags');
		$this->users = $this->G->loadclass('users');
		$this->tpl->assign('navmenu',$this->navmenu->getAllByType('home'));
		$this->tpl->assign('HomeSkinPath',HomeSkinPath);
		$this->tpl->assign('users',$this->users->getAllWithUid());
		if($this->G->loadclass('apps')->getOneByName('kefu')){
            $this->tpl->assign('kefu','1');
        }
	}
}
?>