<?php
class app
{
	public $G;
	public function __construct(&$G){
		$this->G = $G;
		$this->routes = $this->G->loadclass('routes');
		$this->dbpdo = $this->G->loadclass('dbpdo');
		$this->tpl = $this->G->loadclass('tpl');
		$this->files = $this->G->loadclass('files');
		$this->users = $this->G->loadclass('users');
		$this->search = $this->G->loadclass('search');
		$this->category = $this->G->loadclass('category');
		$this->apps = $this->G->loadclass('apps');
		$this->article = $this->G->loadclass('article');
		$this->tags = $this->G->loadclass('tags');
	}
}
?>