<?php
/*
 * 前台搜索管理
 */
class action extends app{
	
	public function display(){
		$this->tpl->assign('ListSearch',$this->search->getAll());
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}

	private function index(){
		$this->tpl->assign("FormTitle",'文章搜索');
		$this->tpl->assign("FormAction","search-act.html");
		$this->tpl->display('search_index');
	}

	private function searchkey(){
		$key=urlencode($_POST['searchkeywords']);
		if($key){
			header("refresh:0;url=/search/$key.html");
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => "亲,请不要调戏我",
				"callbackType" =>'forward',
				"forwardUrl" =>"/search.html"
			);
			$this->G->R($message);
		}		
	}

	private function manage(){
		if($this->routes->url(2)=="search"){
			$key=$this->routes->get('key');
			$page=$this->routes->get('page');
			$page=$page>0?$page:1;
			$ListAll=$this->search->getAllArtByKey($key,$page);
			if($ListAll['data']){
				$this->tpl->assign("FormTitle",'搜索结果');
				$this->tpl->assign('key',$key);
				$this->tpl->assign('ListAll',$ListAll);
				$this->tpl->assign('SeoTitle','搜索关键词"'.$key.'"的结果 第'.$page.'页');
				$this->tpl->assign('SeoKeywords',$key);
				$this->tpl->display('search_list');
			}else{
				$message = array(
					'statusCode' =>300,
					"message" => "没有找到搜索内容",
					"callbackType" =>'forward',
					"forwardUrl" =>"/search.html"
				);
				$this->G->R($message);
			}
		}
	}
}
?>
