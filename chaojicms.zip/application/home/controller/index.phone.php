<?php
/*
 * 2017-0913
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}
	private function index(){
		$this->tpl->display('index');
	}
}
?>
