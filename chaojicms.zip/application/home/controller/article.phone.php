<?php
/*
 * 2017-09-14
 */
class action extends app
{
	public function display()
	{
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "view";
		$this->$action();
		exit;
	}
	
	private function view(){
		$IntID=$this->routes->get('id');
		$Catalog=$this->routes->get('catalog_name');
		$Scat=$this->category->getOneByCatalog($Catalog);
		if($Catalog==$Scat['catalog_name']){
			$IntID = $IntID > 0?$IntID:1;
			$artme = $this->article->getOneByID($IntID);
			$Content=$artme['content'];
            if($this->apps->getOneByName('links')){
                $SetLink=$this->search->setInLinkByContent($Content);//加载内链
                if($SetLink){
                    $artme['content']=$SetLink;
                }
            }
			$this->article->updateView($IntID);
			$this->tpl->assign('preArt',$this->article->getPreByID($IntID));//上一篇
			$this->tpl->assign('nextArt',$this->article->getNextByID($IntID));//下一篇
			$this->tpl->assign('NavCrumb',$this->article->getNavCrumbByAid($IntID));//面包屑导航
			$this->tpl->assign('RelationArt',$this->tags->getRelationArtByAid($IntID));//相关文章
			$this->tpl->assign('HotArt',$this->article->getSpecialArt($Scat['id'],7,'view desc'));//相关文章
            $this->tpl->assign('stags',$this->tags->getTagByAid($IntID));//tag标签
			$nickname=$this->users->getOneByID($artme['adduser']);
			$artme['nickname']=$nickname['nickname'];
			$this->tpl->assign('artme',$artme);
            $this->tpl->assign('MyCat',$Scat);
			$this->tpl->assign('SeoTitle',$artme['seo_title']=$artme['seo_title']!=""?$artme['seo_title']:$artme['title']);
			$this->tpl->assign('SeoKeywords',$artme['seo_keywords']=$artme['seo_keywords']!=""?$artme['seo_keywords']:$artme['seo_tags']);
            if(empty($artme['seo_description'])){
                $artme['seo_description']=substr(strip_tags(html_entity_decode($Content)),0,250);
            }
			$this->tpl->assign('SeoDescription',$artme['seo_description']);
			$this->tpl->display('article_view');
		}else{
			header("location:/404.html");
		}
	}
}
?>
