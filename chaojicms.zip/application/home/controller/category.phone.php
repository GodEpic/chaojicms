<?php
/*
 *
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "view";
		$this->$action();
		exit;
	}

	private function view(){
		$page = intval($this->routes->get('page'));
		$page = $page>0?$page:1;	
		$Catalog=$this->routes->get('catalog_name');
		$MyCat=$this->category->getOneByCatalog($Catalog);
		if($MyCat){
			$ListApps=$this->apps->getAllByData();			
			$ListArt=$this->article->getList($page,PAGED,array('cat_id'=>$MyCat['id']),'list');
			if($page>$ListArt['total']&&$page>1){
				$message = array(
					'statusCode' =>300,
					"message" => "请勿乱策",
					"callbackType" =>'forward',
					"forwardUrl" =>"list1.html"
				);
				$this->G->R($message);
			}
			$NavCrumb=$this->category->getNavCrumbByCid($MyCat['id']);
			$ListCatSun=$this->category->getSunByCid($MyCat['id']);
			$ListArtHot=$this->article->getSpecialArt($MyCat['id'],10,'view desc');
			$ListArtNew=$this->article->getSpecialArt($MyCat['id'],10,'addtime desc');
			$this->tpl->assign("ListArtNew",$ListArtNew);
			$this->tpl->assign("ListArtHot",$ListArtHot);
			$this->tpl->assign("ListApps",$ListApps);		
			$this->tpl->assign("MyCat",$MyCat);
			$this->tpl->assign("NavCrumb",$NavCrumb);
			$this->tpl->assign("Catalog",$Catalog);
			$this->tpl->assign("ListArt",$ListArt);
			$this->tpl->assign("ListCatSun",$ListCatSun);
			$SeoTitle=$MyCat['Seo_title']!=''?$MyCat['Seo_title']:$MyCat['cat_name'];
			$SeoKeywords=$MyCat['Seo_keywords']!=''?$MyCat['Seo_keywords']:$MyCat['cat_name'];
			$SeoDescription=$MyCat['Seo_description']!=''?$MyCat['Seo_description']:$MyCat['cat_name'];
			if($page>1){
				$this->tpl->assign("SeoTitle",$SeoTitle.' 第'.$page.'页');
			}else{
				$this->tpl->assign("SeoTitle",$SeoTitle);
			}
			$this->tpl->assign("SeoKeywords",$SeoKeywords);
			$this->tpl->assign("SeoDescription",$SeoDescription);
            if($MyCat['cat_skin']){
                $this->tpl->display($MyCat['cat_skin']);
            }else{
                $this->tpl->display('category_view');
            }			
		}else{
			header("location:/404.html");
		}			
	}
}
?>
