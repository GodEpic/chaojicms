<?php
/*
 * 2017-0913
 */
class action extends app{
	public function display(){
		if($this->routes->isMobile()){
			header("location:index.php?home-phone");
			exit;
		}
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}

	private function index(){
        if($this->G->loadclass('apps')->getOneByName('links')&&is_file(APP_PATH.'links/install.lock')){
            $friendlink=$this->G->loadclass('friendlink','links')->getAllLink(array('isview'=>1));
            $this->tpl->assign('friendlink',$friendlink);
        }
        $ArtList=$this->article->getAll();
        $this->tpl->assign('ArtList',$ArtList);
        $WebConfig=$this->G->loadclass('webconfig')->getWebConfig();
        $this->tpl->assign('SeoTitle',$WebConfig['website']['seo_title']);
		$this->tpl->assign('SeoKeywords',$WebConfig['website']['seo_keywords']);
		$this->tpl->assign('SeoDescription',$WebConfig['website']['seo_description']);
		$this->tpl->display('index');
	}
}
?>
