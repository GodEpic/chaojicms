<?php
/*
 *
 */
class action extends app
{
	
	public function display()
	{
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}

	private function index(){
		$ListAll=$this->tags->getAll();
		if($ListAll){
			$this->tpl->assign("FormTitle",'tags标签');
			$this->tpl->assign('SeoTitle','tags标签首页');
			$this->tpl->assign("FormAction","tags-act.html");
			$this->tpl->assign('ListAll',$ListAll);
			$this->tpl->display('tags_index');
		}
		
	}

	//ID形式
	private function tag_id(){
		$tagid=$this->routes->get('tagid');
		$ListOne=$this->tags->getTagByID($tagid);
		$ids=$ListOne['tag_article'];
		$ListAll=$this->article->getAll("FIND_IN_SET(id,'".$ids."')");
		$this->tpl->assign("FormTitle",'tags标签');
		$this->tpl->assign('SeoTitle',$ListOne['tag_label'].'-tags标签页');
		$this->tpl->assign('stag',$ListOne['tag_label']);
		$this->tpl->assign('ListAll',$ListAll);
		$this->tpl->display('tags_list');
	}

	//关键词形式
	//伪静态地址：http://www.chaojicms.com/tags/key=关键词
	private function tag_key(){
		$key=$this->routes->get('key');
		$ListOne=$this->tags->getTagByLabel($key);
		$page = $this->routes->get('page');
		$page = $page>0?$page:1;
		$ids=$ListOne['tag_article'];
		$ListAll=$this->article->getList($page,8,"FIND_IN_SET(id,'".$ids."')");
		$this->tpl->assign("FormTitle",'tags标签为【'.$ListOne['tag_label'].'】的相关文章');
		$this->tpl->assign('SeoTitle',$ListOne['tag_label'].'-tags标签页 第'.$page.'页');
		$this->tpl->assign('stag',$ListOne['tag_label']);
		$this->tpl->assign('ListAll',$ListAll);
		$this->tpl->display('tags_list');
	}
}
?>
