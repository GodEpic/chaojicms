<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
<div class="postion wxp-wrap">
    <div class="left">{Tinwin $MyCat['cat_name']}</div>
    <div class="right">
        <ul class="breadcrumb">{Tinwin $NavCrumb}</ul>
    </div>
</div>
<div class="newslist wpx">
    <div class="left">
        <dl class="NavList">
            <dt>{Tinwin $MyCat['cat_name']}</dt>
            {Tinwin if $ListCatSun}
                {Tinwin tree $ListCatSun,mylist,myid}
                <dd><a href="/{Tinwin v:mylist['catalog_name']}/">{Tinwin v:mylist['cat_name']}</a></dd>
                {Tinwin endtree}
            {Tinwin endif}
        </dl>
        <dl class="NavContact">
            <dt>联系我们</dt>
            <dd><span>地址：</span>{Tinwin $WebConfig['website']['web_address']}</dd>
            <dd><span>电话：</span>{Tinwin $WebConfig['website']['web_phone']}</dd>
            <dd><span>邮箱：</span>{Tinwin $WebConfig['website']['web_email']}</dd>
        </dl>   		 
    </div>
    <div class="right">
        {Tinwin if $ListArt['data']}
        {Tinwin tree $ListArt['data'],mylist,myid}
        <div class="list w100 fl">
            <div class="date">
               <div>{Tinwin date:v:mylist[addtime],'d'}</div>
               <div>{Tinwin date:v:mylist[addtime],'Y-m'}</div>
            </div>
            <dl>
                <dt ><a href="{Tinwin v:mylist['url']}" class=" font-14 col-black">{Tinwin v:mylist['title']}</a></dt>
                <dd>{Tinwin realsubstring:v:mylist['content'],280}<a href="{Tinwin v:mylist['url']}" class="col-black">[查看详情]</a>
                </dd>                  
            </dl> 
         </div>
        {Tinwin endtree}
        {Tinwin endif}
        <div class="w100 page"><section><ul>{Tinwin $ListArt['pages']}</ul></section></div>
        </div>
    </div>
    
</div>
{Tinwin include:footer}
