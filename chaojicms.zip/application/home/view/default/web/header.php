<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="{Tinwin c:HomeSkinPath}css/global.css">
<link rel="stylesheet" type="text/css" href="{Tinwin c:HomeSkinPath}css/list.css">
<link rel="shortcut icon" href="/favicon.ico" />
<script type="text/javascript" src="{Tinwin c:PLUGIN_PATH}jquery.js"></script>
<script src="{Tinwin c:HomeSkinPath}js/gundong.js"></script>
<script src="{Tinwin c:HomeSkinPath}js/shangla.js"></script>