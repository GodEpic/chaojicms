<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
<div class="postion wxp-wrap">
    <div class="left">{Tinwin $MyCat['cat_name']}</div>
    <div class="right">
        <ul class="breadcrumb">{Tinwin $NavCrumb}</ul>
    </div>
</div>
<div class="inform wxp">
    <div class="inform-wrap wxp-wrap">
        <div class="inform-center">
            {Tinwin tree $ListArt['data'],mylist,myid}
            <div class="content">
                <div class="left">
                    <img src="{Tinwin v:mylist['img']}" width="240" height="160">
                </div>
                <div class="right">
                    <a href="{Tinwin v:mylist['url']}" class="hd">{Tinwin v:mylist['title']}</a>    
                    <a href="{Tinwin v:mylist['url']}" class="bd">{Tinwin realsubstring:v:mylist['content'],280}</a>
                    <a href="{Tinwin v:mylist['url']}" class="ft">+查看详情</a>
                </div>
            </div>
            {Tinwin endtree}
        </div>
        <div class="page"><section><ul>{Tinwin $ListArt['pages']}</ul></section></div>
    </div>
</div>
{Tinwin include:footer}
