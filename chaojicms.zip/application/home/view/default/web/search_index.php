<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
<div class="container" style="margin-top:100px; margin-bottom:100px; positon:relative;">
	<h1 class="text-center">{Tinwin $FormTitle}</h1>
    <div class="col-xs-6 col-md-offset-3">
        <form action="{Tinwin $FormAction}" method="post">
                <input type="hidden" name="input_token" value="{Tinwin $input_token}">
          <div class="input-group col-md-12">
              <input type="text" name="searchkeywords" class="form-control" placeholder="{Tinwin $Placeholder}" required oninvalid="setCustomValidity('你要对人家负责，不然我是不会放你走的')" oninput="setCustomValidity('')"  / >
                  <span class="input-group-btn">  
                      <button class="btn btn-info btn-search">查找</button>
                  </span>  
          </div>
        </form>
    </div>
</div>
{Tinwin include:footer}
