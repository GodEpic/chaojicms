$(function() {
    //原理：通过定时器来做
    //步骤：1.累加器  2.定时器
    //计算所有li的宽度
    //li数量 *  一个li的宽度
    //alert( $('li').length );
    var allWidth = $('.one li').outerWidth(true) * $('.one li').length;
    //复制所有的li放到ul的最后
    var tag = $('.one li').clone();
    $('.roll ul').append(tag);
    var num=0;
    var timer = null;
    //把这个定时器的功能，封装到一个自定义函数中
    function autoPlay(){ 
        num-=2;
        if( num < -allWidth){
            num = 0;
        }
        $('.roll ul').css({
            'left': num
        });	
    }
    //3.开启定时器
    timer = setInterval(autoPlay,30);
    //鼠标经过的时候，清空定时器
    //鼠标经过的时候，清空定时器
    $('.roll').mouseover(function(event) {
        clearInterval(timer);
    }).mouseout(function(event) {
        clearInterval(timer);
        timer = setInterval(autoPlay,30);
    });;
});	