
	$(function() {
		$('.txt').each(function(index, el) {
			$(el).css('background','#18a4fd');
			var num = -40*index;
			$(el).css('background-position','0 '+num+'px');
		});
		//鼠标经过让盒子显示
		$('.case-wrap ul li').mouseover(function(event) {
			$(this).children('p').stop().animate({bottom:0}, 500);
		}).mouseout(function(){
			$(this).children('p').stop().animate({bottom:-40}, 500);
		});
	});
	

		$(function() {
		$('.text').each(function(index, el) {
			$(el).css('background','rgba(0,0,0,.5)');
			var num = -120*index;
			$(el).css('background-position','0 '+num+'px');
		});
		//鼠标经过让盒子显示
		$('.case-wrap ul li').mouseover(function(event) {
			$(this).children('del').stop().animate({top:0}, 500);
		}).mouseout(function(){
			$(this).children('del').stop().animate({top:-120}, 500);
		});
	});