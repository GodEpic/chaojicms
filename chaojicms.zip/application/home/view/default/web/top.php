<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
<!DOCTYPE html>
<html>
<head>
{Tinwin include:header}
<title>{Tinwin if $SeoTitle==""}{Tinwin $WebConfig['website']['seo_title']}{Tinwin else}{Tinwin $SeoTitle}{Tinwin endif}</title>
<meta name="keywords" content="{Tinwin if $SeoKeywords==""}{Tinwin $WebConfig['website']['seo_keywords']}{Tinwin else}{Tinwin $SeoKeywords}{Tinwin endif}" />
<meta name="description" content="{Tinwin if $SeoDescription==""}{Tinwin $WebConfig['website']['seo_description']}{Tinwin else}{Tinwin $SeoDescription}{Tinwin endif}" />
</head>
<body>
<header class="header wxp">
    <div class="header-wrap wxp-wrap">
        <div class="left">
            <a href="{Tinwin $WebConfig['website']['web_url']}" class="logo">
                <img src="{Tinwin if $WebConfig['website']['web_logo']}{Tinwin $WebConfig['website']['web_logo']}{Tinwin else}{Tinwin c:STATIC_PATH}images/logo.png{Tinwin endif}">
            </a>
        </div>
        <div class="nav right">
            <ul>
                <li class="current"><a href="/">首页</a></li>
                <li><a href="{Tinwin $WebConfig['website']['web_url']}service/">我们的服务</a></li>
                <li><a href="{Tinwin $WebConfig['website']['web_url']}case/">成功案例</a></li>
                <li><a href="{Tinwin $WebConfig['website']['web_url']}news/">新闻中心</a></li>
                <li><a href="{Tinwin $WebConfig['website']['web_url']}about/">关于我们</a></li>
                <li><a href="{Tinwin $WebConfig['website']['web_url']}contactus/">联系我们</a></li>
            </ul>
        </div>
    </div>
</header>
<section>
    <div class="picture wxp">
        <div class="picture-wrap wxp-wrap"></div>
    </div>
</section>