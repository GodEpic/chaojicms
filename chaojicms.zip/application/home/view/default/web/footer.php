<footer class="footer wxp">
    <div class="footer-wrap wxp-wrap">
        <div class="footer-hd">
            <div class="left">
                <dl>
                    <dt>我们的服务</dt>
                    <dd>网站优化</dd>
                    <dd>网站建设</dd>
                    <dd>微信营销</dd>
                    <dd>系统开发</dd>
                </dl>
                <dl>
                    <dt>成功案例</dt>
                    <dd>解决文案</dd>
                    <dd>经典案例</dd>
                </dl>
                <dl>
                    <dt>新闻中心</dt>
                    <dd>公司新闻</dd>
                    <dd>行业新闻</dd>
                </dl>
                <dl>
                    <dt>关于我们</dt>
                    <dd>企业文化</dd>
                    <dd>经营理念</dd>                   
                    <dd>发展历程</dd>
                    <dd>团队活动</dd>
                </dl>
            </div>
            <div class="right">
                <ul>
                    <li class="font-14">联系我们</li>
                    <li class="number">{Tinwin $WebConfig['website']['web_phone']}</li>
                    <li class="Arial font-14">{Tinwin $WebConfig['website']['web_email']}</li>
                </ul>
                <i></i>
            </div>
        </div>
        <div class="footer-ft">
            <p>{Tinwin $WebConfig['website']['web_copyright']} {Tinwin $WebConfig['website']['web_icp']}{Tinwin c:PoweredBy}</p>
        </div>
    </div>
</footer>
{Tinwin $WebConfig['website']['web_tongji']}
{Tinwin if $kefu}
<div id="kefu"></div>
<script type="text/javascript">
$(document).ready(function(){
    $("#kefu").load("/index.php?kefu-web-index");
});
</script>
{Tinwin endif}
</body>
</html>