<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
<script>
$(function(){
    $('.show').each(function(index, el) {
        $(el).css('background','rgba(0,0,0,.5)');
        var num = -150*index;
        $(el).css('background-position','0 '+num+'px');
    });
    //鼠标经过让盒子显示
    $('.right .list').mouseover(function(event) {
        $(this).children('dl').stop().animate({bottom:0},300);
    }).mouseout(function(){
        $(this).children('dl').stop().animate({bottom:-150},300);
    });
});
</script>
<div class="postion wxp-wrap">
        <div class="left">{Tinwin $MyCat['cat_name']}</div>
        <div class="right">
            <ul class="breadcrumb">{Tinwin $NavCrumb}<li>{Tinwin $artme['title']}</li></ul>
        </div>
    </div>
<div class="service w100">
    <div class="wpx">
        <div class="left">
            <dl class="NavList">
                <dt>下级栏目</dt>
                {Tinwin if $ListCatSun}
                    {Tinwin tree $ListCatSun,mylist,myid}
                    <dd><a href="/{Tinwin v:mylist['catalog_name']}/">{Tinwin v:mylist['cat_name']}</a></dd>
                    {Tinwin endtree}
                {Tinwin endif}
            </dl>
            <dl class="NavContact">
                <dt>联系我们</dt>
                <dd><span>地址：</span>{Tinwin $WebConfig['website']['web_address']}</dd>
                <dd><span>电话：</span>{Tinwin $WebConfig['website']['web_phone']}</dd>
                <dd><span>邮箱：</span>{Tinwin $WebConfig['website']['web_email']}</dd>
            </dl>
        </div>
        <div class="right">
            {Tinwin if $ListArt['data']}
            {Tinwin tree $ListArt['data'],mylist,myid}
                <div class="list">
                    <img src="{Tinwin if v:mylist['img']}{Tinwin v:mylist['img']}{Tinwin else}{Tinwin c:STATIC_PATH}images/default.png{Tinwin endif}" width="300" height="190">
                    <dl>
                        <dt><a href="{Tinwin v:mylist['url']}">{Tinwin v:mylist['title']}</a></dt>
                        <dd><a href="{Tinwin v:mylist['url']}">{Tinwin realsubstring:v:mylist['content'],280}</a></dd>
                    </dl>
                </div>
            {Tinwin endtree}
            {Tinwin endif}
            <div class="w100 page"><section><ul>{Tinwin $ListArt['pages']}</ul></section></div>
        </div>

    </div>

</div>
{Tinwin include:footer}
