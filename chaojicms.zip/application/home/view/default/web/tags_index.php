<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
<div class="container">
	<h1 class="text-center">{Tinwin $FormTitle}</h1>
    <div>
		{Tinwin tree $ListAll,mylist,myid}
			<a href="/tags/{Tinwin v:mylist['tag_label']}.html">{Tinwin v:mylist['tag_label']}</a>
		{Tinwin endtree}
	</div>
</div>
{Tinwin include:footer}
