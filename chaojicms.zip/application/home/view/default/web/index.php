<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
<!DOCTYPE html>
<html>
<head>
{Tinwin include:header}
<link rel="stylesheet" type="text/css" href="{Tinwin c:HomeSkinPath}css/index.css">
<title>{Tinwin if $SeoTitle==""}{Tinwin $WebConfig['website']['seo_title']}{Tinwin else}{Tinwin $SeoTitle}{Tinwin endif}</title>
<meta name="keywords" content="{Tinwin if $SeoKeywords==""}{Tinwin $WebConfig['website']['seo_keywords']}{Tinwin else}{Tinwin $SeoKeywords}{Tinwin endif}" />
<meta name="description" content="{Tinwin if $SeoDescription==""}{Tinwin $WebConfig['website']['seo_description']}{Tinwin else}{Tinwin $SeoDescription}{Tinwin endif}" />
<script src="{Tinwin c:HomeSkinPath}js/flash.js"></script>
</head>
<body>
<header class="header wxp">
    <div class="header-wrap wxp-wrap">
        <div class="left">
            <a href="{Tinwin $WebConfig['website']['web_url']}/" class="logo">
                <img src="{Tinwin if $WebConfig['website']['web_logo']}{Tinwin $WebConfig['website']['web_logo']}{Tinwin else}{Tinwin c:HomeSkinPath}images/logo.png{Tinwin endif}">
            </a>
        </div>
        <div class="nav right">
            <ul>
                <li class="current"><a href="/">首页</a></li>
                <li><a href="/service/">我们的服务</a></li>
                <li><a href="/case/">成功案例</a></li>
                <li><a href="/news/">新闻中心</a></li>
                <li><a href="/about/">关于我们</a></li>
                <li><a href="/contactus/">联系我们</a></li>
            </ul>
        </div>
    </div>
</header>
<!--section-start-->
<div class="wxp slide-main" id="touchMain">
	<a class="prev" href="javascript:;" stat="prev1001"><img src="{Tinwin c:HomeSkinPath}images/l-btn.png" /></a>
	<div class="slide-box">
        {TinJdt mylist,3,inrow,myid}
		<div class="slide">
			<a stat="sslink-{Tinwin v:myid}" href="{Tinwin v:mylist['linkurl']}" target="_blank"><img src="{Tinwin v:mylist['img']}"></a>
		</div>
        {WinJdt}
	</div>
	<a class="next" href="javascript:;" stat="next1002"><img src="{Tinwin c:HomeSkinPath}images/r-btn.png" /></a>
	<div class="item">
        {TinJdt mylist,3,inrow,myid}
		<a href="javascript:;" stat="item100{Tinwin v:myid}" class="cur"></a>
        {WinJdt}
	</div>
</div>
   <!-- my services-start-->
	<div class="service wxp">
    	<div class="service-wrap wxp-wrap">
        	<div class="service-top">
                <dl class="homeTitle">
                    <dt>————— <span>服务项目</span> —————</dt>
                    <dd>my services</dd>
                </dl>
            </div>
            <div class="service-bottom">
                <div class="left">
                    <a href="#">
                        <dl class="icon-1">
                            <dt>网站排名优化</dt>
                            <dd>12年网站优化经验，根据企业所在行业分析最适合企业优化的关键词</dd>		
                        </dl>
                    </a>
                </div>
                <div class="left">
                	<a href="#">
                        <dl class="icon-2">
                            <dt>高端定制开发</dt>
                            <dd>10年建站经验，根据企业实际情况定制专属（品牌）官网并适用各种终端设备。</dd>		
                        </dl>
                    </a>
                </div>
                <div class="left">
                	<a href="#">
                        <dl class="icon-3">
                            <dt>线上整合营销</dt>
                            <dd>整合SEO架构，适用于网络营销，专业为企业SEO打造营销型网站</dd>
                        </dl>
                    </a>
                </div>
            </div>
        </div>
        <a href="/service/" class="btn">+MORE</a>
    </div>
     <!--sucessfur case-start-->
    <div class="case wxp">
    	<div class="case-wrap wxp-wrap" >
        	<div class="case-top">
                <dl class="homeTitle">
                    <dt>————— <span>成功案例</span> —————</dt>
                    <dd>SUCESSFUL CASE</dd>
                </dl>
            </div>
            <ul>
                {Tinwin if $ArtList}
                {Tinwin artlist $ArtList,mylist,2,8}
            	<li>
                	<a href="#"><img src="{Tinwin c:HomeSkinPath}images/homecase.png" width="268" height="160"></a>
                    <p></p>
                    <p class="txt" >{Tinwin v:mylist['title']}</p>
                    <del class="text">成功案例成功案例成功案例成功案例成功案例成功案例成功案例成功案例成功案例成功案例成功案例成功案例成功案例成功案例成功案例<a href="#">[详细]</a></del>
                </li>
                {Tinwin endart}
                {Tinwin endif}
            </ul>
        </div>
        <a href="/case/" class="btn">+MORE</a>
    </div> 
    <!--news-start-->
    <div class="news wxp">
    	<div class="news-wrap wxp-wrap">
        	<div class="news-top">
                <dl class="homeTitle">
                    <dt>————— <span>新闻中心</span> —————</dt>
                    <dd>NEWS CENTER</dd>
                </dl>
            </div>
            <div class="news-center">
                <a href="#" class="btn-1">公司新闻</a>
                <a href="#" class="btn-2">行业动态</a>
            </div>
            <div class="news-bottom">
            	<div class="left">
                	<p class="pic"><img src="{Tinwin c:HomeSkinPath}images/homenews.jpg" width="550" height="300"></p>
                    <a href="#">月入万元的SEO项目盈利操作</a>
                    <p class="font-14">我们想要通过SEO技术赚钱。其实，掌握一门技术是次要方面，学会把技术变现才是重中之重，所以你说学习SEO重要吗?挺重要，但绝不是最重要的。学SEO会赚钱才是最重要的。那么都有哪些SEO暴利项目呢？我们来一一讲解</p>
                </div>
                <div class="right">
                	<ul>
                        {Tinwin if $ArtList}
                        {Tinwin artlist $ArtList,mylist,1,4}
                    	<li>
                            <div class="left">
                            	<strong>14</strong>
                                <del class="font-14">2018-05</del>
                            </div>
                            <div class="right">
                            	<a href="#" class="font-18">{Tinwin v:mylist['title']}</a>
                                <p class="font-14">要想百度给你网站排名，只有三种理由，第一你给百度钱了，第二你是百度旗下的公司或产品，第三你提供有价值的内容，提高了百度搜索...</p>
                            </div>
                        </li>
                        {Tinwin endart}
                        {Tinwin endif}
                    </ul>
                </div>
                
            </div>
           
        </div>
         <a class="btn" href="/news/">+MORE</a>
    </div>
   <!-- about us-start-->
    <div class="home_about">
        <div class="wpx">
            <div class="home_about_top">
                <dl class="homeTitle">
                    <dt>————— <span>关于我们</span> —————</dt>
                    <dd>ABOUT US</dd>
                </dl>
            </div>
            <div class="home_about_center">
               <div class="aboutfont">
    超级CMS系统（以下简称产品）由SEO研究中心为了解决网站优化问题而研发的一套产品，本产品采用面向对象方式自助研发的MVC框架开发，它是一款高效开源的内容管理系统，产品基于PHP+MYSQL架构，可运行在Windows、Linux、MacOSX、Solaris等各种平台上。本产品完全采用MVC框架式开发，增加了程序的维护性、可扩展性，并采用模块化开发设计，使二次开发变得简单、容易，系统设计的模板标签，让前端人员可独立完成模板制作及数据调用，后台管理员可自定义模型功能，不会编程就实现各种信息发布和检索。本产品源码简洁、严谨、安全、高效、源码100%开源，作者用心优化每一行代码、减少冗余，在保持高效、强大的功能上，同时尽可能减少整体的容量。
                </div>
                <div class="roll">              
                     <ul class="one">
                          <li>
                            <a href="#"><img src="{Tinwin c:HomeSkinPath}images/about/huodong1.jpg"></a>
                          </li>
                          <li>
                            <a href="#"><img src="{Tinwin c:HomeSkinPath}images/about/huodong2.jpg"></a>
                          </li>
                          <li>
                            <a href="#"><img src="{Tinwin c:HomeSkinPath}images/about/huodong3.jpg"></a>
                          </li>
                          <li>
                            <a href="#"><img src="{Tinwin c:HomeSkinPath}images/about/huodong4.jpg"></a>
                          </li>
                         <li>
                            <a href="#"><img src="{Tinwin c:HomeSkinPath}images/about/huodong5.jpg"></a>
                          </li>
                         <li>
                            <a href="#"><img src="{Tinwin c:HomeSkinPath}images/about/huodong6.jpg"></a>
                          </li>
                      </ul>
                </div>
            </div>
       </div> 
       <a href="/about/" class="btn">+MORE</a>
   </div>
{Tinwin if $friendlink}
    <div class="container-fluid">
		<div class="col-xs-12">
        <div class="title">友情链接</div>
        <ul>
        {Tinwin tree $friendlink,mylist,myid}
            <li class="fl" style="margin-right:1rem;"><a href="{Tinwin v:mylist['link_url']}">{Tinwin v:mylist['link_title']}</a></li>
        {Tinwin endtree}
        </ul>
		</div>
    </div>
{Tinwin endif}
{Tinwin include:footer}
