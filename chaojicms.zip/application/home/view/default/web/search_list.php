<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
<h2 class="text-center">{Tinwin $FormTitle}</h2>
<div class="container-fluid">
	<div class="title" style="margin-bottom:20px;">您搜索的关键词 {Tinwin $key}</div>
	<table class="table">
		<thead>
			<tr>
				<td>文章标题</td>
			</tr>
		</thead>
		<tbody>
		{Tinwin tree $ListAll['data'],myList,cid}
		<tr>
			<td><a target="_blank" href="/{Tinwin v:myList['catalog_name']}/{Tinwin v:myList['id']}.html">{Tinwin v:myList['title']}</a></td>
		</tr>
		{Tinwin endtree}
	</tbody>
	</table>
	<div class="page">
  <section><ul>{Tinwin $pager}</ul></section></div>
</div>
{Tinwin include:footer}
