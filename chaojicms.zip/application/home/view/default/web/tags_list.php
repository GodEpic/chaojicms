<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
<h2 class="text-center">{Tinwin $FormTitle}</h2>
<div class="newslist wpx">
	<div class="title" style="margin-bottom:20px;">您搜索的tags {Tinwin $stag}</div>
    {Tinwin if $ListAll['data']}
    <div class="right">
        {Tinwin tree $ListAll['data'],mylist,myid}
        <div class="list w100 fl">
            <div class="date">
               <div>{Tinwin date:v:mylist[addtime],'d'}</div>
               <div>{Tinwin date:v:mylist[addtime],'Y-m'}</div>
            </div>
            <dl>
                <dt ><a href="{Tinwin v:mylist['url']}" class=" font-14 col-black">{Tinwin v:mylist['title']}</a></dt>
                <dd>{Tinwin realsubstring:v:mylist['content'],280}<a href="{Tinwin v:mylist['url']}" class="col-black">[查看详情]</a>
                </dd>                  
            </dl> 
         </div>
        {Tinwin endtree}      
    </div>
    <div class="wpx page"><section><ul>{Tinwin $ListAll['pages']}</ul></section></div>
    {Tinwin else}
		没有找到相关TAG标签文章
    {Tinwin endif}
</div>
{Tinwin include:footer}
