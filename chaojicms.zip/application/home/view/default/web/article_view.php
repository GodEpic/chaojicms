<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
<div class="postion wxp-wrap">
    <div class="left">{Tinwin $MyCat['cat_name']}</div>
    <div class="right">
        <ul class="breadcrumb">{Tinwin $NavCrumb}<a href="{Tinwin $artme['url']}">{Tinwin $artme['title']}</a></ul>
    </div>
</div>
<div class="article wpx">
    <div class="left">
        <div class="top">
            <h3 class="tac">{Tinwin $artme['title']}</h3>
            <ul>
                <li>来源：<a href="{Tinwin $artme['out_url']}">{Tinwin $artme['out_from']}</a></li>
                <li>作者：{Tinwin if $artme['out_from']}{Tinwin $artme['out_from']}{Tinwin else}{Tinwin $artme['nickname']}{Tinwin endif}</li>
                <li>发布时间：{Tinwin date:$artme['addtime'],'Y-m-d'}</li>
                <li>浏览次数：{Tinwin $artme['view']}</li>
            </ul>
        </div>
        <div class="content">
            {Tinwin $artme['content']}              
        </div>
        <div class="prenext">
            <ul>
                <li>上一篇：{Tinwin $preArt}</li>
                <li>下一篇：{Tinwin $nextArt}</li>
            </ul>
        </div>
    </div>
    <div class="right">
        {Tinwin if $RelationArt}
        <dl class="NavDL">
            <dt class="title">相关文章推荐</dt>
            {Tinwin tree $RelationArt,mylist,myid}
                <dd><a href="{Tinwin v:mylist['url']}">{Tinwin realsubstring:v:mylist['title'],30}</a></dd>
            {Tinwin endtree}
        </dl>
        {Tinwin endif}
    </div>
</div>
{Tinwin include:footer}
