<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
<script>
	$(function() {
		//原理：通过定时器来做
		//步骤：1.累加器  2.定时器
		//计算所有li的宽度
		//li数量 *  一个li的宽度
		//alert( $('li').length );
		var allWidth = $('.one li').outerWidth(true) * $('.one li').length;
		//复制所有的li放到ul的最后
		var tag = $('.one li').clone();
		$('.about-bottom ul').append(tag);

		var num=0;
		var timer = null;
		//把这个定时器的功能，封装到一个自定义函数中
		function autoPlay(){ 
			num-=2;
			if( num < -allWidth){
				num = 0;
			}
			$('.about-bottom ul').css({
				'left': num
			});	
		}
		
		//3.开启定时器
		timer = setInterval(autoPlay,30);
		//鼠标经过的时候，清空定时器
		//鼠标经过的时候，清空定时器
		$('.about-bottom').mouseover(function(event) {
			clearInterval(timer);
		}).mouseout(function(event) {
			clearInterval(timer);
			timer = setInterval(autoPlay,30);
		});;
	});	
</script>
<div class="postion wxp-wrap">
    <div class="left">{Tinwin $MyCat['cat_name']}</div>
    <div class="right">
        <ul class="breadcrumb">{Tinwin $NavCrumb}</ul>
    </div>
</div>
<div class="about wxp">
    	<div class="about-wrap wxp-wrap">
            <div class="about-center" >
            	<h3>公司简介</h3>
                <div class="intro">
                	<div class="left"></div>
                    <div class="right">	
                        <p>超级CMS系统（以下简称产品）由SEO研究中心为了解决网站优化问题而研发的一套产品，本产品采用面向对象方式自助研发的MVC框架开发，它是一款高效开源的内容管理系统，产品基于PHP+MYSQL架构，可运行在Windows、Linux、MacOSX、Solaris等各种平台上。</p>
                        <p>本产品完全采用MVC框架式开发，增加了程序的维护性、可扩展性，并采用模块化开发设计，使二次开发变得简单、容易，系统设计的模板标签，让前端人员可独立完成模板制作及数据调用，后台管理员可自定义模型功能，不会编程就实现各种信息发布和检索。</p>
                        <p>本产品源码简洁、严谨、安全、高效、源码100%开源，作者用心优化每一行代码、减少冗余，在保持高效、强大的功能上，同时尽可能减少整体的容量。 
			介这是某某。</p>
</div>
                </div>
            </div>
          <div class="about-bottom">
           	<h3>团队风采</h3>
              <ul class="one">
               	  <li><img src="{Tinwin c:HomeSkinPath}images/about/huodong1.jpg"></li>
                  <li><img src="{Tinwin c:HomeSkinPath}images/about/huodong2.jpg"></li>
                  <li><img src="{Tinwin c:HomeSkinPath}images/about/huodong3.jpg"></li>
                  <li><img src="{Tinwin c:HomeSkinPath}images/about/huodong4.jpg"></li>
                  <li><img src="{Tinwin c:HomeSkinPath}images/about/huodong5.jpg"></li>
                  <li><img src="{Tinwin c:HomeSkinPath}images/about/huodong6.jpg"></li>
              </ul>
         </div>
      </div>
    </div>
{Tinwin include:footer}
