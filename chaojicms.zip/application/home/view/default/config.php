<?php
!defined('IN_DSW') && exit('大神你要飞呀');
return array(
    'label'   => '默认模板',
    'name' => 'default',
    'version' => '1.0',
    'type' => 'default',
    'description' => '默认模板',
    'ui_author' => '君九',
    'html_author' => '汐痕',
    'skin_author'=>'牛哥',
    'image'=>'img.png',
    'url'=>'http://www.chaojicms.com',
);
?>