<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
<!doctype html>
<html>  
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, maximum-scale=1.0, initial-scale=1.0, user-scalable=no">
<link rel="stylesheet" type="text/css" href="/plugin/bootstrap/bootstrap.css">
<script type="text/javascript" src="/plugin/jquery.js"></script>
<script type="text/javascript" src="/plugin/bootstrap/bootstrap.js"></script>

<script type="text/javascript">
    $(document).ready(function(){
        $('#DswMessage').modal('show');
    });
</script>
<style>
    #DswMessage{ width:600px;position:absolute;top:44%;left:50%;margin:-100px 0 0 -300px;padding:1px;line-height:30px;text-align:center;font-size:16px;}
    #myModalLabel{text-align: left;}
    #myText{color:red; font-weight:bold;margin:0 5px;}
    a{color:red;}
</style>
<?php if($message['WaitTime']>0){?>
    <script type="text/javascript">
        var timer = <?php echo $message['WaitTime'];?>;
        //var locationUrl="/";
        function send(){
        if(timer == 0){
            window.location.href = "<?php echo $message['forwardUrl'];?>";
        }else{
            timer--;
            console.log(timer);
            document.getElementById("myText").innerHTML = timer;
            setTimeout("send()",1000);
            }
        }
        window.onload = function () {
            send();
        }
    </script>
<?php }?>
</head>
<body>
<div class="modal fade" id="DswMessage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">超级CMS系统提示</h4>
            </div>
            <div class="modal-body">
                <h4><?php echo $message['message'];?></h4>
                <?php if(!$stop){?>
                    <p>本页面将在<span id="myText"></span>秒后跳转</p>
                <?php }else{?>
                    <p><a href="javascript:history.back(-1)" title="点击返回上一页">点击返回上一页</a></p>
                <?php }?>
            </div>
            <div class="modal-footer">
                <?php if($message['forwardUrl']=='goback'){?>
                    <a class="btn btn-default" href="javascript:history.back(-1)" title="点击返回上一页">返回上一页</a>
                <?php }else{?>
                    <a class="btn btn-default" href="javascript:history.back(-1)" title="点击返回上一页">返回上一页</a>
                    <a class="btn btn-primary" href="<?php echo $message['forwardUrl'];?>">立即跳转</a>
                <?php }?>
            </div>
        </div>
    </div>
</div>
</body>
</html>