<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
            <li>/</li>
            <li><a href="{Tinwin c:MyAppUrl}navmenu">{Tinwin $Lang['form']['MenuManage']}</li>
            <li>/</li>
            <li><a href="{Tinwin c:MyAppUrl}navmenu-group">{Tinwin $Lang['nav']['GroupManage']}</li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
        {Tinwin include:navmenu_nav}
    </div>    
	<div class="maininfo">
		<table class="table">
			<thead>
				<tr>
					<td>{Tinwin $Lang['table']['Inrow']}</td>
					<td>ID</td>
					<td>{Tinwin $Lang['table']['GroupLabel']}</td>
					<td>{Tinwin $Lang['table']['GroupName']}</td>
					<td>{Tinwin $Lang['table']['IsSystem']}</td>
					<td colspan="2">{Tinwin $Lang['table']['Operation']}</td>
				</tr>
			</thead>
			<tbody>
			{Tinwin tree $ListAll,myList,cid}
			<tr>
				<td>{Tinwin v:myList['inrow']}</td>
				<td>{Tinwin v:myList['id']}</td>
				<td><a href="{Tinwin c:MyAppUrl}navmenu-groupone&group={Tinwin v:myList['group_name']}">{Tinwin v:myList['group_label']}</a></td>
				<td><a href="{Tinwin c:MyAppUrl}navmenu-groupone&group={Tinwin v:myList['group_name']}">{Tinwin v:myList['group_name']}</a></td>
				<td onClick="DisplayOK(this)" id="{Tinwin c:ADMIN_URL}navmenu-issys&id={Tinwin v:myList['id']}" style="cursor:pointer;">
					{Tinwin if v:myList['issys']==1}		
						<span class="glyphicon glyphicon-ok-circle"></span>
					{Tinwin else}
						<span class="glyphicon glyphicon-remove-circle"></span>
					{Tinwin endif}
				</td>
				<td><a class="glyphicon glyphicon-edit" href="{Tinwin c:ADMIN_URL}navmenu-editgroup&id={Tinwin v:myList['id']}"></a></td>
				<td><a class="glyphicon glyphicon-remove" href="#" onclick='dswfirm("{Tinwin c:ADMIN_URL}navmenu-delgroup&id={Tinwin v:myList['id']}","{Tinwin $Lang['table']['DelGroupTips']}")'></a></td>
			</tr>
			{Tinwin endtree}
			<tr>
		</tbody>
		</table>
		<div class="page"><section><ul>{Tinwin $pages}</ul></section></div>
</div>
{Tinwin include:footer}
