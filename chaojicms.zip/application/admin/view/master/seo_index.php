<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['website']['adminhome']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
	</div>   
	<div class="maininfo">
		{Tinwin $Lang['index']['Message']}
	</div>
</div>
{Tinwin include:footer}