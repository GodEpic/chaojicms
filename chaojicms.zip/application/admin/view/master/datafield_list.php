<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li><a href="{Tinwin c:ADMIN_URL}data-index">{Tinwin $Lang['common']['DataOperation']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
	</div>
	<div class="mainform">
		<table class="table">
			<thead>
				<tr>
					<td>{Tinwin $Lang['table']['FieldName']}</td>
					<td>{Tinwin $Lang['table']['FidldLabel']}</td>
					<td>{Tinwin $Lang['table']['FieldType']}</td>
					<td>{Tinwin $Lang['table']['FieldDefault']}</td>
					<!--td>编辑</td>
					<td>删除</td-->
				</tr>
			</thead>
			<tbody>
				{Tinwin if $ListAll}
				{Tinwin tree $ListAll,myList,cid}
				<tr>
					<td>{Tinwin v:myList['Field']}</td>
					<td>{Tinwin v:myList['Comment']}</td>
					<td>{Tinwin v:myList['Type']}</td>
					<td>{Tinwin v:myList['Default']}</td>
					<!--td><a href="{Tinwin c:MyAppUrl}datafield-edit&cid={Tinwin $Stable}&id={Tinwin v:myList['Field']}">编辑</a></td>
					<td>
						{Tinwin if v:myList['isdel']==0}			
						<a href="#" onclick='firm("{Tinwin c:MyAppUrl}datafield-del&cid={Tinwin $Stable}&id={Tinwin v:myList['Field']}")'>删除</a>
						{Tinwin endif}
					</td-->
				</tr>
				{Tinwin endtree}
				{Tinwin endif}
			</tbody>
		</table>
	</div>
{Tinwin include:footer}
