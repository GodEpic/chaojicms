<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li><a href="{Tinwin c:MyAppUrl}tags">{Tinwin $Lang['index']['FormTitle']}</li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
        {Tinwin include:category_nav}
    </div>    
	<div class="maininfo">
		<form action="{Tinwin $FormAction}" method="post" class="container-fluid">
			<input type="hidden" name="input_token" value="{Tinwin $input_token}">
			<div class="form-group row" style="padding-top:20px;">
				<label for="inrow" class="col-sm-2 control-label text-right">{Tinwin $Lang['form']['tag_label']}</label>
				<div class="col-sm-6">
					<input type="text" class="form-control" name="tag_label" placeholder="{Tinwin $Lang['form']['tag_labelTips']}" required value="{Tinwin $ListOne['tag_label']}">
				</div>
			</div>
			<div class="form-group row">
				<label for="psd2" class="col-sm-2 control-label"></label>
				<div class="col-sm-6">
					<button type="submit" class="btn btn-default">{Tinwin $Lang['form']['Save']}</button>
				</div>
			</div>
		</form>
	</div>
</div>
{Tinwin include:footer}
