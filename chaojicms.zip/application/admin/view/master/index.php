<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main" id="loadajax">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
		</ul>
	</div>
	<div class="mainform">
		<ul>
		{Tinwin if $Notice}
			{Tinwin tree $Notice,mylist,myid}
				<li>{Tinwin v:mylist['admin']}</li>
				<li>{Tinwin v:mylist['admindir']}</li>
			{Tinwin endtree}
		{Tinwin endif}
			<li id="checkupdate" ></li>
			<li>{Tinwin $Lang['website']['Version']}:{Tinwin c:SoftVersion}</li>
		</ul>	
	</div>
	<div class="maininfo">
		<div></div>
	</div>
</div>
<script type="text/javascript">
$(document).ready(function(){
	$('#checkupdate').load("{Tinwin c:ADMIN_URL}update-checkversion");
});
</script>
	
{Tinwin include:footer}
