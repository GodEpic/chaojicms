<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
        {Tinwin include:category_nav}
    </div>    
	<div class="maininfo">
		<form action="{Tinwin $FormAction}" method="post">
		<div class="title" style="margin-bottom:20px;">{Tinwin $Lang['searchkey']['SearchTips']} {Tinwin $key}</div>
		<table class="table">
			<thead>
				<tr>
					<td>{Tinwin $Lang['searchkey']['Select']}</td>
					<td>ID</td>
					<td>{Tinwin $Lang['searchkey']['ArticleTitle']}</td>
					<td colspan="2">{Tinwin $Lang['searchkey']['Operation']}</td>
				</tr>
			</thead>
			<tbody>
				{Tinwin if $ListAll['data']}
			{Tinwin tree $ListAll['data'],myList,cid}
			<tr>
				<td><input type="checkbox" name="SelectCheckbox[]" value="{Tinwin v:myList['id']}"></td>
				<td>{Tinwin v:myList['id']}</td>
				<td><a target="_blank" href="{Tinwin v:myList['url']}">{Tinwin v:myList['title']}</a></td>
				<td><a class="glyphicon glyphicon-edit" href="{Tinwin c:ADMIN_URL}article-edit&cid={Tinwin v:myList['cat_id']}&id={Tinwin v:myList['id']}"></a></td>
				<td><a class="glyphicon glyphicon-remove" href="#" onclick='dswfirm("{Tinwin c:ADMIN_URL}article-del&id={Tinwin v:myList['id']}","{Tinwin $Lang['searchkey']['DelTips']}")'></a></td>
			</tr>
			{Tinwin endtree}
			{Tinwin endif}
			<tr>
		</tbody>
		</table>
		<div>
			<a onClick="choiceAll(this)" style="cursor:pointer;" class="btn btn-default">{Tinwin $Lang['searchkey']['ChoiceAll']}</a> 
			<a style="cursor:pointer;" onClick="unSelect(this)" class="btn btn-default">{Tinwin $Lang['searchkey']['UnSelect']}</a> 
			<a style="cursor:pointer;" onClick="choiceReverse(this)" class="btn btn-default">{Tinwin $Lang['searchkey']['ChoiceReverse']}</a>
			<button type="submit" class="btn btn-primary">{Tinwin $Lang['searchkey']['Submit']}</button>
		</div>
		<div class="page"><section><ul>{Tinwin $ListAll['pages']}</ul></section></div>
		</form>
	</div>
</div>
{Tinwin include:footer}
