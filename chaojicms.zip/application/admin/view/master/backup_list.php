<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
	</div>
	<div class="mainform">
		<table class="table">
			<thead>
				<tr>
					<td>{Tinwin $Lang['backuplist']['BackupTime']}</td>
					<td>{Tinwin $Lang['backuplist']['Recover']}</td>
					<td>{Tinwin $Lang['backuplist']['Del']}</td>
				</tr>
			</thead>
			<tbody>
				{Tinwin if $ListAll}
					{Tinwin tree $ListAll,myList,cid}
					<tr>
						<td>{Tinwin date:v:myList['modify'],'Y-m-d H:i:s'}</td>
						<td><a href="#" onclick='dswfirm("{Tinwin c:MyAppUrl}data-recoverdata&sfile={Tinwin v:myList['name']}","{Tinwin $Lang['backuplist']['RecoverTips']}")'>{Tinwin $Lang['backuplist']['Recover']}</a></td>
						<td><a class="glyphicon glyphicon-remove" href="#" onclick='dswfirm("{Tinwin c:MyAppUrl}data-del&sfile={Tinwin v:myList['name']}","{Tinwin $Lang['backuplist']['DelTips']}")'></a></td>
					</tr>
					{Tinwin endtree}
				{Tinwin endif}
			</tbody>
		</table>
	</div>
</div>
{Tinwin include:footer}