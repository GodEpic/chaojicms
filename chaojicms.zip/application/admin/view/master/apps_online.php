<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
	</div>
	<div class="mainform">
		{Tinwin include:apps_nav}
    </div> 
	<div class="maininfo">
		{Tinwin if $AppOnline}
            {Tinwin tree $AppOnline,mylist,myid}
            <div class="col-sm-6" style="margin-bottom: 20px;">
				<div class="media applist">
					<div class="media-left">
						<img class="media-object" src="{Tinwin v:mylist['mypath']}{Tinwin v:mylist['appimg']}" style=" width:150px;">
					</div>
					<div class="media-body">
						<dl>
							<dt>{Tinwin v:mylist['applabel']}</dt>
							<dd>{Tinwin $Lang['common']['AppName']}{Tinwin v:mylist['appname']}</dd>
							<dd>{Tinwin $Lang['common']['AppVersion']}{Tinwin v:mylist['appversion']}</dd>
							<dd>{Tinwin $Lang['common']['AppAuthor']}{Tinwin v:mylist['author']}</dd>
						</dl>
						<p>
							{Tinwin if v:mylist['local']}
							{Tinwin v:mylist['local']}
							{Tinwin endif}
							{Tinwin if v:mylist['newversion']>v:mylist['localversion']}
								{Tinwin if v:mylist['localversion']==''}
									<a href="#" onclick='dswfirm("{Tinwin c:MyAppUrl}apps-netinstall&appname={Tinwin v:mylist['appname']} ","{Tinwin $Lang['common']['InstallTips']}")'>{Tinwin $Lang['common']['InstallOnline']}</a>
								{Tinwin else}
									{Tinwin $Lang['common']['AppNow']}{Tinwin v:mylist['localversion']} <a href="#" onclick='dswfirm("{Tinwin c:MyAppUrl}apps-netupgrade&appname={Tinwin v:mylist['appname']}","{Tinwin $Lang['common']['UpgradeTips']}")'>{Tinwin $Lang['common']['Upgrade']}</a>
								{Tinwin endif}
							{Tinwin endif}
						</p>
					</div>
				</div>
			</div>
            {Tinwin endtree}
        {Tinwin endif}
	</div>
</div>
{Tinwin include:footer}