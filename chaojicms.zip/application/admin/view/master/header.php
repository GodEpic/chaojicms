<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="{Tinwin c:PLUGIN_PATH}bootstrap/bootstrap.css">
<link rel="stylesheet" type="text/css" href="{Tinwin c:PLUGIN_PATH}niuguwen.css">
<link rel="stylesheet" type="text/css" href="{Tinwin c:ADMIN_SKIN}css/style.css">
<link rel="stylesheet" type="text/css" href="{Tinwin c:PLUGIN_PATH}iconfont/iconfont.css">
<script type="text/javascript" src="{Tinwin c:PLUGIN_PATH}jquery.js"></script>
<script type="text/javascript" src="{Tinwin c:PLUGIN_PATH}bootstrap/bootstrap.js"></script>
<script type="text/javascript" src="{Tinwin c:ADMIN_SKIN}js/navmenu.js"></script>
<script type="text/javascript" src="{Tinwin c:PLUGIN_PATH}niuguwen.js"></script>