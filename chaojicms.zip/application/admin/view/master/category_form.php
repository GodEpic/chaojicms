<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
<link rel="stylesheet" type="text/css" href="{Tinwin c:PLUGIN_PATH}bootstrap/bootstrap-fileinput.css">
<script type="text/javascript" src="{Tinwin c:PLUGIN_PATH}bootstrap/bootstrap-fileinput.js"></script>
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $Lang['common']['NavCategory']}</li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
    	{Tinwin include:category_nav}
    </div>    
	<div class="maininfo">
		<form action="{Tinwin $FormAction}" onSubmit="return CheckForm(this)" name="mainform" enctype="multipart/form-data" method="post">
			<ul id="myTab" class="nav nav-tabs">
				<li class="active"><a href="#basic" data-toggle="tab">{Tinwin $Lang['common']['Basic']}</a></li>
				<li><a href="#seo" data-toggle="tab">{Tinwin $Lang['common']['Seo']}</a></li>
				<li><a href="#other" data-toggle="tab">{Tinwin $Lang['common']['Other']}</a></li>
			</ul>
		<div id="myTabContent" class="tab-content w100">
			<div class="tab-pane fade in active" id="basic" style="padding-top:20px;">
				<input type="hidden" name="input_token" value="{Tinwin $input_token}">
				<input type="hidden" name="OldInput" value="{Tinwin $OldInput}" id="OldInput">
				<div class="form-group row">
					<label class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['AppName']}</label>
					<div class="col-sm-6">
						{Tinwin if $ListApps}
							<select name="dsw[appname]" class="form-control">
                                <option value="article">{Tinwin $Lang['form']['AppArticle']}</option>
								{Tinwin tree $ListApps,myList,myid}
									{Tinwin if v:myList['appname']==$ListOne['appname']}
										<option value="{Tinwin v:myList['appname']}" selected>
											{Tinwin v:myList['applabel']}
										</option>
									{Tinwin else}
										<option value="{Tinwin v:myList['appname']}">
											{Tinwin v:myList['applabel']}
										</option>
									{Tinwin endif}
								{Tinwin endtree}
							</select>
						{Tinwin else}
							<select name="dsw[appname]" class="form-control">
                                <option value="article">{Tinwin $Lang['form']['AppArticle']}</option>
                            </select>
						{Tinwin endif}
					</div>
				</div>
				<div class="form-group row">
					<label class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['ParentCatName']}</label>
					<div class="col-sm-6">
						<select name="dsw[parent_id]" class="form-control">
							<option value="0">{Tinwin $Lang['form']['TopCatName']}</option>
							{Tinwin if $CatTree}
							{Tinwin tree $CatTree,myList,myid}
								{Tinwin if v:myList['id']==$ListOne['parent_id']}
									<option value="{Tinwin v:myList['id']}" selected>{Tinwin v:myList['cat_name']}
									</option>
								{Tinwin else}
									<option value="{Tinwin v:myList['id']}">
									{Tinwin v:myList['cat_name']}
									</option>
								{Tinwin endif}	
							{Tinwin endtree}
							{Tinwin endif}
						</select>
					</div>
				</div>
				<div class="form-group row">
					<label for="cat_name" class="col-sm-3 control-label text-right"><span class="required">*</span>{Tinwin $Lang['form']['CatName']}</label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="dsw[cat_name]" maxlength="50" placeholder="{Tinwin $Lang['form']['CatNameTips']}" required value="{Tinwin $ListOne['cat_name']}">
					</div>
				</div>
				<div class="form-group row">
					<label for="catalog_name" class="col-sm-3 control-label text-right"><span class="required">*</span>{Tinwin $Lang['form']['CatalogName']}</label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="dsw[catalog_name]" maxlength="50" placeholder="{Tinwin $Lang['form']['CatalogNameTips']}" required value="{Tinwin $ListOne['catalog_name']}" id="SInput" onblur="CheckInput()" >
					</div>
					<div class="col-sm-3" id="LoadCheckInput"></div>
				</div>
				<div class="form-group row">
					<label for="cat_skin" class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['CatSkin']}</label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="dsw[cat_skin]" maxlength="50" placeholder="{Tinwin $Lang['form']['CatSkinTips']}" value="{Tinwin if $ListOne['cat_skin']}{Tinwin $ListOne['cat_skin']}{Tinwin else}category_view{Tinwin endif}" >
					</div>
					<div class="col-sm-3"></div>
				</div>
				<div class="form-group row">
					<label for="cat_skin" class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['ArticleSkin']}</label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="dsw[article_skin]" maxlength="50" placeholder="{Tinwin $Lang['form']['ArticleSkinTips']}" value="{Tinwin if $ListOne['article_skin']}{Tinwin $ListOne['article_skin']}{Tinwin else}article_view{Tinwin endif}" >
					</div>
					<div class="col-sm-3"></div>
				</div>
				<div class="form-group row" id="uploadForm" enctype='multipart/form-data'>
	                <label class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['Img']}</label>
	                <div class="col-sm-6 fileinput fileinput-new" data-provides="fileinput"  id="exampleInputUpload">
	                    <div class="fileinput-new thumbnail">
	                    	{Tinwin if $ListOne['cat_img']==""}
	                        <img id='picImg' src="{Tinwin c:STATIC_PATH}images/noimage.png" />
	                        {Tinwin else}
							<img id='picImg' src="{Tinwin $ListOne['cat_img']}" />
							{Tinwin endif}
	                    </div>
	                    <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px;"></div>
	                    <div>
	                        <span class="btn btn-primary btn-file">
	                            <span class="fileinput-new">{Tinwin $Lang['form']['ImgSelect']}</span>
	                            <span class="fileinput-exists">{Tinwin $Lang['form']['ImgChange']}</span>
	                            <input type="file" name="file" id="file" accept="image/gif,image/jpeg,image/x-png">
	                        </span>
	                        <a href="javascript:;" class="btn btn-warning fileinput-exists" data-dismiss="fileinput">{Tinwin $Lang['form']['ImgDel']}</a>
	                    </div>
	                </div>
	            </div>
				<div class="form-group row">
					<label class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['Inrow']}</label>
					<div class="col-sm-6">
						<input type="number" class="form-control" name="dsw[inrow]" maxlength="5" placeholder="{Tinwin $Lang['form']['InrowTips']}" value="{Tinwin $ListOne['inrow']}" min="0" max="99999" step="1" >
					</div>
                    <div class="col-sm-3">{Tinwin $Lang['form']['InrowTips']}</div>
				</div>
				<div class="form-group row">
					<label class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['View']}</label>
					<div class="col-sm-6">
                        <input type="number" class="form-control" name="dsw[cat_view]" maxlength="10" placeholder="{Tinwin $Lang['form']['ViewTips']}" value="{Tinwin if $ListOne['cat_view']}{Tinwin $ListOne['cat_view']}{Tinwin else}0{Tinwin endif}" min="0" max="99999" step="1" >
					</div>
				</div>
			</div>
			<div class="tab-pane fade in" id="seo" style="padding-top:20px;">				
				<div class="form-group row">
					<label class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['SeoTitle']}</label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="dsw[seo_title]" maxlength="80" placeholder="{Tinwin $Lang['form']['SeoTitleTips']}" value="{Tinwin $ListOne['seo_title']}">
					</div>
				</div>
				<div class="form-group row">
					<label class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['SeoKeywords']}</label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="dsw[seo_keywords]" maxlength="200" placeholder="{Tinwin $Lang['form']['SeoKeywordsTips']}" value="{Tinwin $ListOne['seo_keywords']}">
					</div>
				</div>
				<div class="form-group row">
					<label class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['SeoDescription']}</label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="dsw[seo_description]" maxlength="200" placeholder="{Tinwin $Lang['form']['SeoDescriptionTips']}" value="{Tinwin $ListOne['seo_description']}">
					</div>
				</div>
				<div class="form-group row">
					<label class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['CatUrl']}</label>
					<div class="col-sm-4">
						<input type="text" class="form-control" name="dsw[cat_url]" maxlength="250" placeholder="{Tinwin $Lang['form']['CatUrlTips']}" value="{Tinwin $ListOne['cat_url']}">
					</div>
					<div class="col-sm-2">
						{Tinwin if $ListOne['isoutlink']==1}
							<label><input name="dsw[isoutlink]" type="radio" value="1" checked />{Tinwin $Lang['form']['OutLink']}</label>
							<label><input name="dsw[isoutlink]" type="radio" value="0" />{Tinwin $Lang['form']['InLink']}</label>
						{Tinwin else}
							<label><input name="dsw[isoutlink]" type="radio" value="1" />{Tinwin $Lang['form']['OutLink']}</label>
							<label><input name="dsw[isoutlink]" type="radio" value="0" checked />{Tinwin $Lang['form']['InLink']}</label>
						{Tinwin endif}				
					</div>
				</div>
			</div>
			<div class="tab-pane fade in" id="other" style="padding-top:20px;">
				<div class="form-group row">
					<label class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['IsView']}</label>
					<div class="col-sm-6">
						<select name="dsw[isview]" class="form-control">
							{Tinwin if $ListOne['isview']==1}
							<option value="0">{Tinwin $Lang['form']['NoView']}</option>
							<option value="1" selected>{Tinwin $Lang['form']['YesView']}</option>
							{Tinwin else}
							<option value="0" selected>{Tinwin $Lang['form']['NoView']}</option>
							<option value="1">{Tinwin $Lang['form']['YesView']}</option>
							{Tinwin endif}
						</select>
					</div>
				</div>
                <div class="form-group row">
					<label class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['MenuView']}</label>
					<div class="col-sm-6">
						<select name="dsw[ismenu]" class="form-control">
							{Tinwin if $ListOne['ismenu']==1}
							<option value="0">{Tinwin $Lang['form']['NoView']}</option>
							<option value="1" selected>{Tinwin $Lang['form']['YesView']}</option>
							{Tinwin else}
							<option value="0" selected>{Tinwin $Lang['form']['NoView']}</option>
							<option value="1">{Tinwin $Lang['form']['YesView']}</option>
							{Tinwin endif}
						</select>
					</div>
				</div>
                <div class="form-group row">
					<label for="isindex" class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['IndexView']}</label>
					<div class="col-sm-6">
						<select name="dsw[isindex]" class="form-control">
							{Tinwin if $ListOne['isindex']==1}
							<option value="0">{Tinwin $Lang['form']['NoView']}</option>
							<option value="1" selected>{Tinwin $Lang['form']['YesView']}</option>
							{Tinwin else}
							<option value="0" selected>{Tinwin $Lang['form']['NoView']}</option>
							<option value="1">{Tinwin $Lang['form']['YesView']}</option>
							{Tinwin endif}
						</select>
					</div>
				</div>
                <div class="form-group row">
					<label for="cat_price" class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['CatPrice']}</label>
					<div class="col-sm-6">
						<input type="number" class="form-control" name="dsw[cat_price]" maxlength="50" placeholder="{Tinwin $Lang['form']['CatPriceTips']}" value="{Tinwin if $ListOne['cat_price']}{Tinwin $ListOne['cat_price']}{Tinwin else}0{Tinwin endif}">
					</div>
				</div>
			</div>
			<div class="form-group row">
				<label for="psd2" class="col-sm-3 control-label"></label>
				<div class="col-sm-6">
					<button type="submit" class="btn btn-default">{Tinwin $Lang['form']['SaveButton']}</button>
				</div>
			</div>
		</div>
	</form>
</div>
</div>
<script type="text/javascript">
function CheckForm() {  
	var obj = document.getElementById('file');  
	if (obj.value != ''){
        var stuff = obj.value.substr(obj.value.length-3, 3);  
        if (stuff!='jpg'&&stuff!='png'&&stuff!='jpeg'&&stuff!='gif') {  
            alert('{Tinwin $Lang['form']['ImgUploadTips']}');  
            return false;
        }
    }
	return true;
}
function CheckInput(){
	var x=document.getElementById("SInput");
	var y=document.getElementById("OldInput");
	if(y.value==""&&x.value!=''){
		$('#LoadCheckInput').load("{Tinwin c:MyAppUrl}category-CheckInput&SInput="+x.value);
	}
};
</script>
{Tinwin include:footer}
