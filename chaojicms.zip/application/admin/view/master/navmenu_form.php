<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li><a href="{Tinwin c:MyAppUrl}navmenu">{Tinwin $Lang['form']['MenuManage']}</li>
			<li>/</li>
			<li><a href="{Tinwin c:MyAppUrl}navmenu-add&cid={Tinwin $ListFather['id']}">{Tinwin $ListFather['menu_label']}</li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
        {Tinwin include:navmenu_nav}
    </div>    
	<div class="maininfo">
		<form action="{Tinwin $FormAction}" method="post" class="container-fluid">
			<input type="hidden" name="input_token" value="{Tinwin $input_token}">
			<div class="form-group row" style="padding-top:20px;">
				<label for="inrow" class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['Inrow']}</label>
				<div class="col-sm-6">
					<input type="number" class="form-control" name="dsw[inrow]" maxlength="5" placeholder="{Tinwin $Lang['form']['InrowTips']}" required value="{Tinwin $ListOne['inrow']}" min="0" max="99999" step="1" >
				</div>
			</div>
			<div class="form-group row">
					<label class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['ParentName']}</label>
					<div class="col-sm-6">
						{Tinwin if $MenuTree}
							<select name="dsw[parent_id]" class="form-control">
								<option value="0">{Tinwin $Lang['form']['TopMenu']}</option>
								{Tinwin tree $MenuTree,mylist,myid}
									{Tinwin if v:mylist['id']==$ListOne['parent_id']}
										<option value="{Tinwin v:mylist['id']}" selected>{Tinwin v:mylist['menu_label']}
										</option>
									{Tinwin else}
										<option value="{Tinwin v:mylist['id']}">
										{Tinwin v:mylist['menu_label']}
										</option>
									{Tinwin endif}	
								{Tinwin endtree}
							</select>
						{Tinwin endif}
					</div>
				</div>
			<div class="form-group row">
				<label for="menu_label" class="col-sm-3 control-label text-right"><span class="required">*</span>{Tinwin $Lang['form']['MenuLabel']}</label>
				<div class="col-sm-6">
					<input type="text" class="form-control" name="dsw[menu_label]" placeholder="{Tinwin $Lang['form']['MenuLabelTips']}" required value="{Tinwin $ListOne['menu_label']}" >
				</div>
			</div>			
			<div class="form-group row">
				<label for="menu_path" class="col-sm-3 control-label text-right"><span class="required">*</span>{Tinwin $Lang['form']['MenuPath']}</label>
				<div class="col-sm-6">
					<input type="text" class="form-control" name="dsw[menu_path]" placeholder="{Tinwin $Lang['form']['MenuPathTips']}" required value="{Tinwin $ListOne['menu_path']}" >
				</div>
			</div>
			<div class="form-group row">
				<label for="iconfont" class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['Iconfont']}</label>
				<div class="col-sm-6">
					<input type="text" class="form-control" name="dsw[iconfont]" placeholder="{Tinwin $Lang['form']['IconfontTips']}" value="{Tinwin $ListOne['iconfont']}" maxlength="50" >
				</div>
			</div>
			<div class="form-group row">
				<label for="menu_type" class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['MenuGroup']}</label>
				<div class="col-sm-6">
					<select name="dsw[menu_type]" class="form-control">
                        {Tinwin tree $MenuGroup,mylist,myid}
						{Tinwin if $ListOne['menu_type']==v:mylist['group_name']}
							<option selected="selected" value ="{Tinwin v:mylist['group_name']}" >{Tinwin v:mylist['group_label']}</option>
						{Tinwin else}
							<option value ="{Tinwin v:mylist['group_name']}" >{Tinwin v:mylist['group_label']}</option>
						{Tinwin endif}
                        {Tinwin endtree}
					</select>
				</div>
			</div>
			<div class="form-group row">
				<label for="menu_target" class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['MenuTarget']}</label>
				<div class="col-sm-6">
					<select name="dsw[menu_target]" class="form-control">
						{Tinwin if $ListOne['menu_target']=='_blank'}
							<option selected="selected" value ="_blank" >{Tinwin $Lang['form']['MenuTargetBlank']}</option>
							<option value ="_self" >{Tinwin $Lang['form']['MenuTargetSelf']}</option>
						{Tinwin else}
							<option selected="selected" value ="_self" >{Tinwin $Lang['form']['MenuTargetSelf']}</option>
							<option value ="_blank" >{Tinwin $Lang['form']['MenuTargetBlank']}</option>
						{Tinwin endif}
					</select>
				</div>
			</div>
			<div class="form-group row">
				<label for="psd2" class="col-sm-3 control-label"></label>
				<div class="col-sm-6">
					<button type="submit" class="btn btn-primary">{Tinwin $Lang['form']['Button']}</button>
                    <a href="javascript:history.go(-1);" class="btn btn-default" style="margin-left: 10px;">{Tinwin $Lang['form']['Goback']}</a>
				</div>
			</div>
		</form>
	</div>
</div>
{Tinwin include:footer}
