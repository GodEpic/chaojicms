<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
        {Tinwin include:user_nav}
    </div>
    <div class="mainsearch">
        {Tinwin include:user_search}
    </div> 
	<div class="maininfo">
		<form action="{Tinwin $FormAction}" method="post">
		<table class="table">
			<thead>
				<tr>
					<td>ID</td>
					<td>{Tinwin $Lang['index']['Username']}</td>
					<td>{Tinwin $Lang['index']['Nickname']}</td>
					<td>{Tinwin $Lang['index']['UserType']}</td>
					<td>{Tinwin $Lang['index']['RegisterTime']}</td>
					<td colspan="2">{Tinwin $Lang['index']['Operation']}</td>
				</tr>
			</thead>
			<tbody>
				{Tinwin if $ListAll['data']}
				{Tinwin tree $ListAll['data'],myList,cid}
				<tr>
					<td>{Tinwin v:myList['id']}</td>
					<td>{Tinwin v:myList['username']}</td>
					<td>{Tinwin v:myList['nickname']}</td>
					<td onClick="DisplayOK(this)" id="{Tinwin c:ADMIN_URL}user-isadmin&id={Tinwin v:myList['id']}" style="cursor:pointer;">
						{Tinwin if v:myList['isadmin']==1}		
							{Tinwin $Lang['index']['Manage']}
						{Tinwin else}
							{Tinwin $Lang['index']['DefaultUser']}
						{Tinwin endif}
					</td>
					<td>{Tinwin date:v:myList['addtime'],'Y-m-d H:i:s'}</td>
					<td><a class="glyphicon glyphicon-edit" href="{Tinwin c:ADMIN_URL}user-edit&id={Tinwin v:myList['id']}"></a></td>
					<td><a class="glyphicon glyphicon-remove" href="#" onclick='dswfirm("{Tinwin c:ADMIN_URL}user-del&id={Tinwin v:myList['id']}","{Tinwin $Lang['index']['DelTips']}")'></a></td>
				</tr>
				{Tinwin endtree}
				{Tinwin endif}
			</tbody>
		</table>
		<div class="page"><section><ul>{Tinwin $ListAll['pages']}</ul></section></div>
		</form>
	</div>
</div>
{Tinwin include:footer}
