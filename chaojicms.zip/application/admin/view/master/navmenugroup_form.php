<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
            <li>/</li>
            <li><a href="{Tinwin c:MyAppUrl}navmenu">{Tinwin $Lang['form']['MenuManage']}</li>
            <li>/</li>
            <li><a href="{Tinwin c:MyAppUrl}navmenu-group">{Tinwin $Lang['nav']['GroupManage']}</li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
        {Tinwin include:navmenu_nav}
    </div>    
	<div class="maininfo">
		<form action="{Tinwin $FormAction}" method="post" class="container-fluid">
			<input type="hidden" name="input_token" value="{Tinwin $input_token}">
			<div class="form-group row" style="padding-top:20px;">
				<label for="inrow" class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['Inrow']}</label>
				<div class="col-sm-6">
					<input type="number" class="form-control" name="dsw[inrow]" maxlength="5" placeholder="{Tinwin $Lang['form']['InrowTips']}" required value="{Tinwin $ListOne['inrow']}" min="0" max="99999" step="1" >
				</div>
			</div>
			<div class="form-group row">
				<label for="group_name" class="col-sm-3 control-label text-right"><span class="required">*</span>{Tinwin $Lang['form']['GroupName']}</label>
				<div class="col-sm-6">
					<input type="text" class="form-control" name="dsw[group_name]" placeholder="{Tinwin $Lang['form']['GroupNameTips']}" title="{Tinwin $Lang['form']['GroupNameTips']}" required value="{Tinwin $ListOne['group_name']}" >
				</div>
			</div>
			<div class="form-group row">
				<label for="group_label" class="col-sm-3 control-label text-right"><span class="required">*</span>{Tinwin $Lang['form']['GroupLabel']}</label>
				<div class="col-sm-6">
					<input type="text" class="form-control" name="dsw[group_label]" placeholder="{Tinwin $Lang['form']['GroupLabelTips']}" title="{Tinwin $Lang['form']['GroupLabelTips']}" required value="{Tinwin $ListOne['group_label']}" >
				</div>
			</div>
			<div class="form-group row">
				<label for="psd2" class="col-sm-3 control-label"></label>
				<div class="col-sm-6">
					<button type="submit" class="btn btn-primary">{Tinwin $Lang['form']['Button']}</button>
                    <a href="javascript:history.go(-1);" class="btn btn-default" style="margin-left: 10px;">{Tinwin $Lang['form']['Goback']}</a>
				</div>
			</div>
		</form>
	</div>
</div>
{Tinwin include:footer}
