<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="{Tinwin c:ADMIN_SKIN}css/login.css">
</head>
<body>
<div class="top">
    <div class="top-wrap">
        <div class="top-main">
            <div class="main-hd">
                <img src="{Tinwin c:ADMIN_SKIN}images/login/logo_03.png" width="108" height="103">
                <h1>超级CMS</h1>
            </div>
            <form class="form" action="{Tinwin $FormAction}" method="post">
                <div class="main-bd">                  	
                    <div class="pic-1">
                        <img src="{Tinwin c:ADMIN_SKIN}images/login/main-bd.png" width="30" height="30">
                        <input type="text" name="dsw[username]" placeholder="{Tinwin $Lang['index']['UsernameTips']}" class="input-1" value="" />
                    </div>
                    <div class="pic-1" style="margin-top:10px;">
                        <img src="{Tinwin c:ADMIN_SKIN}images/login/main-bd-1_02.png" width="30" height="30">
                        <input type="password" name="dsw[psd]" placeholder="{Tinwin $Lang['index']['PsdTips']}" class="input-1" value="" />
                    </div>
                </div>
                <div class="main-ft"><button type="submit">{Tinwin $Lang['index']['Submit']}</button></div>
            </form>
        </div>
    </div>
</div>
{Tinwin include:footer}

