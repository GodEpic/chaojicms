<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
        <div class="menu title">
            <ul>
                <li><a href="{Tinwin c:ADMIN_URL}skin"><span class="glyphicon glyphicon-hdd"></span><span>{Tinwin $Lang['nav']['Index']}</span></a></li>
                <li><a href="{Tinwin c:ADMIN_URL}skin-net"><span class="glyphicon glyphicon-cloud"></span><span>{Tinwin $Lang['nav']['Net']}</span></a></li>
            </ul>
        </div>
    </div>
	<div class="maininfo">
		{Tinwin if $SkinList}
			{Tinwin tree $SkinList,myList,myid}
			<div class=" col-sm-6" style="margin-bottom:20px;">
				<div class="skinlist">
					<div class="media-left">
						<a href="{Tinwin c:ADMIN_URL}file-getDir&mypath=/application/home/view/{Tinwin v:myList['name']}"><img class="media-object" src="{Tinwin v:myList['img']}"></a>
					</div>
					<div class="media-body">
						<dl>
							<dt>{Tinwin v:myList['config']['label']}</dt>
							<dd>{Tinwin $Lang['index']['SkinName']}{Tinwin v:myList['name']}</dd>
							<dd>{Tinwin $Lang['index']['SkinVersion']}{Tinwin v:myList['config']['version']}</dd>
							<dd>{Tinwin $Lang['index']['UiAuthor']}{Tinwin v:myList['config']['ui_author']}，{Tinwin $Lang['index']['HtmlAuthor']}{Tinwin v:myList['config']['html_author']}，{Tinwin $Lang['index']['SkinAuthor']}{Tinwin v:myList['config']['skin_author']}</dd>
							<dd>{Tinwin $Lang['index']['SkinUrl']}<a href="{Tinwin v:myList['config']['url']}">{Tinwin v:myList['config']['url']}</a></dd>
						</dl>
						<p>
							<a href="{Tinwin c:ADMIN_URL}file-getDir&mypath=/application/home/view/{Tinwin v:myList['name']}">{Tinwin $Lang['index']['Edit']}</a>
							{Tinwin v:myList['status']}{Tinwin v:myList['del']}
						</p>
					</div>
				</div>
			</div>
			{Tinwin endtree}
		{Tinwin endif}
	</div>
</div>
{Tinwin include:footer}
