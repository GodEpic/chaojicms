<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
        {Tinwin include:category_nav}
    </div>    
	<div class="maininfo">
        <table class="table">
            <thead>  
                <tr>
                    <td>id</td>
                    <td>{Tinwin $Lang['table']['Inrow']}</td>
                    <td>{Tinwin $Lang['table']['CategoryName']}</td>
                    <td>{Tinwin $Lang['table']['ArticleList']}</td>
                    <td>{Tinwin $Lang['table']['CategorySun']}</td>
                    <td>{Tinwin $Lang['table']['CategoryAppname']}</td>
                    <td>{Tinwin $Lang['table']['IsView']}</td>
                    <td>{Tinwin $Lang['table']['IsHome']}</td>
                    <td>{Tinwin $Lang['table']['IsMenu']}</td>
                    <td colspan="4">{Tinwin $Lang['table']['Operation']}</td>
                </tr>
                </thead>
                <tbody>
            {Tinwin tree $ListAll['data'],myList,myid}
                <tr>
                    <td>{Tinwin v:myList['id']}</td>
                    <td>{Tinwin v:myList['inrow']}</td>
                    <td><a href="{Tinwin c:ADMIN_URL}category-edit&id={Tinwin v:myList['id']}" title="{Tinwin $Lang['table']['Edit']}" target="_blank">{Tinwin v:myList['cat_name']}</a></td>
                    <td><a href="{Tinwin c:ADMIN_URL}article-manage_one&cid={Tinwin v:myList['id']}">{Tinwin $Lang['table']['ArticleList']}</a></td>
                    <td><a href="{Tinwin c:ADMIN_URL}category-manage&cid={Tinwin v:myList['id']}">{Tinwin $Lang['table']['CategorySun']}</a></td>
                    <td>{Tinwin v:myList['appname']}</td>
                    <td onClick="DisplayOK(this)" id="{Tinwin c:ADMIN_URL}category-isview&id={Tinwin v:myList['id']}" style="cursor:pointer;">
                        {Tinwin if v:myList['isview']==1}		
                            <span class="glyphicon glyphicon-eye-open"></span>
                        {Tinwin else}
                            <span class="glyphicon glyphicon-eye-close"></span>
                        {Tinwin endif}
                    </td>
                    <td onClick="DisplayOK(this)" id="{Tinwin c:ADMIN_URL}category-isindex&id={Tinwin v:myList['id']}" style="cursor:pointer;">
                        {Tinwin if v:myList['isindex']==1}       
                            <span class="glyphicon glyphicon-eye-open"></span>
                        {Tinwin else}
                            <span class="glyphicon glyphicon-eye-close"></span>
                        {Tinwin endif}
                    </td>
                    <td onClick="DisplayOK(this)" id="{Tinwin c:ADMIN_URL}category-ismenu&id={Tinwin v:myList['id']}" style="cursor:pointer;">
                        {Tinwin if v:myList['ismenu']==1}       
                            <span class="glyphicon glyphicon-eye-open"></span>
                        {Tinwin else}
                            <span class="glyphicon glyphicon-eye-close"></span>
                        {Tinwin endif}
                    </td>
                    <td><a class="glyphicon glyphicon-plus" href="{Tinwin c:MyAppUrl}article-add&cid={Tinwin v:myList['id']}" title="{Tinwin $Lang['table']['Add']}"></a></td>
                    <td><a class="glyphicon glyphicon-globe" target="_blank" href="{Tinwin if v:myList['isoutlink']==1}{Tinwin v:myList['cat_url']}{Tinwin else}{Tinwin c:SITE_ROOT}{Tinwin v:myList['catalog_name']}/" title="{Tinwin $Lang['table']['View']}{Tinwin endif}"></a></td>
                    <td><a class="glyphicon glyphicon-edit" href="{Tinwin c:ADMIN_URL}category-edit&id={Tinwin v:myList['id']}" title="{Tinwin $Lang['table']['Edit']}"></a></td>
                    <td><a class="glyphicon glyphicon-remove" href="#" onclick='dswfirm("{Tinwin c:ADMIN_URL}category-del&id={Tinwin v:myList['id']}","{Tinwin $Lang['table']['DelTips']}")' title="{Tinwin $Lang['table']['Del']}"></a></td>
                    <!-- <td><a class="glyphicon glyphicon-edit" href="{Tinwin c:ADMIN_URL}category-makehtml&id={Tinwin v:myList['id']}" title="{Tinwin $Lang['table']['Makehtml']}"></a></td> -->
                </tr>
            {Tinwin endtree}
        </table>
        <div class="page"><section><ul>{Tinwin $ListAll['pages']}</ul></section></div>
        </div>
    </div>
</div>
{Tinwin include:footer}
