<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
<script>
    //update表单
	var id=0;
    function update_info(id){
        id = id; 
        //alert(id);
	})
</script>
<!-- 模态框（Modal） -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					&times;
				</button>
				<h4 class="modal-title" id="myModalLabel">
					相关文章设置
				</h4>
			</div>
            <form action="{Tinwin $FormActionAjax}" method="post">
			<div class="modal-body">
			    {Tinwin tree $ListAll,mylist,myid}
                    <li><input type="checkbox" name="SelectCheckbox[]" value="{Tinwin $myList['id']}">
                    {Tinwin v:mylist['title']}</li>
                {Tinwin endtree}
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
				<button type="submit" class="btn btn-primary">提交更改</button>
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal -->
</div>