<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
	</div>   
	<div class="maininfo">
		<div class="w100">
			<table class="table">
				<thead>
					<tr>
						<td colspan="3"><span class="fl">搜索引擎收录详情</span><a style="margin-left:2rem;" class="fr" href="{Tinwin c:ADMIN_URL}seo-update">更新缓存</a><span class="fr">缓存时间:{Tinwin date:$DataList['endtime'],'Y-m-d H:i:s'}</span></td>
					</tr>
				</thead>
				<thead>
					<tr>
						<td>百度</td>
						<td>360</td>
						<td>搜狗</td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>{Tinwin $DataList['baidu']}</td>
						<td>{Tinwin $DataList['360']}</td>
						<td>{Tinwin $DataList['sogou']}</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
{Tinwin include:footer}