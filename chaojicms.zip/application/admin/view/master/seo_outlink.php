<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">后台首页</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
	</div>   
	<div class="maininfo">
		seo站长工具模块是超级CMS特有的模块，由SEO研究中心（bbs.moonseo.cn）提出，结合多位老师的实战经验。提取出一些SEO人员常用的功能在后台直接查看数据。
	</div>
</div>
{Tinwin include:footer}