<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
        {Tinwin include:category_nav}
    </div>    
    <div class="maininfo">
        <div style="margin-top:100px; positon:relative;">
            <h1 class="text-center">{Tinwin $FormTitle}</h1>
            <div class="col-xs-6 col-md-offset-3">
                <form action="{Tinwin c:ADMIN_URL}search-manage" method="post">
                        <input type="hidden" name="input_token" value="{Tinwin $input_token}">
                <div class="input-group col-md-12">
                    <input type="text" name="searchkeywords" class="form-control" placeholder="{Tinwin $Placeholder}" required oninvalid="setCustomValidity('{Tinwin $Lang['index']['FormTips']}')" oninput="setCustomValidity('')"  / >
                    <span class="input-group-btn">
                    <button class="btn btn-info btn-search">{Tinwin $Lang['index']['Submit']}</button>
                    </span>  
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
{Tinwin include:footer}
