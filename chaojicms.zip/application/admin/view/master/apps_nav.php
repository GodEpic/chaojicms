<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
<div class="menu title">
    <ul>
        <li><a href="{Tinwin c:MyAppUrl}apps-index"><span class="iconfont icon-liebiao1"></span><span>{Tinwin $Lang['nav']['Index']}</span></a></li>
        <li><a href="{Tinwin c:MyAppUrl}apps-del"><span class="iconfont icon-shanchu"></span><span>{Tinwin $Lang['nav']['Del']}</span></a></li>
        <li><a href="{Tinwin c:MyAppUrl}apps-add"><span class="iconfont icon-add"></span><span>{Tinwin $Lang['nav']['Add']}</span></a></li>
        <li><a href="{Tinwin c:MyAppUrl}apps-upgrade"><span class="iconfont icon-shengji"></span><span>{Tinwin $Lang['nav']['Upgrade']}</span></a></li>
        <li><a href="{Tinwin c:MyAppUrl}apps-installed"><span class="iconfont icon-caidan"></span><span>{Tinwin $Lang['nav']['Installed']}</span></a></li>
        <li><a href="{Tinwin c:MyAppUrl}apps-online"><span class="iconfont icon-xiazai"></span><span>{Tinwin $Lang['nav']['Online']}</span></a></li>
    </ul>
</div>