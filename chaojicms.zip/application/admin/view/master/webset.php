<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
<link rel="stylesheet" type="text/css" href="{Tinwin c:PLUGIN_PATH}bootstrap/bootstrap-fileinput.css">
<script type="text/javascript" src="{Tinwin c:PLUGIN_PATH}bootstrap/bootstrap-fileinput.js"></script>
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['set']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>   
	<div class="maininfo">
		<form action="{Tinwin $FormAction}" onSubmit="return CheckForm(this)" name="mainform" enctype="multipart/form-data" method="post">
			<ul id="myTab" class="nav nav-tabs">
				<li class="active"><a href="#basic" data-toggle="tab">{Tinwin $Lang['set']['Basic']}</a></li>
				<li><a href="#seo" data-toggle="tab">{Tinwin $Lang['set']['Seo']}</a></li>
				<li><a href="#contact" data-toggle="tab">{Tinwin $Lang['set']['Contact']}</a></li>
				<li><a href="#soft" data-toggle="tab">{Tinwin $Lang['set']['Soft']}</a></li>
			</ul>
	        <div id="myTabContent" class="tab-content">
				<div class="tab-pane fade in active" id="basic" style="padding-top:20px;">
					<input type="hidden" name="input_token" value="{Tinwin $input_token}">
					<div class="form-group row">
						<label for="web_name" class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['WebName']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[web_name]" maxlength="50" placeholder="{Tinwin $Lang['set']['WebNameTips']}" title="{Tinwin $Lang['set']['WebNameTips']}" required value="{Tinwin $ListOne['web_name']}">
						</div>
						<div class="col-sm-3">$WebConfig['website']['web_name']</div>
					</div>
					<div class="form-group row">
						<label for="web_url" class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['WebUrl']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[web_url]" maxlength="50" placeholder="{Tinwin $Lang['set']['WebUrlTips']}"  title="{Tinwin $Lang['set']['WebUrlTips']}" required value="{Tinwin $ListOne['web_url']}">
						</div>
						<div class="col-sm-3">$WebConfig['website']['web_url']</div>
					</div>
					<div class="form-group row">
						<label for="web_dir" class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['WebDir']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[web_dir]" maxlength="50" placeholder="{Tinwin $Lang['set']['WebDirTips']}" title="{Tinwin $Lang['set']['WebDirTips']}" required value="{Tinwin $ListOne['web_dir']}" >
						</div>
						<div class="col-sm-3">$WebConfig['website']['web_dir']</div>
					</div>
					<div class="form-group row">
						<label for="web_index" class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['WebIndex']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[web_index]" maxlength="50" placeholder="{Tinwin $Lang['set']['WebIndexTips']}" title="{Tinwin $Lang['set']['WebIndexTips']}" required value="{Tinwin $ListOne['web_index']}" >
						</div>
						<div class="col-sm-3">$WebConfig['website']['web_index']</div>
					</div>
					<div class="form-group row" id="uploadForm" enctype='multipart/form-data'>
		                <label class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['Img']}</label>
		                <div class="col-sm-6 fileinput fileinput-new" data-provides="fileinput"  id="exampleInputUpload">
		                    <div class="fileinput-new thumbnail">
		                    	{Tinwin if $ListOne['web_logo']==""}
		                        <img id='picImg' src="{Tinwin c:STATIC_PATH}images/noimage.png" />
		                        {Tinwin else}
								<img id='picImg' src="{Tinwin $ListOne['web_logo']}" />
								{Tinwin endif}
		                    </div>
		                    <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px;"></div>
		                    <div>
		                        <span class="btn btn-primary btn-file">
		                            <span class="fileinput-new">{Tinwin $Lang['set']['ImgSelect']}</span>
		                            <span class="fileinput-exists">{Tinwin $Lang['set']['ImgChange']}</span>
		                            <input type="file" name="file" id="file" accept="image/gif,image/jpeg,image/x-png">
		                        </span>
		                        <a href="javascript:;" class="btn btn-warning fileinput-exists" data-dismiss="fileinput">{Tinwin $Lang['set']['ImgDel']}</a>
		                    </div>
		                </div>
		            </div>
					<div class="form-group row">
						<label for="web_copyright" class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['WebCopyright']}</label>
						<div class="col-sm-6">
							<textarea class="form-control" rows="3" title="{Tinwin $Lang['set']['WebCopyrightTips']}" name="dsw[web_copyright]">{Tinwin $ListOne['web_copyright']}</textarea>
						</div>
						<div class="col-sm-3">$WebConfig['website']['web_copyright']</div>
					</div>
					<div class="form-group row">
						<label for="web_tongji" class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['WebTongji']}</label>
						<div class="col-sm-6">
							<textarea class="form-control" rows="3" title="{Tinwin $Lang['set']['WebTongjiTips']}" name="dsw[web_tongji]">{Tinwin $ListOne['web_tongji']}</textarea>
						</div>
						<div class="col-sm-3">$WebConfig['website']['web_tongji']</div>
					</div>
					<div class="form-group row">
						<label for="web_icp" class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['WebIcp']}</label>
						<div class="col-sm-6">
						<input type="text" class="form-control" name="dsw[web_icp]" maxlength="50" placeholder="{Tinwin $Lang['set']['WebIcpTips']}" title="{Tinwin $Lang['set']['WebIcpTips']}" value="{Tinwin $ListOne['web_icp']}">
						</div>
						<div class="col-sm-3">$WebConfig['website']['web_icp']</div>
					</div>
				</div>
				<div class="tab-pane fade" id="seo" style="padding-top:20px;">
					<div class="form-group row">
						<label for="seo_title" class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['SeoTitle']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[seo_title]" maxlength="200" placeholder="{Tinwin $Lang['set']['SeoTitleTips']}" title="{Tinwin $Lang['set']['SeoTitleTips']}" value="{Tinwin $ListOne['seo_title']}">
						</div>
						<div class="col-sm-3">$WebConfig['website']['seo_title']</div>
					</div>
					<div class="form-group row">
						<label for="seo_keywords" class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['SeoKeywords']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[seo_keywords]" maxlength="255" placeholder="{Tinwin $Lang['set']['SeoKeywordsTips']}" title="{Tinwin $Lang['set']['SeoKeywordsTips']}" value="{Tinwin $ListOne['seo_keywords']}">
						</div>
						<div class="col-sm-3">$WebConfig['website']['seo_keywords']</div>
					</div>
					<div class="form-group row">
						<label for="seo_description" class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['SeoDescription']}</label>
						<div class="col-sm-6">
							<textarea class="form-control" rows="3" title="{Tinwin $Lang['set']['SeoDescriptionTips']}" placeholder="{Tinwin $Lang['set']['SeoDescriptionTips']}" name="dsw[seo_description]" maxlength="255">{Tinwin $ListOne['seo_description']}</textarea>
						</div>
						<div class="col-sm-3">$WebConfig['website']['seo_description']</div>
					</div>
				</div>
				<div class="tab-pane fade" id="contact" style="padding-top:20px;">
					<div class="form-group row">
						<label for="web_email" class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['WebEmail']}</label>
						<div class="col-sm-6">
							<input type="email" class="form-control" name="dsw[web_email]" maxlength="200" placeholder="{Tinwin $Lang['set']['WebEmailTips']}" title="{Tinwin $Lang['set']['WebEmailTips']}" value="{Tinwin $ListOne['web_email']}">
						</div>
						<div class="col-sm-3">$WebConfig['website']['web_email']</div>
					</div>
					<div class="form-group row">
						<label for="web_qq" class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['WebQQ']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[web_qq]" maxlength="255" placeholder="{Tinwin $Lang['set']['WebQQTips']}" title="{Tinwin $Lang['set']['WebQQTips']}" value="{Tinwin $ListOne['web_qq']}">
						</div>
						<div class="col-sm-3">$WebConfig['website']['web_qq']</div>
					</div>
					<div class="form-group row">
						<label for="web_phone" class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['WebPhone']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[web_phone]" maxlength="255" placeholder="{Tinwin $Lang['set']['WebPhoneTips']}" title="{Tinwin $Lang['set']['WebPhoneTips']}" value="{Tinwin $ListOne['web_phone']}">
						</div>
						<div class="col-sm-3">$WebConfig['website']['web_phone']</div>
					</div>
					<div class="form-group row">
						<label for="web_fax" class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['WebFax']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[web_fax]" maxlength="255" placeholder="{Tinwin $Lang['set']['WebFaxTips']}" title="{Tinwin $Lang['set']['WebFaxTips']}" value="{Tinwin $ListOne['web_fax']}">
						</div>
						<div class="col-sm-3">$WebConfig['website']['web_fax']</div>
					</div>
					<div class="form-group row">
						<label for="web_address" class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['WebAddress']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[web_address]" maxlength="255" placeholder="{Tinwin $Lang['set']['WebAddressTips']}" title="{Tinwin $Lang['set']['WebAddressTips']}" value="{Tinwin $ListOne['web_address']}">
						</div>
						<div class="col-sm-3">$WebConfig['website']['web_address']</div>
					</div>
				</div>
				<div class="tab-pane fade" id="soft" style="padding-top:20px;">
					<div class="form-group row">
						<label class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['SoftUser']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[soft_user]" maxlength="200" placeholder="{Tinwin $Lang['set']['SoftUserTips']}" title="{Tinwin $Lang['set']['SoftUserTips']}" value="{Tinwin $ListOne['soft_user']}">
						</div>
						<div class="col-sm-3">$WebConfig['website']['soft_user']</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-3 control-label text-right">{Tinwin $Lang['set']['SoftToken']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[soft_token]" maxlength="200" placeholder="{Tinwin $Lang['set']['SoftTokenTips']}" title="{Tinwin $Lang['set']['SoftTokenTips']}" value="{Tinwin $ListOne['soft_token']}">
						</div>
						<div class="col-sm-3">$WebConfig['website']['soft_token']</div>
					</div>
				</div>
			</div>
			<div class="form-group row">
				<label for="psd2" class="col-sm-3 control-label"></label>
				<div class="col-sm-6">
					<button type="submit" class="btn btn-default">{Tinwin $Lang['set']['Submit']}</button>
				</div>
			</div>
		</form>
	</div>
</div>
<script type="text/javascript">
function CheckForm() {  
	var obj = document.getElementById('file');  
	if (obj.value != '') {  
	//	alert('请选择要上传的文件');  
	//	return false;
	//}  
	var stuff = obj.value.substr(obj.value.length-3, 3);  
	if (stuff!='jpg'&&stuff!='png'&&stuff!='jpeg'&&stuff!='gif') {  
		alert('{Tinwin $Lang['set']['ImgUploadTips']}');  
		return false;
	}
    }
	return true;  
}
function CheckInput(){
	var x=document.getElementById("SInput");
	var y=document.getElementById("OldInput");
	if(y.value==""){
		$('#LoadCheckInput').load("{Tinwin c:ADMIN_URL}category-CheckInput&SInput="+x.value);
	}
};
</script>
{Tinwin include:footer}
