<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
	</div>
	<div class="mainform">
		<form action="{Tinwin $FormAction}" method="post">
		<table class="table">
			<thead>
				<tr>	
					<td>{Tinwin $Lang['table']['Select']}</td>
					<td>{Tinwin $Lang['table']['TableName']}</td>
					<td>{Tinwin $Lang['table']['Remark']}</td>
					<td>{Tinwin $Lang['table']['RecodeNum']}</td>
					<td>{Tinwin $Lang['table']['Size']}</td>
					<td>{Tinwin $Lang['table']['DataEngine']}</td>
					<td>{Tinwin $Lang['table']['Code']}</td>
					<td>{Tinwin $Lang['table']['AddTime']}</td>
					<td>{Tinwin $Lang['table']['ViewField']}</td>
				</tr>
			</thead>
			<tbody>
				{Tinwin tree $ListAll,myList,cid}
				<tr>	
					<td><input type="checkbox" name="SelectCheckbox[]" value="{Tinwin v:myList['Name']}"></td>
					<td>{Tinwin v:myList['Name']}</td>
					<td>{Tinwin v:myList['Comment']}</td>
					<td>{Tinwin v:myList['Rows']}</td>
					<td>{Tinwin v:myList['Data_length']}</td>
					<td>{Tinwin v:myList['Engine']}</td>
					<td>{Tinwin v:myList['Collation']}</td>
					<td>{Tinwin v:myList['Create_time']}</td>			
					<td><a class="glyphicon glyphicon-th-list" href="{Tinwin c:MyAppUrl}data-fieldlist&stable={Tinwin v:myList['Name']}"></a></td>
				</tr>
				{Tinwin endtree}
			</tbody>
		</table>
		<div class="">
			<a onClick="choiceAll(this)" style="cursor:pointer;" class="btn btn-default">{Tinwin $Lang['table']['ChoiceAll']}</a> 
			<a style="cursor:pointer;" onClick="unSelect(this)" class="btn btn-default">{Tinwin $Lang['table']['UnSelect']}</a> 
			<a style="cursor:pointer;" onClick="choiceReverse(this)" class="btn btn-default">{Tinwin $Lang['table']['ChoiceReverse']}</a>
			<select id="dotypeid" name="dotypeid" class="btn btn-default dropdown-toggle">
				<option value="1">{Tinwin $Lang['table']['Backup']}</option>
				<option value="2">{Tinwin $Lang['table']['Optimize']}</option>
				<option value="3">{Tinwin $Lang['table']['Repair']}</option>
				<option value="4">{Tinwin $Lang['table']['Analyze']}</option>
			</select>
			<button type="submit" class="btn btn-primary">{Tinwin $Lang['table']['Execute']}</button>
		</div>
		</form>
	</div>
</div>
{Tinwin include:footer}
