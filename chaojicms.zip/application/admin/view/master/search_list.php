<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
        {Tinwin include:category_nav}
    </div>    
	<div class="maininfo">
		<form action="{Tinwin $FormAction}" method="post">
		<table class="table">
			<thead>
				<tr>
					<td>{Tinwin $Lang['keywordslist']['Select']}</td>
					<td>ID</td>
					<td>{Tinwin $Lang['keywordslist']['SearchKey']}</td>		
					<td>{Tinwin $Lang['keywordslist']['IsResult']}</td>
					<td>{Tinwin $Lang['keywordslist']['SearchTime']}</td>
					<td>{Tinwin $Lang['keywordslist']['SearchIp']}</td>
					<td>{Tinwin $Lang['keywordslist']['IsView']}</td>
					<td>{Tinwin $Lang['keywordslist']['Del']}</td>
				</tr>
			</thead>
			<tbody>
			{Tinwin if $ListAll['data']}
			{Tinwin tree $ListAll['data'],myList,cid}
			<tr>
				<td><input type="checkbox" name="SelectCheckbox[]" value="{Tinwin v:myList['search_id']}"></td>
				<td>{Tinwin v:myList['search_id']}</td>
				<td>{Tinwin v:myList['search_keywords']}</td>		
				<td>{Tinwin if v:myList['issearch']==0}{Tinwin $Lang['keywordslist']['NoResult']}{Tinwin else}{Tinwin $Lang['keywordslist']['YesResult']}{Tinwin endif}</td>
				<td>{Tinwin date:v:myList['search_time'],'Y-m-d'}</td>
				<td>{Tinwin v:myList['search_ip']}</td>
				<td onClick="DisplayOK(this)" id="{Tinwin c:ADMIN_URL}search-isview&id={Tinwin v:myList['search_id']}" style="cursor:pointer;">
					{Tinwin if v:myList['isview']==1}		
						<span class="glyphicon glyphicon-eye-open"></span>
					{Tinwin else}
						<span class="glyphicon glyphicon-eye-close"></span>
					{Tinwin endif}
				</td>
				<td><a class="glyphicon glyphicon-remove" href="#" onclick='dswfirm("{Tinwin c:ADMIN_URL}search-del&id={Tinwin v:myList['search_id']}","{Tinwin $Lang['keywordslist']['DelTips']}")'></a></td>
			</tr>
			{Tinwin endtree}
			{Tinwin endif}
		</tbody>
		</table>
		<div class="mainfoot">
			<a onClick="choiceAll(this)" style="cursor:pointer;" class="btn btn-default">{Tinwin $Lang['keywordslist']['ChoiceAll']}</a> 
			<a style="cursor:pointer;" onClick="unSelect(this)" class="btn btn-default">{Tinwin $Lang['keywordslist']['UnSelect']}</a> 
			<a style="cursor:pointer;" onClick="choiceReverse(this)" class="btn btn-default">{Tinwin $Lang['keywordslist']['ChoiceReverse']}</a>
			<button type="submit" class="btn btn-primary">{Tinwin $Lang['keywordslist']['Submit']}</button>
		</div>
		<div class="page"><section><ul>{Tinwin $ListAll['pages']}</ul></section></div>
		</form>
	</div>
</div>
{Tinwin include:footer}
