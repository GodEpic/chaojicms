<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li><a href="{Tinwin c:MyAppUrl}article">{Tinwin $Lang['common']['ArticleManage']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
    	{Tinwin include:category_nav}
    </div>    
	<div class="maininfo">
		<form action="{Tinwin $FormAction}" method="post">
			<table class="table">
				<thead>
					<tr>
						<td>{Tinwin $Lang['table']['Select']}</td>
						<td>{Tinwin $Lang['table']['Inrow']}</td>
						<td>{Tinwin $Lang['table']['Category']}</td>
						<td>ID</td>
						<td>{Tinwin $Lang['table']['ArticleTitle']}</td>
						<td>{Tinwin $Lang['table']['AddTime']}</td>
						<td>{Tinwin $Lang['table']['EndTime']}</td>
						<td>{Tinwin $Lang['table']['IsImg']}</td>
						<td colspan="3">{Tinwin $Lang['table']['Operation']}</td>
					</tr>
				</thead>
				<tbody>
					{Tinwin if $ListArt['data']}
					{Tinwin tree $ListArt['data'],myList,cid}
					<tr>
						<td><input type="checkbox" name="SelectCheckbox[]" value="{Tinwin v:myList['id']}"></td>
						<td>{Tinwin v:myList['inrow']}</td>
						<td><a href="{Tinwin c:ADMIN_URL}article-manage_one&cid={Tinwin v:myList['cat_id']}">{Tinwin $ListCat[v:myList['cat_id']]['cat_name']}</a></td>
						<td>{Tinwin v:myList['id']}</td>
						<td><a href="{Tinwin c:ADMIN_URL}article-edit&cid={Tinwin v:myList['cat_id']}&id={Tinwin v:myList['id']}">{Tinwin v:myList['title']}</a></td>
						<td>{Tinwin date:v:myList['addtime'],'Y-m-d H:i:s'}</td>
						<td>{Tinwin date:v:myList['endtime'],'Y-m-d H:i:s'}</td>
						<td>{Tinwin if v:myList['img']}有{Tinwin else}无{Tinwin endif}</td>
						<!--td><button class="btn btn-primary" data-toggle="modal" data-whatever="id={Tinwin v:myList['id']}" onclick="update_info({Tinwin v:myList['id']})" data-target="#myModal">相关文章</button></td-->
                        <td><a class="glyphicon glyphicon-globe" target="_blank" href="{Tinwin v:myList['url']}" title="{Tinwin $Lang['table']['View']}"></a></td>
						<td><a class="glyphicon glyphicon-edit" href="{Tinwin c:ADMIN_URL}article-edit&id={Tinwin v:myList['id']}" title="{Tinwin $Lang['table']['Edit']}"></a></td>
						<td><a class="glyphicon glyphicon-remove" href="#" onclick='dswfirm("{Tinwin c:ADMIN_URL}article-del&id={Tinwin v:myList['id']}","{Tinwin $Lang['table']['DelTips']}")' title="{Tinwin $Lang['table']['Del']}"></a></td>
					</tr>
					{Tinwin endtree}
					{Tinwin endif}
				</tbody>
			</table>
			<div class="">
				{Tinwin if $CatTree}
				<a onClick="choiceAll(this)" style="cursor:pointer;" class="btn btn-default">{Tinwin $Lang['table']['ChoiceAll']}</a> 
				<a style="cursor:pointer;" onClick="unSelect(this)" class="btn btn-default">{Tinwin $Lang['table']['UnSelect']}</a> 
				<a style="cursor:pointer;" onClick="choiceReverse(this)" class="btn btn-default">{Tinwin $Lang['table']['ChoiceReverse']}</a>
				<select id="catid" name="catid" class="btn btn-default dropdown-toggle">
					{Tinwin tree $CatTree,myList,myid}
						<option value="{Tinwin v:myList['id']}">{Tinwin v:myList['cat_name']}</option>
					{Tinwin endtree}
				</select>
				<button type="submit" name="operation" class="btn btn-primary" value="movecat">{Tinwin $Lang['table']['Move']}</button>
				<button type="submit" name="operation" class="btn btn-primary" value="dels">{Tinwin $Lang['table']['Dels']}</button>
				{Tinwin endif}
			</div>	
			<div class="page"><section><ul>{Tinwin $ListArt['pages']}</ul></section></div>
		</form>
	</div>
</div>
{Tinwin include:article_relation}
{Tinwin include:footer}
