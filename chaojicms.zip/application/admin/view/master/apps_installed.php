<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
	</div>
	<div class="mainform">
		{Tinwin include:apps_nav}
    </div> 
	<div class="maininfo">
		{Tinwin if $InstallList}
            {Tinwin tree $InstallList,mylist,myid}
            <div class="col-sm-6" style="margin-bottom: 20px;">
				<div class="media applist">
					<div class="media-left">
						<img class="media-object" src="{Tinwin v:mylist['mypath']}{Tinwin v:mylist['appimg']}" style=" width:150px;">
					</div>
					<div class="media-body">
						<dl>
							<dt>{Tinwin v:mylist['applabel']}</dt>
							<dd>{Tinwin $Lang['common']['AppName']}{Tinwin v:mylist['appname']}</dd>
							<dd>{Tinwin $Lang['common']['AppVersion']}{Tinwin v:mylist['appversion']}</dd>
							<dd>{Tinwin $Lang['common']['AppAuthor']}{Tinwin v:mylist['author']}</dd>
						</dl>
						<p>
							<a href="{Tinwin v:mylist['menuurl']}">{Tinwin $Lang['common']['Manage']}</a>
						</p>
					</div>
				</div>
			</div>
            {Tinwin endtree}
        {Tinwin endif}
	</div>
</div>
{Tinwin include:footer}