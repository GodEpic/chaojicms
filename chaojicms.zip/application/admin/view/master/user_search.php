<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
<form action="{Tinwin c:MyAppUrl}user-search" method="post" class="w100">
	<input type="hidden" name="input_token" value="{Tinwin $input_token}">
    <input type="text" name="searchkeywords" placeholder="{Tinwin $Lang['search']['SearchTips']}" required>
    <button name="searchbutton" id="submit" type="submit">{Tinwin $Lang['search']['SearchButton']}</button>
</form>
