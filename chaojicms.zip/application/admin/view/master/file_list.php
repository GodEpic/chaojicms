<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			{Tinwin $TinwinPath}
		</ul>
    </div>
    <div class="mainform">
    </div>    
	<div class="maininfo">
		<table class="table">
			<thead>
				<tr>
					<td>{Tinwin $Lang['table']['Select']}</td>
					<td>{Tinwin $Lang['table']['FileName']}</td>
					<td>{Tinwin $Lang['table']['FileSize']}</td>
					<td>{Tinwin $Lang['table']['FilePath']}</td>
					<td>{Tinwin $Lang['table']['EndTime']}</td>
					<td colspan="2">{Tinwin $Lang['table']['Operation']}</td>
				</tr>
			</thead>
			<tbody>
				{Tinwin if $ListAll['dir']}
				{Tinwin tree $ListAll['dir'],myList,cid}
				<tr>
					<td><input type="checkbox" name="SelectCheckbox[]" value="{Tinwin $myList['id']}"></td>
					<td><a class="glyphicon glyphicon-briefcase fl" style="padding-left:1rem;" href="index.php?admin-master-file-getDir&mypath={Tinwin $mypath}{Tinwin v:myList['name']}">{Tinwin v:myList['name']}</a></td>
					<td>{Tinwin v:myList['size']}</td>
					<td>{Tinwin v:myList['path']}</td>
					<td>{Tinwin date:v:myList['modify'],'Y-m-d H:i:s'}</td>
					<td colspan="2"><a class="glyphicon glyphicon-remove" href="#" onclick='dswfirm("{Tinwin c:ADMIN_URL}file-dirDel&mypath={Tinwin $mypath}{Tinwin v:myList['name']}","{Tinwin $Lang['table']['DelDirTips']}")'></a></td>
				</tr>
				{Tinwin endtree}
				{Tinwin endif}
				{Tinwin if $ListAll['file']}
				{Tinwin tree $ListAll['file'],myList,cid}
				<tr>
					<td><input type="checkbox" name="SelectCheckbox[]" value="{Tinwin $myList['id']}"></td>
					<td class="fl" style="padding-left:1rem;">{Tinwin v:myList['name']}</td>
					<td>{Tinwin v:myList['size']}</td>
					<td>{Tinwin v:myList['path']}</td>
					<td>{Tinwin date:v:myList['modify'],'Y-m-d H:i:s'}</td>
					<td>
						<a class="glyphicon glyphicon-edit" href="{Tinwin c:ADMIN_URL}file-fileEdit&mypath={Tinwin $mypath}{Tinwin v:myList['name']}"></a>
					</td>
					<td>
						<a class="glyphicon glyphicon-remove" href="#" onclick='dswfirm("{Tinwin c:ADMIN_URL}file-fileDel&mypath={Tinwin $mypath}{Tinwin v:myList['name']}","{Tinwin $Lang['table']['DelFileTips']}")'></a>
					</td>
				</tr>
				{Tinwin endtree}
				{Tinwin endif}
			</tbody>
		</table>
	</div>
</div>
{Tinwin include:footer}
