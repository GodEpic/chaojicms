<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
        <div class="menu title">
            <ul>
                <li><a href="{Tinwin c:ADMIN_URL}skin"><span class="glyphicon glyphicon-hdd"></span><span>{Tinwin $Lang['nav']['Index']}</span></a></li>
                <li><a href="{Tinwin c:ADMIN_URL}skin-net"><span class="glyphicon glyphicon-cloud"></span><span>{Tinwin $Lang['nav']['Net']}</span></a></li>
            </ul>
        </div>
    </div>
	<div class="maininfo">
		<div class="title" style="color: #f00;">{Tinwin $Lang['net']['Tips']}</div>
		{Tinwin if $SkinList}
			{Tinwin tree $SkinList,myList,myid}
			<div class=" col-sm-6" style="margin-bottom:20px;">
				<div class="skinlist">
					<div class="media-left">
						<img class="media-object" src="{Tinwin v:myList['skin_img']}">
					</div>
					<div class="media-body">
						<dl>
							<dt>{Tinwin v:myList['skin_label']}</dt>
							<dd>{Tinwin $Lang['net']['Price']}{Tinwin v:myList['skin_price']}</dd>
							<dd>{Tinwin $Lang['net']['Author']}{Tinwin v:myList['author']}</dd>
							<dd>{Tinwin $Lang['net']['Sold']}{Tinwin v:myList['skin_sold']}</dd>
						</dl>
						<p>
							<a target="_blank" href="http://www.chaojicms.com/skinview-{Tinwin v:myList['skin_name']}.html">{Tinwin $Lang['net']['View']}</a>
							<a href="{Tinwin c:ADMIN_URL}skin-netinstall&skin_name={Tinwin v:myList['skin_name']}">{Tinwin $Lang['net']['NetInstall']}</a>
						</p>
					</div>
				</div>
			</div>
			{Tinwin endtree}
		{Tinwin endif}
	</div>
</div>
{Tinwin include:footer}
