<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">后台首页</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
	</div>   
	<div class="maininfo">
		<div class="w100">			
			{Tinwin if $DataList}
				{Tinwin tree $DataList,mylist,cid}
				<dl>
					<dt>{Tinwin v:mylist['url']}</dt>
					<dd>{Tinwin v:mylist['info']}</dd>
				</dl>
				{Tinwin endtree}
			{Tinwin endif}
		</div>
	</div>
</div>
{Tinwin include:footer}