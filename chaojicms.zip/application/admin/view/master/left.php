<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
<div class="sidebar">
    <nav class="navbar-collapse row">
        <ul class="" id="side-menu">
            <li>
                <a class="navtitle" href="#">
                <i class="iconfont icon-guanli"></i>
                {Tinwin $Lang['webmenu']['System']}
                <span class="nav-badge"></span>
                <span class="nav-more glyphicon glyphicon-chevron-right"></span>
                </a>
                <ul class="collapse">
                    <li><a href="{Tinwin c:ADMIN_URL}webset"><span>{Tinwin $Lang['webmenu']['SystemSet']}</span></a></li>
                    <li><a href="{Tinwin c:ADMIN_URL}navmenu"><span>{Tinwin $Lang['webmenu']['MenuManage']}</span></a></li>
                    <li><a href="{Tinwin c:ADMIN_URL}file"><span>{Tinwin $Lang['webmenu']['FileManage']}</span></a></li>
                    <li><a href="{Tinwin c:ADMIN_URL}apps"><span>{Tinwin $Lang['webmenu']['ModelManage']}</span></a></li>
                    <li><a href="{Tinwin c:ADMIN_URL}skin"><span>{Tinwin $Lang['webmenu']['SkinManage']}</span></a></li>
                    <li><a href="{Tinwin c:ADMIN_URL}file-clear"><span>{Tinwin $Lang['webmenu']['Clear']}</span></a></li>
                </ul>
            </li>
            <li>
                <a class="navtitle" href="#"><i class="iconfont icon-liebiao1"></i>{Tinwin $Lang['webmenu']['Content']} <span class="nav-badge"></span> <span class="nav-more glyphicon glyphicon-chevron-right"></span></a>
                <ul class="collapse">        
                    <li><a href="{Tinwin c:ADMIN_URL}article"><span>{Tinwin $Lang['webmenu']['ArticleAll']}</span></a></li>
                    <li><a href="{Tinwin c:ADMIN_URL}category"><span>{Tinwin $Lang['webmenu']['Category']}</span></a></li>
                    <li><a href="{Tinwin c:ADMIN_URL}search-keywordslist"><span>{Tinwin $Lang['webmenu']['Search']}</span></a></li>
                    <li><a href="{Tinwin c:ADMIN_URL}tags"><span>{Tinwin $Lang['webmenu']['Tags']}</span></a></li>
                    <li><a href="{Tinwin c:ADMIN_URL}jiaodiantu"><span>{Tinwin $Lang['webmenu']['Jiaodiantu']}</span></a></li>
                </ul>
            </li>
            <li>
                <a class="navtitle" href="#"><i class="iconfont icon-tuandui"></i>{Tinwin $Lang['webmenu']['User']} <span class="nav-badge"></span> <span class="nav-more glyphicon glyphicon-chevron-right"></span></a>
                <ul class="collapse">        
                    <li><a href="{Tinwin c:ADMIN_URL}user-manage"><span>{Tinwin $Lang['webmenu']['UserManage']}</span></a></li>
                    <li><a href="{Tinwin c:ADMIN_URL}user-loginlog"><span>{Tinwin $Lang['webmenu']['LoginLog']}</span></a></li>
                </ul>
            </li>
            <li>
                <a class="navtitle" href="#"><i class="iconfont icon-fuwuqi"></i>{Tinwin $Lang['webmenu']['DataManage']} <span class="nav-badge"></span> <span class="nav-more glyphicon glyphicon-chevron-right"></span></a>
                <ul class="collapse">        
                    <li><a href="{Tinwin c:ADMIN_URL}data-index"><span>{Tinwin $Lang['webmenu']['Backup']}</span></a></li>
                    <li><a href="{Tinwin c:ADMIN_URL}data-backuplist"><span>{Tinwin $Lang['webmenu']['Restore']}</span></a></li>
                </ul>
            </li>
            <li>
                <a class="navtitle" href="#"><i class="iconfont icon-tool"></i>{Tinwin $Lang['webmenu']['Seo']} <span class="nav-badge"></span> <span class="nav-more glyphicon glyphicon-chevron-right"></span></a>
                <ul class="collapse">        
                    <li><a href="{Tinwin c:ADMIN_URL}seo-enterurl"><span>{Tinwin $Lang['webmenu']['SeoEnterUrl']}</span></a></li>
                    <li><a href="{Tinwin c:ADMIN_URL}seo-all"><span>{Tinwin $Lang['webmenu']['SeoAll']}</span></a></li>
                    <li><a href="{Tinwin c:ADMIN_URL}seo-whois"><span>{Tinwin $Lang['webmenu']['SeoWhois']}</span></a></li>
                    <li><a href="{Tinwin c:ADMIN_URL}seo-friendlink"><span>{Tinwin $Lang['webmenu']['SeoFriendlink']}</span></a></li>
                </ul>
            </li>
        </ul>
    </nav>
</div>

