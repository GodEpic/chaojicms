<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
<link rel="stylesheet" type="text/css" href="{Tinwin c:PLUGIN_PATH}bootstrap/bootstrap-fileinput.css">
<script type="text/javascript" src="{Tinwin c:PLUGIN_PATH}bootstrap/bootstrap-fileinput.js"></script>
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li><a href="{Tinwin c:ADMIN_URL}jiaodiantu-index">{Tinwin $Lang['common']['NavCategory']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
    	{Tinwin include:category_nav}
    </div>    
	<div class="maininfo">
		<form action="{Tinwin $FormAction}" onSubmit="return CheckForm(this)" name="mainform" enctype="multipart/form-data" method="post">
			<div id="myTabContent" class="tab-content w100">
				<input type="hidden" name="input_token" value="{Tinwin $input_token}">
				<input type="hidden" name="OldInput" value="{Tinwin $OldInput}" id="OldInput">
				<div class="form-group row" id="uploadForm" enctype='multipart/form-data'>
	                <label class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['Img']}</label>
	                <div class="col-sm-6 fileinput fileinput-new" data-provides="fileinput"  id="exampleInputUpload">
	                    <div class="fileinput-new thumbnail">
	                    	{Tinwin if $ListOne['img']==""}
	                        <img id='picImg' src="{Tinwin c:STATIC_PATH}images/noimage.png" />
	                        {Tinwin else}
							<img id='picImg' src="{Tinwin $ListOne['img']}" />
							{Tinwin endif}
	                    </div>
	                    <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px;"></div>
	                    <div>
	                        <span class="btn btn-primary btn-file">
	                            <span class="fileinput-new">{Tinwin $Lang['form']['ImgSelect']}</span>
	                            <span class="fileinput-exists">{Tinwin $Lang['form']['ImgChange']}</span>
	                            <input type="file" name="file" id="file" accept="image/gif,image/jpeg,image/x-png">
	                        </span>
	                        <a href="javascript:;" class="btn btn-warning fileinput-exists" data-dismiss="fileinput">{Tinwin $Lang['form']['ImgDel']}</a>
	                    </div>
	                </div>
	            </div>
				<div class="form-group row">
					<label class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['Inrow']}</label>
					<div class="col-sm-6">
						<input type="number" class="form-control" name="dsw[inrow]" maxlength="5" placeholder="{Tinwin $Lang['form']['InrowTips']}" value="{Tinwin $ListOne['inrow']}" min="0" max="99999" step="1" >
					</div>
                    <div class="col-sm-3">{Tinwin $Lang['form']['InrowTips']}</div>
				</div>
				<div class="form-group row">
					<label class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['LinkUrlLabel']}</label>
					<div class="col-sm-4">
						<input type="text" class="form-control" name="dsw[linkurl]" maxlength="250" placeholder="{Tinwin $Lang['form']['LinkUrlLabelTips']}" value="{Tinwin $ListOne['linkurl']}">
					</div>
				</div>
				<div class="form-group row">
					<label class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['IsView']}</label>
					<div class="col-sm-6">
						<select name="dsw[isview]" class="form-control">
							{Tinwin if $ListOne['isview']==1}
							<option value="0">{Tinwin $Lang['form']['NoView']}</option>
							<option value="1" selected>{Tinwin $Lang['form']['YesView']}</option>
							{Tinwin else}
							<option value="0" selected>{Tinwin $Lang['form']['NoView']}</option>
							<option value="1">{Tinwin $Lang['form']['YesView']}</option>
							{Tinwin endif}
						</select>
					</div>
				</div>
			</div>
			<div class="form-group row">
				<label for="psd2" class="col-sm-3 control-label"></label>
				<div class="col-sm-6">
					<button type="submit" class="btn btn-default">{Tinwin $Lang['form']['SaveButton']}</button>
				</div>
			</div>
		</div>
	</form>
</div>
</div>
<script type="text/javascript">
function CheckForm() {  
	var obj = document.getElementById('file');  
	if (obj.value != ''){
        var stuff = obj.value.substr(obj.value.length-3, 3);  
        if (stuff!='jpg'&&stuff!='png'&&stuff!='jpeg'&&stuff!='gif') {  
            alert('{Tinwin $Lang['form']['ImgUploadTips']}');  
            return false;
        }
    }
	return true;
}
</script>
{Tinwin include:footer}
