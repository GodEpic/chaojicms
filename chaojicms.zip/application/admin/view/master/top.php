<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
<!DOCTYPE html>
<html>
<head>
{Tinwin include:header}
</head>
<body>
<div class="top">
    <div class="logo fl"><a href="{Tinwin c:ADMIN_URL}index"><span>超级</span>CMS</a></div>
    <div class="search fl">
        <form action="{Tinwin c:ADMIN_URL}search-manage" method="post">
            <input type="text" name="searchkeywords" class="fl"  placeholder="{Tinwin $Lang['website']['SearchTips']}" required>
            <button class="fl" name="searchbutton" id="submit" type="submit">{Tinwin $Lang['website']['SearchButton']}</button>
        </form>
    </div>
    <div class="topnav fr">
        <dt>
            <a href="{Tinwin c:ADMIN_URL}webset-setlang&langname=cn">中文简体</a>
            <a href="{Tinwin c:ADMIN_URL}webset-setlang&langname=en">English</a>
        </dt>
        <dd>
            <a href="#"> {Tinwin $Lang['website']['Welcome']}：<?php echo $_SESSION['tinwinsession']['username'];?></a>
            <a href="#" onclick='dswfirm("{Tinwin c:ADMIN_URL}login-loginout","{Tinwin $Lang['website']['LogoutTips']}")'>{Tinwin $Lang['website']['Logout']}</a>
            <a href="{Tinwin c:ADMIN_URL}user-edit">{Tinwin $Lang['website']['EditProfile']}</a>
            <a href="http://www.chaojicms.com" target="_blank">{Tinwin $Lang['website']['OfficialWebsite']}</a>
            <a href="{Tinwin c:SITE_WEB}" target="_blank">{Tinwin $Lang['website']['FrontPage']}</a>
        </dd>
    </div>
</div>