<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
<div class="menu title">
    <ul>
        <li><a href="{Tinwin c:ADMIN_URL}category"><span class="glyphicon glyphicon-list"></span><span>{Tinwin $Lang['nav']['List']}</span></a></li>
        <li><a href="{Tinwin c:ADMIN_URL}category-add"><span class="glyphicon glyphicon-plus"></span><span>{Tinwin $Lang['nav']['Add']}</span></a></li>
        <li><a href="{Tinwin c:ADMIN_URL}article"><span class="glyphicon glyphicon-list"></span><span>{Tinwin $Lang['nav']['ArticleList']}</span></a></li>
        <li><a href="{Tinwin c:ADMIN_URL}article-add"><span class="glyphicon glyphicon-plus"></span><span>{Tinwin $Lang['nav']['ArticleAdd']}</span></a></li>
        <li><a href="{Tinwin c:ADMIN_URL}search-keywordslist"><span class="glyphicon glyphicon-list"></span><span>{Tinwin $Lang['nav']['SearchRecord']}</span></a></li>
        <li><a href="{Tinwin c:ADMIN_URL}tags"><span class="glyphicon glyphicon-list"></span><span>{Tinwin $Lang['nav']['TagLabel']}</span></a></li>
        <li><a href="{Tinwin c:ADMIN_URL}jiaodiantu"><span class="glyphicon glyphicon-list"></span><span>{Tinwin $Lang['nav']['Jiaodiantu']}</span></a></li>
        <li><a href="{Tinwin c:ADMIN_URL}jiaodiantu-add"><span class="glyphicon glyphicon-plus"></span><span>{Tinwin $Lang['nav']['JiaodiantuAdd']}</span></a></li>
    </ul>
</div>