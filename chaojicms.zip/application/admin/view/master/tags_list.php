<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
	</div>
	<div class="mainform">
        {Tinwin include:category_nav}
    </div>    
	<div class="maininfo">
		<form action="{Tinwin $FormAction}" method="post">
		<table class="table">
			<thead>
				<tr>
					<td>{Tinwin $Lang['index']['Select']}</td>
					<td>ID</td>
					<td>{Tinwin $Lang['index']['Label']}</td>
					<td>{Tinwin $Lang['index']['ArticleIds']}</td>
					<td colspan="2">{Tinwin $Lang['index']['Operation']}</td>
				</tr>
			</thead>
			<tbody>
				{Tinwin if $ListAll['data']}
				{Tinwin tree $ListAll['data'],myList,cid}
				<tr>
					<td><input type="checkbox" name="SelectCheckbox[]" value="{Tinwin v:myList['tag_id']}"></td>
					<td>{Tinwin v:myList['tag_id']}</td>
					<td>{Tinwin v:myList['tag_label']}</td>
					<td>{Tinwin v:myList['tag_article']}</td>
					<td><a class="glyphicon glyphicon-edit" href="{Tinwin c:ADMIN_URL}tags-edit&id={Tinwin v:myList['tag_id']}"></a></td>
					<td><a class="glyphicon glyphicon-remove" href="#" onclick='dswfirm("{Tinwin c:ADMIN_URL}tags-del&id={Tinwin v:myList['tag_id']}","{Tinwin $Lang['index']['DelTips']}")'></a>
						</td>
				</tr>
				{Tinwin endtree}
				{Tinwin endif}
			</tbody>
		</table>
		<div class="">
			<a onClick="choiceAll(this)" style="cursor:pointer;" class="btn btn-default">{Tinwin $Lang['index']['ChoiceAll']}</a> 
			<a style="cursor:pointer;" onClick="unSelect(this)" class="btn btn-default">{Tinwin $Lang['index']['UnSelect']}</a> 
			<a style="cursor:pointer;" onClick="choiceReverse(this)" class="btn btn-default">{Tinwin $Lang['index']['ChoiceReverse']}</a>
			<button type="submit" class="btn btn-primary">{Tinwin $Lang['index']['Submit']}</button>
		</div>
		</form>
		<div class="page"><section><ul>{Tinwin $ListAll['pages']}</ul></section></div>
	</div>
</div>
{Tinwin include:footer}
