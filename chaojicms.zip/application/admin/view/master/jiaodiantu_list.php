<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
        {Tinwin include:category_nav}
    </div>    
	<div class="maininfo jiaodiantu">
		{Tinwin if $ListAll['data']}
		{Tinwin tree $ListAll['data'],mylist,myid}
		<dl>
			<dt><img src="{Tinwin v:mylist['img']}"></dt>
			<dd><a href="{Tinwin c:MyAppUrl}jiaodiantu-edit&id={Tinwin v:mylist['id']}">编辑</a> 
				<a href="{Tinwin c:MyAppUrl}jiaodiantu-del&id={Tinwin v:mylist['id']}">删除</a>
				<a href="#" onClick="DisplayOK(this)" id="{Tinwin c:MyAppUrl}jiaodiantu-isview&id={Tinwin v:mylist['id']}" style="cursor:pointer;">
					{Tinwin if v:mylist['isview']==1}		
						{Tinwin $Lang['form']['YesView']}
					{Tinwin else}
						{Tinwin $Lang['form']['NoView']}
					{Tinwin endif}
				</a>
			</dd>
		</dl>
		{Tinwin endtree}
		{Tinwin endif}
	</div>
</div>
{Tinwin include:footer}