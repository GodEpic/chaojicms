<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
<link rel="stylesheet" type="text/css" href="{Tinwin c:PLUGIN_PATH}bootstrap/bootstrap-fileinput.css">
<script type="text/javascript" charset="utf-8" src="{Tinwin c:PLUGIN_PATH}ueditor/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="{Tinwin c:PLUGIN_PATH}ueditor/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="{Tinwin c:PLUGIN_PATH}ueditor/lang/zh-cn/zh-cn.js"></script>
<script type="text/javascript" src="{Tinwin c:PLUGIN_PATH}bootstrap/bootstrap-fileinput.js"></script>
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li><a href="{Tinwin c:MyAppUrl}article">{Tinwin $Lang['common']['ArticleManage']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
    	{Tinwin include:category_nav}
    </div>    
	<div class="maininfo">
		<form action="{Tinwin $FormAction}" onSubmit="return CheckForm(this)" enctype="multipart/form-data" method="post" class="container-fluid">
			<ul id="myTab" class="nav nav-tabs">
				<li class="active"><a href="#basic" data-toggle="tab">{Tinwin $Lang['common']['Basic']}</a></li>
				<li><a href="#seo" data-toggle="tab">{Tinwin $Lang['common']['Seo']}</a></li>
				<li><a href="#other" data-toggle="tab">{Tinwin $Lang['common']['Other']}</a></li>
			</ul>
	        <div id="myTabContent" class="tab-content">
				<div class="tab-pane fade in active" id="basic" style="margin-top: 20px;">
					<input type="hidden" name="input_token" value="{Tinwin $input_token}">				
					<div class="form-group row">
						<label class="col-sm-2 control-label text-right">{Tinwin $Lang['form']['Title']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" id="STitle" name="dsw[title]" placeholder="{Tinwin $Lang['form']['TitleTips']}" required value="{Tinwin $ListOne['title']}"  onblur="CheckTitle()" >
						</div>
						<div class="col-sm-3" id="LoadCheckTitle"></div>
					</div>
					<div class="form-group row">
						<label class="col-sm-2 control-label text-right">{Tinwin $Lang['form']['CatName']}</label>
						<div class="col-sm-6">
							{Tinwin if $CatTree}
								<select name="dsw[cat_id]" class="form-control">
									{Tinwin tree $CatTree,myList,myid}
										{Tinwin if v:myList['id']==$ListOne['cat_id']}
											<option value="{Tinwin v:myList['id']}" selected>{Tinwin v:myList['cat_name']}
											</option>
										{Tinwin else}
											<option value="{Tinwin v:myList['id']}">
											{Tinwin v:myList['cat_name']}
											</option>
										{Tinwin endif}	
									{Tinwin endtree}
								</select>
							{Tinwin endif}
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-2 control-label text-right">{Tinwin $Lang['form']['Content']}</label>
						<div class="col-sm-10">
							<script name="dsw[content]" id="editor" type="text/plain" style="width:800px;height:300px;">{Tinwin realhtml:$ListOne['content']}</script>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-2 control-label text-right">{Tinwin $Lang['form']['Inrow']}</label>
						<div class="col-sm-6">
							<input type="number" class="form-control" name="dsw[inrow]" maxlength="5" placeholder="{Tinwin $Lang['form']['InrowTips']}" value="{Tinwin $ListOne['inrow']}" min="0" max="99999" step="1" >
						</div>
	                    <div class="col-sm-3">{Tinwin $Lang['form']['InrowTips']}</div>
					</div>
					<div class="form-group row" id="uploadForm" enctype='multipart/form-data'>
		                <label class="col-sm-2 control-label text-right">{Tinwin $Lang['form']['Img']}</label>
		                <div class="col-sm-6 fileinput fileinput-new" data-provides="fileinput"  id="exampleInputUpload">
		                    <div class="fileinput-new thumbnail">
		                    	{Tinwin if $ListOne['img']==""}
		                        <img id='picImg' src="{Tinwin c:STATIC_PATH}images/noimage.png" />
		                        {Tinwin else}
								<img id='picImg' src="{Tinwin $ListOne['img']}" />
								{Tinwin endif}
		                    </div>
		                    <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px;"></div>
		                    <div>
		                        <span class="btn btn-primary btn-file">
		                            <span class="fileinput-new">{Tinwin $Lang['form']['ImgSelect']}</span>
		                            <span class="fileinput-exists">{Tinwin $Lang['form']['ImgChange']}</span>
		                            <input type="file" name="file" id="file" accept="image/gif,image/jpeg,image/x-png">
		                        </span>
		                        <a href="javascript:;" class="btn btn-warning fileinput-exists" data-dismiss="fileinput">{Tinwin $Lang['form']['ImgDel']}</a>
		                    </div>
		                </div>
		                <div class="col-sm-4">{Tinwin $Lang['form']['ImgTips']}</div>
		            </div>
				</div>
				<div class="tab-pane fade in" id="seo" style="margin-top: 20px;">
					<div class="form-group row">
						<label class="col-sm-2 control-label text-right">{Tinwin $Lang['form']['SeoTitle']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[seo_title]" maxlength="80" placeholder="{Tinwin $Lang['form']['SeoTitleTips']}" value="{Tinwin $ListOne['seo_title']}">
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-2 control-label text-right">{Tinwin $Lang['form']['SeoKeywords']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[seo_keywords]" maxlength="200" placeholder="{Tinwin $Lang['form']['SeoKeywordsTips']}" value="{Tinwin $ListOne['seo_keywords']}">
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-2 control-label text-right">{Tinwin $Lang['form']['SeoDescription']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[seo_description]" maxlength="200" placeholder="{Tinwin $Lang['form']['SeoDescriptionTips']}" value="{Tinwin $ListOne['seo_description']}">
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-2 control-label text-right">{Tinwin $Lang['form']['SeoTags']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[seo_tags]" maxlength="200" placeholder="{Tinwin $Lang['form']['SeoTagsTips']}" value="{Tinwin $ListOne['seo_tags']}">
						</div>
					</div>
				</div>
				<div class="tab-pane fade in" id="other" style="margin-top: 20px;">
	                <div class="form-group row">
						<label class="col-sm-2 control-label text-right">{Tinwin $Lang['form']['View']}</label>
						<div class="col-sm-6">
	                        <input type="number" class="form-control" name="dsw[view]" maxlength="10" placeholder="{Tinwin $Lang['form']['ViewTips']}" value="{Tinwin $ListOne['view']}" min="0" max="99999" step="1" >
						</div>
					</div>
	                <div class="form-group row">
						<label class="col-sm-2 control-label text-right">{Tinwin $Lang['form']['Addtime']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[addtime]" value="{Tinwin if $ListOne['addtime']}{Tinwin date:$ListOne['addtime'],'Y-m-d H:i:s'}{Tinwin else}<?php echo date("Y-m-d H:i:s")?>{Tinwin endif}">
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-2 control-label text-right">{Tinwin $Lang['form']['OutFrom']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[out_from]" maxlength="30"  value="{Tinwin $ListOne['out_from']}">
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-2 control-label text-right">{Tinwin $Lang['form']['OutUrl']}</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="dsw[out_url]" maxlength="200" placeholder="{Tinwin $Lang['form']['OutUrlTips']}" value="{Tinwin $ListOne['out_url']}">
						</div>
					</div>
				</div>
				<div class="form-group row">
					<label for="psd2" class="col-sm-2 control-label"></label>
					<div class="col-sm-6">
						<button type="submit" class="btn btn-default">{Tinwin $Lang['form']['SaveButton']}</button>
					</div>
				</div>
			</div>
		</form>
	</div>
</div>
<script type="text/javascript">
function CheckForm() {  
	var obj = document.getElementById('file');  
	if (obj.value != ''){ 
        var stuff = obj.value.substr(obj.value.length-3, 3);  
        if (stuff!='jpg'&&stuff!='png'&&stuff!='jpeg'&&stuff!='gif') {  
            alert('{Tinwin $Lang['form']['ImgUploadTips']}');  
            return false;
        }
    }
	return true;
}
function CheckTitle(){
	var x=document.getElementById("STitle");
	$('#LoadCheckTitle').load("{Tinwin c:ADMIN_URL}article-CheckTitle&id={Tinwin if $ListOne['id']}{Tinwin $ListOne['id']}{Tinwin else}0{Tinwin endif}&STitle="+x.value);
};
</script>
{Tinwin include:ueditor}
{Tinwin include:footer}
