<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
    	<div class="menu title">
		    <ul>
		        <li><a href="{Tinwin c:MyAppUrl}user-loginlog"><span class="glyphicon glyphicon-ok"></span><span>{Tinwin $Lang['loginnav']['loginlog']}</span></a></li>
		        <li><a href="{Tinwin c:MyAppUrl}user-loginlogno"><span class="glyphicon glyphicon-remove"></span><span>{Tinwin $Lang['loginnav']['loginlogno']}</span></a></li>
		    </ul>
		</div>
    </div>    
	<div class="maininfo">
		<table class="table">
			<thead>
				<tr>
					<td>ID</td>
					<td>{Tinwin $Lang['logintable']['Username']}</td>
					<td>{Tinwin $Lang['logintable']['LoginTime']}</td>
					<td>{Tinwin $Lang['logintable']['LoginIp']}</td> 
					<td>{Tinwin $Lang['logintable']['Del']}</td>
				</tr>
			</thead>
			<tbody>
				{Tinwin tree $ListAll['data'],myList,myid}
				<tr>
					<td>{Tinwin v:myList['id']}</td>
					<td>{Tinwin v:myList['username']}</td>
					<td>{Tinwin date:v:myList['addtime'],"Y-m-d H:i:s"}</td>
					<td>{Tinwin v:myList['login_ip']}</td>
					<td><a class="glyphicon glyphicon-remove" href="#" onclick='dswfirm("{Tinwin c:ADMIN_URL}user-logindel&id={Tinwin v:myList['id']}","{Tinwin $Lang['logintable']['DelTips']}")'></a></td>
				</tr>
				{Tinwin endtree}
			</tbody>
		</table>
		<div class="page"><section><ul>{Tinwin $ListAll['pages']}</ul></section></div>
	</div>
</div>
{Tinwin include:footer}
