<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
<div class="menu title">
    <ul>
        <li><a href="{Tinwin c:MyAppUrl}navmenu-group"><span class="glyphicon glyphicon-list"></span><span>{Tinwin $Lang['nav']['GroupManage']}</span></a></li>
        <li><a href="{Tinwin c:MyAppUrl}navmenu-addgroup"><span class="glyphicon glyphicon-plus"></span><span>{Tinwin $Lang['nav']['AddGroup']}</span></a></li>
        <li><a href="{Tinwin c:MyAppUrl}navmenu-manage"><span class="glyphicon glyphicon-list"></span><span>{Tinwin $Lang['nav']['MenuList']}</span></a></li>
        <li><a href="{Tinwin c:MyAppUrl}navmenu-add"><span class="glyphicon glyphicon-plus"></span><span>{Tinwin $Lang['nav']['AddMenu']}</span></a></li>
    </ul>
</div>