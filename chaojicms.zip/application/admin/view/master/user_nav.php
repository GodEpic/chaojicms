<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
<div class="menu title">
    <ul>
        <li><a href="{Tinwin c:MyAppUrl}user-index"><span class="glyphicon glyphicon-list"></span><span>{Tinwin $Lang['nav']['UserManage']}</span></a></li>
        <li><a href="{Tinwin c:MyAppUrl}user-add"><span class="glyphicon glyphicon-plus"></span><span>{Tinwin $Lang['nav']['AddUser']}</span></a></li>
    </ul>
</div>