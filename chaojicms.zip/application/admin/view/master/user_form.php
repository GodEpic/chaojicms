<?php !defined('IN_DSW') && exit('大神你要飞呀');?>
{Tinwin include:top}
{Tinwin include:left}
<div class="main">
	<div class="position">
		<ul>
			<li><a href="{Tinwin c:ADMIN_URL}index">{Tinwin $Lang['common']['Home']}</a></li>
			<li>/</li>
			<li>{Tinwin $FormTitle}</li>
		</ul>
    </div>
    <div class="mainform">
        {Tinwin include:user_nav}
    </div>    
	<div class="maininfo">
		<form action="{Tinwin $FormAction}" method="post" class="container-fluid">
			<input type="hidden" name="input_token" value="{Tinwin $input_token}">
			<div class="form-group row" style="padding-top:20px;">
				<label for="username" class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['Username']}</label>
				<div class="col-sm-6">
					{Tinwin if $ListOne['username']}
					<input type="text" class="form-control readonly" readonly name="dsw[username]"  value="{Tinwin $ListOne['username']}">
					{Tinwin else}
					<input type="text" class="form-control" name="dsw[username]" placeholder="{Tinwin $Lang['form']['UsernameTips']}" required value="">
					{Tinwin endif}
				</div>
			</div>
			<div class="form-group row">
				<label for="nickname" class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['Nickname']}</label>
				<div class="col-sm-6">
					<input type="text" class="form-control" name="dsw[nickname]" placeholder="{Tinwin $Lang['form']['NicknameTips']}" required value="{Tinwin $ListOne['nickname']}" >
				</div>
			</div>
			<div class="form-group row">
				<label for="psd" class="col-sm-3 control-label text-right">{Tinwin $Lang['form']['Psd']}</label>
				<div class="col-sm-6">
					{Tinwin if $ListOne['psd']}
					<input type="text" class="form-control" name="dsw[psd]" placeholder="{Tinwin $Lang['form']['PsdEditTips']}" value="" >
					{Tinwin else}
					<input type="text" class="form-control" name="dsw[psd]" placeholder="{Tinwin $Lang['form']['PsdAddTips']}" required value="" >
					{Tinwin endif}
				</div>
			</div>
			<div class="form-group row">
				<label for="psd2" class="col-sm-3 control-label"></label>
				<div class="col-sm-6">
					<button type="submit" class="btn btn-default">{Tinwin $Lang['form']['Submit']}</button>
				</div>
			</div>
		</form>
	</div>
</div>
{Tinwin include:footer}
