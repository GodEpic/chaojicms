<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间:2018-05-08
 * 作者:牛哥 tinwin@vip.qq.com
 * 说明:SEO研究中心特色模块 更多优化资料参考bbs.moonseo.cn
 * 
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}

    //SEO综合信息查询
	private function index(){
		$Lang=$this->G->loadLang();
		$this->tpl->assign('Lang',$Lang);
        $this->tpl->display('seo_index');
	}
    
	//SEO综合信息查询
	private function all(){
		$Lang=$this->G->loadLang();
		$url = SoftUrl."/index.php?api-get-seo-index&user=".SoftUser."&token=".SoftToken."&url=".SITE_WEB;
		$data=$this->tinwin->GetWebContent($url,3);
		$DataList=json_decode($data,true);
		if($DataList['status']=='success'){
			$this->tpl->assign('FormTitle',$Lang['all']['FormTitle']);
			$this->tpl->assign('DataList',$DataList['data']);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('seo_all');
		}else{
            $message = array(
				'statusCode' =>300,
				"message" => "错误代码:".$DataList['code'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."seo-index"
			);
			$this->G->R($message);
        }
	}

    //SEO综合信息查询 更新
	private function update(){
		$Lang=$this->G->loadLang();
		$url = SoftUrl."/index.php?api-get-seo-update&user=".SoftUser."&token=".SoftToken."&url=".SITE_WEB;
		$data=$this->tinwin->GetWebContent($url,3);
		$DataList=json_decode($data,true);
		if($DataList['status']=='success'){
			$this->tpl->assign('FormTitle',$Lang['all']['FormTitle']);
			$this->tpl->assign('DataList',$DataList['data']);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('seo_all');
		}else{
            $message = array(
				'statusCode' =>300,
				"message" => "错误代码:".$DataList['code'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."seo-index"
			);
			$this->G->R($message);
        }
	}
    
	//获取搜索引擎入口网址
	private function enterurl(){
		$Lang=$this->G->loadLang();
		$url = SoftUrl."/index.php?api-get-seo-enterurl&user=".SoftUser."&token=".SoftToken."&url=".SITE_WEB;
		$data=$this->tinwin->GetWebContent($url,3);
		$DataList=json_decode($data,true);
		if($DataList['status']=='success'){
			$this->tpl->assign('FormTitle',$Lang['enterurl']['FormTitle']);
			$this->tpl->assign('DataList',$DataList['data']);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('seo_enterurl');
		}else{
            $message = array(
				'statusCode' =>300,
				"message" => "错误代码".$DataList['code'].$DataList['status'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."seo-index"
			);
			$this->G->R($message);
        }
	}

	//获取域名详细信息
	private function doamin(){
		$Lang=$this->G->loadLang();
		$url = SoftUrl."/index.php?api-get-seo-domain&user=".SoftUser."&token=".SoftToken."&url=".SITE_WEB;
		$data=$this->tinwin->GetWebContent($url,3);
		$DataList=json_decode($data,true);
		if($DataList['status']=='success'){
			$this->tpl->assign('FormTitle',$Lang['doamin']['FormTitle']);
			$this->tpl->assign('DataList',$DataList['data']);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('seo_enterurl');
		}else{
            $message = array(
				'statusCode' =>300,
				"message" => "错误代码".$DataList['code'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."seo-index"
			);
			$this->G->R($message);
        }
	}

	//友链检测
	private function friendlink(){
		$Lang=$this->G->loadLang();
		$isInstall=$this->apps->getOneByName('links');
		if($isInstall){
			$slist=$this->G->loadclass('friendlink','links')->getAllIsView();
			foreach($slist as $k=>$v){
				$data=$this->tinwin->GetWebContent($v['link_url'],3);
				$result[$k]['url']=$v['link_url'];
				if($data){
					$islink=strpos($data,SITE_URL);
					if($islink){
						$result[$k]['info']=$Lang['friendlink']['IsLink'];
					}else{
						$result[$k]['info']=$Lang['friendlink']['NotLink'];
					}
				}else{					
					$result[$k]['info']=$Lang['friendlink']['WebBreak'];
				}
			}
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['friendlink']['AppNotInstall'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."seo-index"
			);
			$this->G->R($message);
		}
		$this->tpl->assign('FormTitle',$Lang['friendlink']['FormTitle']);
		$this->tpl->assign('DataList',$result);
		$this->tpl->assign('Lang',$Lang);
		$this->tpl->display('seo_friendlink');
	}
	
  //   //增加外链 2018-06-14
  //   private function outlink(){
		// $url = SoftUrl."/index.php?api-get-seo-outlink&user=".SoftUser."&token=".SoftToken."&url=".SITE_URL;
		// $data=$this->tinwin->GetWebContent($url,3);
		// $DataList=json_decode($data,ture);
		// if($DataList['status']=='success'){
		// 	$this->tpl->assign('FormTitle','增加外链');
		// 	$this->tpl->assign('DataList',$DataList['data']);
		// 	$this->tpl->display('seo_outlink');
		// }else{
  //           $message = array(
		// 		'statusCode' =>300,
		// 		"message" => "错误代码".$DataList['code'],
		// 		"callbackType" =>'forward',
		// 		"forwardUrl" =>ADMIN_URL."seo-index"
		// 	);
		// 	$this->G->R($message);
  //       }
  //   }

    /**
     * 功能：查询域名whois
     * 作者：牛哥 tinwin@vip.qq.com
     * 时间：2018-10-13 09：43
     */
    private function whois(){
    	$Lang=$this->G->loadLang();
    	$url='http://www.niuguwen.cn/index.php?whois-web-index-loadwhois&domain='.SITE_WEB.'&url='.SITE_URL;
    	$data=$this->tinwin->GetWebContent($url,3);
    	$this->tpl->assign('DataList',$data);
    	$this->tpl->assign('Lang',$Lang);
    	$this->tpl->display('seo_whois');
    }
}
?>
