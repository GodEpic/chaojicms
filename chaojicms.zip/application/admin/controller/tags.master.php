<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：2018-02-27
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：tag标签模块
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}

	private function index(){
		$Lang=$this->G->loadLang();
		$page = $this->routes->get('page');
		$page = $page>0?$page:1;
		$ListAll=$this->tags->getList($page,10);
		$this->tpl->assign("FormTitle",$Lang['index']['FormTitle']);		
		$this->tpl->assign('ListAll',$ListAll);
		$this->tpl->assign('FormAction',ADMIN_URL.'tags-dels');
		$this->tpl->assign('Lang',$Lang);
		$this->tpl->display('tags_list');
	}
	
	private function del(){
		$Lang=$this->G->loadLang();
		$IntID=$this->routes->get('id');
		$this->tags->del($IntID);
		$message = array(
			'statusCode' =>200,
			"message" => $Lang['del']['DelSuccess'],
			"callbackType" =>'forward',
			"forwardUrl" =>ADMIN_URL."tags"
		);
		$this->G->R($message);
	}

	private function edit(){
		$Lang=$this->G->loadLang();
		$IntID=$this->routes->get('id');
		if($_SESSION['input_token']!="" && $_SESSION['input_token']==$_POST['input_token']){
			$_SESSION['input_token']='';
			$tag_label =$this->routes->post('tag_label');
			if(!empty($tag_label)){
				$check=$this->tags->CheckTag($IntID,$tag_label);
				//var_dump($check);
				if(!$check){
					$s=$this->tags->updateTag(array('tag_label'=>$tag_label),array('tag_id'=>$IntID));
					if($s){
						$message = array(
							'statusCode' =>200,
							"message" => $Lang['edit']['EditSuccess'],
							"callbackType" =>'forward',
							"forwardUrl" =>ADMIN_URL."tags"
						);
						$this->G->R($message);	
					}else{
						$message = array(
							'statusCode' =>200,
							"message" => $Lang['edit']['EditNot'],
							"callbackType" =>'forward',
							"forwardUrl" =>ADMIN_URL."tags"
						);
						$this->G->R($message);
					}
				}else{
					$message = array(
						'statusCode' =>200,
						"message" => $Lang['edit']['EditFail'],
						"callbackType" =>'forward',
						"forwardUrl" =>ADMIN_URL."tags"
					);
					$this->G->R($message);	
				}
			}
		}else{
			$ListOne=$this->tags->getTagByID($IntID);
			$_SESSION['input_token'] = md5(rand(100,1000));
			$this->tpl->assign("input_token",$_SESSION['input_token']);
			$this->tpl->assign('FormTitle',$Lang['edit']['FormTitle']);
			$this->tpl->assign('ListOne',$ListOne);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('tags_form');
		}

	}

	//删除多条记录
	private function dels(){
		$Lang=$this->G->loadLang();
		$SelectCheckbox = $_POST['SelectCheckbox'];
		if(is_array($SelectCheckbox)){
			foreach($SelectCheckbox as $value){
				$this->tags->del($value);
			}
			$message = array(
				'statusCode' =>200,
				"message" => $Lang['dels']['DelSuccess'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."tags"
			);
			$this->G->R($message);			
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['dels']['NotSelect'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."tags"
			);
			$this->G->R($message);
		}
	}
}
?>
