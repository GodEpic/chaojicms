<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 作者:牛哥 tinwin@vip.qq.com
 * 说明:数据备份与还原
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}

	private function index(){
		$Lang=$this->G->loadLang();
		$ListAll=$this->data->getDatabase();
		if($ListAll){
			foreach ($ListAll as $key => $value) {
				$ListAll[$key]['Data_length']=$this->files->sizecount($value['Data_length']);
			}
			$this->tpl->assign("FormTitle",$Lang['index']['FormTitle']);
			$this->tpl->assign("FormAction",ADMIN_URL.'data-dotype');
			$this->tpl->assign('ListAll',$ListAll);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('data_list');
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['index']['NotDatabase'],
				"callbackType" =>'forward',
				"forwardUrl" => ADMIN_URL."card-add"
			);
			$this->G->R($message);
		}
	}

	private function dotype(){
		$Lang=$this->G->loadLang();
		$SelectCheckbox = $_POST['SelectCheckbox'];
		$dotypeid = $_POST['dotypeid'];
		//$db=implode(',',$SelectCheckbox);
		//var_dump($SelectCheckbox);
		switch ($dotypeid){
			case '1':
				$r=$this->data->backup($SelectCheckbox);
				break;
			case '2':
				$r=$this->data->optimize($SelectCheckbox);
				break;
			case '3':
				$r=$this->data->repair($SelectCheckbox);
				break;
			case '4':
				$r=$this->data->analyze($SelectCheckbox);
				break;
			default:
				echo $Lang['dotype']['NotSelect'];
				break;
		}
		$message = array(
			'statusCode' =>300,
			"message" => $r,
			"callbackType" =>'forward',
			"forwardUrl" => ADMIN_URL."data"
		);
		$this->G->R($message);
	}

	private function fieldlist(){
		$Lang=$this->G->loadLang();
		$Stable=$this->routes->get('stable');
		$ListAll=$this->dbsqli->exec('SHOW FULL FIELDS FROM '.$Stable);
		$this->tpl->assign('ListAll',$ListAll);
		$this->tpl->assign('Stable',$Stable);
		$this->tpl->assign("FormTitle",$Stable.$Lang['fieldlist']['FormTitle']);
		$this->tpl->assign('Lang',$Lang);
		$this->tpl->display('datafield_list');
	}

	//备份数据列表
	private function backuplist(){
		$Lang=$this->G->loadLang();
		$ListAll=$this->data->getBackupList();
		if($ListAll){
			$this->tpl->assign("FormTitle",$Lang['backuplist']['FormTitle']);
			$this->tpl->assign("FormAction",ADMIN_URL.'data-goback');
			$this->tpl->assign('ListAll',$ListAll['file']);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('backup_list');
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['backuplist']['NoRecord'],
				"callbackType" =>'forward',
				"forwardUrl" => ADMIN_URL."data"
			);
			$this->G->R($message);
		}
	}

	//恢复数据
	private function recoverdata(){
		$Lang=$this->G->loadLang();
		$sfile=$this->routes->get('sfile');
		if(is_file(DATA_BACKUP.$sfile)){
			$this->data->import(DATA_BACKUP.$sfile);
			$message = array(
				'statusCode' =>200,
				"message" => $Lang['recoverdata']['RecoverSuccess'],
				"callbackType" =>'forward',
				"forwardUrl" => ADMIN_URL."data"
			);
			$this->G->R($message);
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['recoverdata']['NoFile'],
				"callbackType" =>'forward',
				"forwardUrl" => ADMIN_URL."data"
			);
			$this->G->R($message);
		}
	}

	//删除备份数据
	private function del(){
		$Lang=$this->G->loadLang();
		$sfile=$this->routes->get('sfile');
		if(is_file(DATA_BACKUP.$sfile)){
			$this->files->delFile(DATA_BACKUP.$sfile);
			$message = array(
				'statusCode' =>200,
				"message" => $Lang['del']['DelSuccess'],
				"callbackType" =>'forward',
				"forwardUrl" => ADMIN_URL."data-backuplist"
			);
			$this->G->R($message);
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['del']['NoFile'],
				"callbackType" =>'forward',
				"forwardUrl" => ADMIN_URL."data-backuplist"
			);
			$this->G->R($message);
		}
	}
}
?>
