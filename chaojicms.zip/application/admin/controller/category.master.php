<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 作者:牛哥 tinwin@vip.qq.com
 * 说明:分类栏目管理模块
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "manage";
		$this->$action();
		exit;
	}

	private function manage(){
		$Lang=$this->G->loadLang();
		$IntCid=$this->routes->get('cid');
		if(!$IntCid){
			$IntCid=0;
		}
		$page = intval($this->routes->get('page'));
		$page = $page>0?$page:1;
		$ListAll=$this->category->getList($page,10,array('parent_id'=>$IntCid));
		if($ListAll['data']){
			$this->tpl->assign("FormTitle",$Lang['manage']['FormTitle']);
			$this->tpl->assign("FormAction",'category-add&cid='.$IntCid);
			$this->tpl->assign('ListAll',$ListAll);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('category_list');
		}else{
			$message = array(
				'CodeType' =>300,
				"message" => $Lang['manage']['NotSunCategory'],
				"callbackType" => 'forward',
				"forwardUrl" => ADMIN_URL."category-add&cid=$IntCid"	
			);
			$this->G->R($message);
		}
	}
	
	private function add(){
		$Lang=$this->G->loadLang();
		if($_SESSION['input_token']!="" && $_SESSION['input_token']==$_POST['input_token']){
			$_SESSION['input_token']='';
			$dsw =$_POST['dsw'];
			$Catalog=$dsw['catalog_name'];
			$isnot=$this->category->getOne(array('catalog_name'=>$Catalog));
			if(!$isnot&&$dsw){
                if(is_uploaded_file($_FILES['file']['tmp_name'])){
                    $sfile=$_FILES["file"];
                    $dsw['cat_img']=$this->files->uploadFile($sfile,UPLOAD_PATH_IMG);
                }
				$this->category->save($dsw);
				$message = array(
					'CodeType' =>200,
					"message" => $Lang['add']['AddSuccess'],
					"callbackType" => 'forward',
					"forwardUrl" => ADMIN_URL."category-manage&cid=".$dsw['parent_id']	
				);
				$this->G->R($message);
			}else{
				$message = array(
					'CodeType' =>300,
					"message" => $Lang['add']['CatalogNameRepeat'],
					"callbackType" => 'forward',
					"forwardUrl" => ADMIN_URL."category-manage&cid=".$dsw['parent_id']
				);
				$this->G->R($message);
			}
		}else{
			$ListOne['parent_id']=$this->routes->get('cid');
			$_SESSION['input_token'] = md5(rand(100,1000));
			$this->tpl->assign("input_token",$_SESSION['input_token']);
			$this->tpl->assign("FormTitle",$Lang['add']['FormTitle']);
			$this->tpl->assign("FormAction",ADMIN_URL."category-add");
			$this->tpl->assign("ListOne",$ListOne);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('category_form');
		}
	}

	private function edit(){
		$Lang=$this->G->loadLang();
		$IntID=$this->routes->get('id');
		if($_SESSION['input_token']!="" && $_SESSION['input_token']==$_POST['input_token']){
			$_SESSION['input_token']='';
			$dsw =$_POST['dsw'];
			if($dsw){
                if(is_uploaded_file($_FILES['file']['tmp_name'])){
                    $sfile=$_FILES["file"];
                    $dsw['cat_img']=$this->files->uploadFile($sfile,UPLOAD_PATH_IMG);
                }
				$this->category->update($dsw,array('id'=>$IntID));
				$message = array(
					'CodeType' =>200,
					"message" => $Lang['edit']['EditSuccess'],
					"callbackType" => 'forward',
					"forwardUrl" => ADMIN_URL."category-manage"
				);
				$this->G->R($message);
			}
		}else{
			$ListOne=$this->category->getOneByID($IntID);
			$this->tpl->assign("ListOne",$ListOne);
			$_SESSION['input_token'] = md5(rand(100,1000));
			$this->tpl->assign("input_token",$_SESSION['input_token']);
			$this->tpl->assign("FormTitle",$Lang['edit']['FormTitle']);
			$this->tpl->assign("OldInput",$ListOne['catalog_name']);
			$this->tpl->assign("FormAction",ADMIN_URL."category-edit&id=$IntID");
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('category_form');
		}
	}

	private function isview(){
		$IntID=$this->routes->get('id');
		echo $this->category->isview($IntID);
	}

	private function ismenu(){
		$IntID=$this->routes->get('id');
		echo $this->category->ismenu($IntID);
	}

	private function isindex(){
		$IntID=$this->routes->get('id');
		echo $this->category->isindex($IntID);
	}
	
	private function del(){
		$Lang=$this->G->loadLang();
		$IntID=$this->routes->get('id');
		$sunArt=$this->article->getAll(array('cat_id'=>$IntID));
		$sunCid=$this->category->getSunByCid($IntID);
		if(!$sunCid){
			if(!$sunArt){
				$this->category->del($IntID);
				$message = array(
					'statusCode' =>200,
					"message" => $Lang['del']['DelSuccess'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL."category"
				);
				$this->G->R($message);
			}else{
				$message = array(
					'statusCode' =>300,
					"message" => $Lang['del']['IsArticleInCat'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL."category"
				);
				$this->G->R($message);
			}
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['del']['IsCategoryInCat'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."category"
			);
			$this->G->R($message);
		}	
	}
	
    //检测输入信息
	private function CheckInput(){
		$SInput=$this->routes->get('SInput');
		echo $this->category->getCheckInput($SInput);
	}
}
?>
