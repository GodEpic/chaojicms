<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：2019-01-09
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：焦点图模块
 */
class action extends app{
	public function display(){
		$this->jiaodiantu=$this->G->loadclass('jiaodiantu');
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}

	private function index(){
		$Lang=$this->G->loadLang();
		$page = $this->routes->get('page');
		$page = $page>0?$page:1;
		$ListAll=$this->jiaodiantu->getList($page,5);
		$this->tpl->assign("FormTitle",$Lang['index']['FormTitle']);
		$this->tpl->assign('ListAll',$ListAll);
		$this->tpl->assign('Lang',$Lang);
		$this->tpl->display('jiaodiantu_list');
	}
	
	private function add(){
		$Lang=$this->G->loadLang();
		if($_SESSION['input_token']!="" && $_SESSION['input_token']==$_POST['input_token']){
			$_SESSION['input_token']='';
			$dsw = $this->routes->post('dsw');
			if(is_uploaded_file($_FILES['file']['tmp_name'])){
                $dsw['img']=$this->files->uploadFile($_FILES["file"],UPLOAD_PATH_IMG);
                $this->jiaodiantu->addSave($dsw);
                $message = array(
					'CodeType' =>200,
					"message" => $Lang['operation']['AddSuccess'],
					"callbackType" => 'forward',
					"forwardUrl" => MyAppUrl."jiaodiantu-index"	
				);
				$this->G->R($message);
            }
		}else{
			$_SESSION['input_token'] = md5(rand(100,1000));
			$this->tpl->assign("input_token",$_SESSION['input_token']);
			$this->tpl->assign('FormTitle',$Lang['add']['FormTitle']);
			$this->tpl->assign('FormAction',MyAppUrl.'jiaodiantu-add');
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('jiaodiantu_form');
		}
	}

	private function edit(){
		$Lang=$this->G->loadLang();
		$IntID=$this->routes->get('id');
		if($_SESSION['input_token']!="" && $_SESSION['input_token']==$_POST['input_token']){
			$_SESSION['input_token']='';
			$dsw = $this->routes->post('dsw');
			if(is_uploaded_file($_FILES['file']['tmp_name'])){
                $dsw['img']=$this->files->uploadFile($_FILES["file"],UPLOAD_PATH_IMG);
            }
            $this->jiaodiantu->update($dsw,array('id'=>$IntID));
            $message = array(
				'CodeType' =>200,
				"message" => $Lang['operation']['EditSuccess'],
				"callbackType" => 'forward',
				"forwardUrl" => MyAppUrl."jiaodiantu-index"	
			);
			$this->G->R($message);
		}else{
			$ListOne=$this->jiaodiantu->getOne(array('id'=>$IntID));
			$_SESSION['input_token'] = md5(rand(100,1000));
			$this->tpl->assign("input_token",$_SESSION['input_token']);
			$this->tpl->assign('FormTitle',$Lang['edit']['FormTitle']);
			$this->tpl->assign('ListOne',$ListOne);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('jiaodiantu_form');
		}
	}

	private function del(){
		$Lang=$this->G->loadLang();
		$IntID=$this->routes->get('id');
		$this->jiaodiantu->del($IntID);
		$message = array(
			'statusCode' =>200,
			"message" => $Lang['operation']['DelSuccess'],
			"callbackType" =>'forward',
			"forwardUrl" =>ADMIN_URL."jiaodiantu"
		);
		$this->G->R($message);
	}

	private function isview(){
		$IntID=$this->routes->get('id');
		echo $this->jiaodiantu->isview($IntID);
	}
}
?>
