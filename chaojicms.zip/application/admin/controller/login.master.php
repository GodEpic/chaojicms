<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：2017-10-07
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：后台用户登录控制器
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}
	
	private function index(){
		$Lang=$this->G->loadLang();
		if($_SESSION['tinwinsession']['isadmin']==1){//如果已经登录，无需重复登录
			header("refresh:0;url=".ADMIN_URL."index");
		}else{
			$this->tpl->assign('FormAction',ADMIN_URL."login-checklogin");
			$this->tpl->assign('FormTitle',$Lang['index']['FormTitle']);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('login');
		}		
	}

	private function checklogin(){
		$Lang=$this->G->loadLang();
		$dsw = $this->routes->get('dsw');
		$dsw['username']=trim($dsw['username']);
		$dsw['psd']=sha1($dsw['psd']);
		$login = $this->user->getLogin($dsw);
		if($login['isadmin']==1){
			$tinwinsession=array(
				'uid'=>$login['id'],
				'username'=>$login['username'],
				'nicknam'=>$login['nickname'],
				'isadmin'=>$login['isadmin']
			);
			$_SESSION['tinwinsession']=$tinwinsession;			
			$this->G->loadclass('log')->addLoginLog($dsw['username'],1);
			header("refresh:0;url=".ADMIN_URL."index");
		}else{
           $this->G->loadclass('log')->addLoginLog($dsw['username'],0);
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['checklogin']['LoginError'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."login"
			);
			$this->G->R($message);
		}			
	}

	private function loginout(){
		session_destroy(); //清空已创建的所有SESSION
		session_unset("session_name");//清空指定的session
		unset($_SESSION["tinwinsession"]);//清空指定的session
		header("refresh:0;url=".ADMIN_URL."login");
	}
	
}
?>
