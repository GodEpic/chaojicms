<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 作者:牛哥 tinwin@vip.qq.com
 * 说明:文章管理模块
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "manage";
		$this->$action();
		exit;
	}

	private function manage(){
		$Lang=$this->G->loadLang();
		$page = intval($this->routes->get('page'));
		$page = $page>0?$page:1;
		$ListArt=$this->article->getList($page,10,'','','id desc');
		$ListCat=$this->category->getAll();
		$this->tpl->assign("FormTitle",$Lang['manage']['FormTitle']);
		$this->tpl->assign("FormAction",ADMIN_URL."article-operation");
		$this->tpl->assign('ListArt',$ListArt);
		$this->tpl->assign('ListCat',$ListCat);
		$this->tpl->assign('Lang',$Lang);
		$this->tpl->display('article_list');
	}

	private function manage_one(){
		$Lang=$this->G->loadLang();
		$IntCid=$this->routes->get('cid');
		$page = $this->routes->get('page');
		$page = $page>0?$page:1;
		if(!$IntCid){
			$message = array(
				'CodeType' =>300,
				"message" => $Lang['manage_one']['NotSelectCategory'],
				"callbackType" => 'forward',
				"forwardUrl" => ADMIN_URL."category"	
			);
			$this->G->R($message);
		}
        $ListArt=$this->article->getList($page,10,array('cat_id'=>$IntCid),'','id desc');
		if($ListArt['data']){
			$ListCat=$this->category->getAll();
			$this->tpl->assign("FormTitle",'【'.$ListCat[$IntCid]['cat_name'].'】 '.$Lang['manage_one']['ManageList']);
			$this->tpl->assign("FormAction",ADMIN_URL."article-operation");
			$this->tpl->assign('ListArt',$ListArt);
			$this->tpl->assign('ListCat',$ListCat);
			$this->tpl->assign('ListAll',$this->article->getAll());
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('article_list');
		}else{
			$message = array(
				'CodeType' =>300,
				"message" => $Lang['manage_one']['NotSearchArticle'],
				"callbackType" => 'forward',
				"forwardUrl" => ADMIN_URL."article-add&cid=$IntCid"	
			);
			$this->G->R($message);
		}
	}

	private function operation(){
		$Lang=$this->G->loadLang();
		$SelectCheckbox = $_POST['SelectCheckbox'];
		$operation = $_POST['operation'];
		if(is_array($SelectCheckbox)){
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['movecat']['MoveNotSelect'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."article-manage"
			);
			$this->G->R($message);
		}
		$intcount=0;
		switch ($operation) {
			case 'movecat':
				$movecatid = $_POST['catid'];
				foreach($SelectCheckbox as $value){
					$dsw['cat_id']=$movecatid;       
					$dsw['endtime']=time();
					$dsw['enduser']=$_SESSION['tinwinsession']['uid'];
					//var_dump($value);
					$this->article->update($dsw,array('id'=>$value));
					$intcount++;
					//echo "成功移动".$intcount."条数据<br>";			
				}
				$message = array(
					'statusCode' =>200,
					"message" => $Lang['movecat']['MoveSuccessLeft'].$intcount.$Lang['movecat']['MoveSuccessRight'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL."article-manage_one&cid=$movecatid"
				);
				$this->G->R($message);
				break;
			case 'dels':
				foreach($SelectCheckbox as $value){
					$this->article->del($value);
					$movecount++;
				}
				$message = array(
					'statusCode' =>200,
					"message" => $Lang['del']['DelSuccess'].$movecount.$Lang['movecat']['MoveSuccessRight'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL."article-manage"
				);
				$this->G->R($message);
				break;
			default:
				# code...
				break;
		}
	}
	private function add(){
		$Lang=$this->G->loadLang();
		if($_SESSION['input_token']!="" && $_SESSION['input_token']==$_POST['input_token']){
			$_SESSION['input_token']='';
			$dsw =$_POST['dsw'];
			$stags=$dsw['seo_tags'];
			if($dsw['content']){
				if(is_uploaded_file($_FILES['file']['tmp_name'])){
                    $sfile=$_FILES["file"];
                    $dsw['img']=$this->files->uploadFile($sfile,UPLOAD_PATH_IMG);
                }
                if(empty($dsw['img'])){
                	$dsw['img']=$this->files->getFirstImg($dsw['content']);
                }
                if($dsw['addtime']){
                	$dsw['addtime']=strtotime($dsw['addtime']);
                }
				$Aid=$this->article->save($dsw);
				$this->tags->addArticleTags($stags,$Aid);
				$message = array(
					'CodeType' =>200,
					"message" => $Lang['add']['AddSuccess'],
					"callbackType" => 'forward',
					"forwardUrl" => ADMIN_URL."article-manage_one&cid=".$dsw['cat_id']	
				);
				$this->G->R($message);
			}
		}else{
			$ListOne['cat_id'] =$_GET['cid'];
			$this->tpl->assign("ListCat",$this->category->getTree());
			$_SESSION['input_token'] = md5(rand(100,1000));
			$this->tpl->assign("input_token",$_SESSION['input_token']);
			$this->tpl->assign("FormTitle",$Lang['add']['FormTitle']);
			$this->tpl->assign("FormAction",ADMIN_URL."article-add");
			$this->tpl->assign("Lang",$Lang);
			$this->tpl->assign("ListOne",$ListOne);
			$this->tpl->display('article_form');
		}
	}

	private function edit(){
		$Lang=$this->G->loadLang();
		$IntID=$this->routes->get('id');
		if($_SESSION['input_token']!="" && $_SESSION['input_token']==$_POST['input_token']){
			$_SESSION['input_token']='';
			$dsw =$_POST['dsw'];
			$stags=$dsw['seo_tags'];
			if($dsw){
				$dsw['addtime']=strtotime($dsw['addtime']);
				if(is_uploaded_file($_FILES['file']['tmp_name'])){
                    $sfile=$_FILES["file"];
                    $dsw['img']=$this->files->uploadFile($sfile,UPLOAD_PATH_IMG);
                }
                if(empty($dsw['img'])){
                	$dsw['img']=$this->files->getFirstImg($dsw['content']);
                }
				$this->article->update($dsw,array('id'=>$IntID));
				$this->tags->addArticleTags($stags,$IntID);
				$message = array(
					'CodeType' =>300,
					"message" => $Lang['edit']['EditSuccess'],
					"callbackType" => 'forward',
					"forwardUrl" => ADMIN_URL."article-manage_one&cid=".$dsw['cat_id']	
				);
				$this->G->R($message);
			}
		}else{
			$ListOne=$this->article->getOneByID($IntID);
			$this->tpl->assign("ListCat",$this->category->getTree());
			$this->tpl->assign("ListOne",$ListOne);
			$_SESSION['input_token'] = md5(rand(100,1000));
			$this->tpl->assign("input_token",$_SESSION['input_token']);
			$this->tpl->assign("FormTitle",$Lang['edit']['FormTitle']);
			$this->tpl->assign("FormAction",ADMIN_URL."article-edit&id=$IntID");
			$this->tpl->assign("Lang",$Lang);
			$this->tpl->display('article_form');
		}
	}
	
	private function isview(){
		$IntID=$this->routes->get('id');
		echo $this->article->isview($IntID);
	}

	private function CheckTitle(){
		$Lang=$this->G->loadLang();
		$STitle=$this->routes->get('STitle');
		if($STitle){
			$IntID=$this->routes->get('id');
			$isok=$this->article->getCheckTitle($STitle,$IntID);
			if($isok){
				echo '<span class="text-success glyphicon glyphicon-ok"> '.$Lang['form']['TitleIsok'].'</span>';
			}else{
				echo '<span class="text-danger glyphicon glyphicon-remove"> '.$Lang['form']['TitleIsnot'].'</span>';
			}
		}else{
			echo '<span class="text-danger glyphicon glyphicon-edit"> '.$Lang['CheckTitle']['InputTitle'].'</span>';
		}
		
	}

	private function del(){
		$Lang=$this->G->loadLang();
		$IntID=$this->routes->get('id');
		$rs=$this->article->getOneByID($IntID);
		if($rs){
			$IntCid=$rs['cat_id'];
			$this->article->del($IntID);
			$message = array(
				'statusCode' =>200,
				"message" => $Lang['del']['DelSuccess'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."article-manage_one&cid=".$IntCid
			);
			$this->G->R($message);
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['del']['DelNot'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."article-manage_one&cid=".$IntCid
			);
			$this->G->R($message);
		}	
	}
}
?>
