<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：2018-03-01
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：网站管理控制器
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "set";
		$this->$action();
		exit;
	}

	private function set(){
		$Lang=$this->G->loadLang();
		if($_SESSION['input_token']!="" && $_SESSION['input_token']==$_POST['input_token']){
			$_SESSION['input_token']='';
			$dsw =$_POST['dsw'];
			if($dsw){
                if(is_uploaded_file($_FILES['file']['tmp_name'])){
                    $sfile=$_FILES["file"];
                    $dsw['web_logo']=$this->files->uploadFile($sfile,UPLOAD_PATH_IMG);
                }
				foreach($dsw as $k=>$v){
					$this->webconfig->update(array('value'=>$v),array('varname'=>$k));
				}
				$message = array(
					'CodeType' =>300,
					"message" => $Lang['set']['UpdateSuccess'],
					"callbackType" => 'forward',
					"forwardUrl" => ADMIN_URL."webset"	
				);
				$this->G->R($message);
			}
		}else{
			$ListAll=$this->webconfig->getAll();
			if($ListAll){
				$ListOne=array();
				foreach($ListAll as $k=>$v){
					$ListOne[$v['varname']]=$v['value'];
				}
				$this->tpl->assign("FormTitle",$Lang['set']['FormTitle']);
				$this->tpl->assign('ListOne',$ListOne);
				$_SESSION['input_token'] = md5(rand(100,1000));
				$this->tpl->assign("input_token",$_SESSION['input_token']);
				$this->tpl->assign("FormAction",ADMIN_URL."webset-set");
				$this->tpl->assign("Lang",$Lang);
				$this->tpl->display('webset');
			}
		}
	}

	/**
	 * 时间：20181018 17:23
	 * 作者：牛哥 tinwin@vip.qq.com
	 * 功能：设置网站后台语言
	 */
	private function setlang(){
		$Lang=$this->G->loadLang();
		$langname=$this->routes->get('langname');
		$this->webconfig->update(array('value'=>$langname),array('varname'=>'web_lang'));
		$message = array(
			'CodeType' =>200,
			"message" => $Lang['setlang']['SetSuccess'],
			"callbackType" => 'forward',
			"forwardUrl" => 'goback'	
		);
		$this->G->R($message);
	}
}
?>
