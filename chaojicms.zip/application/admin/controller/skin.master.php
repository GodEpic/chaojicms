<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：2018-02-28
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：模板控制器
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}

	private function index(){
		$Lang=$this->G->loadLang();
		$CurSkin=$this->webconfig->getOne(array('appname'=>'website','varname'=>'homeskin'));
		$skinpath="./application/".HOMENAME."/view/";
		$ListAll = $this->files->listDir($skinpath);
		if($ListAll['dir']){
			foreach($ListAll['dir'] as $k=>$v){
                if(file_exists($skinpath.$v['name'].'/config.php')){
					$SkinList[$k]['config']=$this->tinwin->readArrFile($skinpath.$v['name'].'/config.php');  
                }
				if(file_exists($skinpath.$v['name'].'/img.png')){
					$SkinList[$k]['img']=$skinpath.$v['name'].'/img.png';
				}else{
                    $SkinList[$k]['img']=STATIC_PATH.'images/noimage.png';
				}
				$SkinList[$k]['name']=$v['name'];
				if($v['name']==$CurSkin['value']){
					$SkinList[$k]['status']=$Lang['index']['IsEnable'];
					$SkinList[$k]['del']=$Lang['index']['InUse'];
				}else{
					$SkinList[$k]['status']='<a href="'.ADMIN_URL.'skin-isEnable&skinname='.$v['name'].'">'.$Lang['index']['EnableSkin'].'</a>';
					$SkinList[$k]['del']='<a class="glyphicon glyphicon-remove" href="#" onclick='.'dswfirm("'.ADMIN_URL.'skin-del&skinname='.$v['name'].'","'.$Lang['index']['DelSkinTips'].'")'.'>'.$Lang['index']['DelSkin'].'</a>';
				}
			}
			$this->tpl->assign('FormTitle',$Lang['index']['FormTitle']);
			$this->tpl->assign('SkinList',$SkinList);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('skin_list');
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['index']['NotSkin'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."skin-net"
			);
			$this->G->R($message);
		}		
	}

	private function del(){
		$Lang=$this->G->loadLang();
		$skinname=$this->routes->get('skinname');
		$CurSkin=$this->webconfig->getOne(array('appname'=>'website','varname'=>'homeskin'));
		$mypath="./application/".HOMENAME."/view/".$skinname;
		if(file_exists($mypath)&&$skinname<>$CurSkin['value']){
			$this->files->delfolder($mypath);
			$message = array(
				'statusCode' =>200,
				"message" => $Lang['del']['DelSuccess'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."skin"
			);
			$this->G->R($message);
		}else{
            $message = array(
				'statusCode' =>300,
				"message" => $Lang['del']['NotSkin'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."skin"
			);
			$this->G->R($message);
        }
	}

	private function isEnable(){
		$Lang=$this->G->loadLang();
		$skinname=$this->routes->get('skinname');
		$this->webconfig->update(array('value'=>$skinname),array('varname'=>'homeskin','appname'=>'website'));
		$message = array(
			'statusCode' =>200,
			"message" => $Lang['isEnable']['EnableSuccess'],
			"callbackType" =>'forward',
			"forwardUrl" =>ADMIN_URL."skin"
		);
		$this->G->R($message);
	}

	//获取网络模板 2018-04-18
	private function net(){
		$Lang=$this->G->loadLang();
		$url = SoftUrl."/index.php?api-get-skin-skins";
		$data=$this->tinwin->GetWebContent($url,3);
		$SkinList=json_decode($data,true);
		if($SkinList['status']=='success'){
			$this->tpl->assign('FormTitle',$Lang['net']['FormTitle']);
			$this->tpl->assign('SkinList',$SkinList['data']);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('skin_net');
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['net']['WebBreak'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."skin"
			);
			$this->G->R($message);
		}
	}

	//下载网络模板 2018-04-18
	private function netinstall(){
		$Lang=$this->G->loadLang();
		$skin_name=$this->routes->get('skin_name');
		$url = SoftUrl.'/index.php?api-get-skin-netinstall&skin_name='.$skin_name.'&url='.SITE_WEB.'&username='.SoftUser.'&token='.SoftToken;
		$data=$this->tinwin->GetWebContent($url,3);
		$SkinList=json_decode($data,true);
		if($SkinList['status']=='success'){
			$sdir='./application/'.HOMENAME.'/view/'.$skin_name;
			$sfile=$this->tinwin->getWebSkin($SkinList['data'],$sdir);
			$s=$this->tinwin->unzip_file($sfile,$sdir);
			if($s){
				$this->files->delFile($sfile);
				$message = array(
					'statusCode' =>200,
					"message" => $Lang['netinstall']['InstallSuccess'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL.'skin'
				);
				$this->G->R($message);
			}else{
				$message = array(
					'statusCode' =>300,
					"message" => $Lang['netinstall']['InstallFail'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL.'skin'
				);
				$this->G->R($message);
			}	
		}else{
			$message = array(
				'statusCode' =>300,
				'message' => '错误代码:'.$SkinList['code'].$SkinList['status'],
				"callbackType" =>'forward',
				"forwardUrl" =>"goback"
			);
			$this->G->R($message);
		}
	}
}
?>
