<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20170925
 * 作者：牛哥 tinwin@vip.qq
 * 功能：首页管理控制器
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}
	
	private function index(){
		$Lang=$this->G->loadLang();
		if(file_exists(ROOT_PATH.'admin.php')){
			$Notice[0]['admin']=$Lang['index']['Admin'];
		}
		if(file_exists(APP_PATH.'admin')){
			$Notice[0]['admindir']=$Lang['index']['AdminDir'];
		}
		$this->tpl->assign('Notice',$Notice);
		$this->tpl->assign('Lang',$Lang);
		$this->tpl->display('index');
	}
}
?>
