<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：2017-08-11
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：导航菜单控制器
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}

	private function index(){
		$Lang=$this->G->loadLang();
		$IntCid=$this->routes->get('cid');
		if(!$IntCid){$IntCid=0;}
		$ListAll=$this->navmenu->getAllbyCid($IntCid);
		if($ListAll){
			$this->tpl->assign("FormTitle",$Lang['index']['FormTitle']);
			$this->tpl->assign('ListAll',$ListAll);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('navmenu_list');
		}else{
			$message = array(
				'CodeType' =>300,
				"message" => $Lang['index']['NoCategory'],
				"callbackType" => 'forward',
				"forwardUrl" => MyAppUrl."navmenu-add&cid=".$IntCid
			);
			$this->G->R($message);
		}
	}
    
    private function groupone(){
    	$Lang=$this->G->loadLang();
		$group=$this->routes->get('group');
		$ListAll=$this->navmenu->getAll(array('menu_type'=>$group,'parent_id'=>0));
		if($ListAll){
			$this->tpl->assign("FormTitle",$Lang['groupone']['FormTitle']);
			$this->tpl->assign('ListAll',$ListAll);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('navmenu_list');
		}else{
			$message = array(
				'CodeType' =>300,
				"message" => $Lang['groupone']['NoMenu'],
				"callbackType" => 'forward',
				"forwardUrl" => MyAppUrl."navmenu-add&cid=0"
			);
			$this->G->R($message);
		}
	}
	
	private function add(){
		$Lang=$this->G->loadLang();
		$IntCid=$this->routes->get('cid');
		if($_SESSION['input_token']!="" && $_SESSION['input_token']==$_POST['input_token']){
			$_SESSION['input_token']='';
			$dsw =$_POST['dsw'];
			if($dsw){
				$this->navmenu->save($dsw);
				$message = array(
					'statusCode' =>200,
					"message" => $Lang['add']['AddSuccess'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL."navmenu-index&cid=".$IntCid
				);
				$this->G->R($message);
			}
		}else{
			if($IntCid>0){
				$ListFather=$this->navmenu->getParentByCid($IntCid);			
			}else{
				$ListFather=array("id"=>"0","menu_label"=>$Lang['add']['TopMenu']);
			}
			$this->tpl->assign("ListFather",$ListFather);
			$_SESSION['input_token'] = md5(rand(100,1000));
			$this->tpl->assign("MenuGroup",$this->navmenu->getAllGroup());
			$this->tpl->assign("input_token",$_SESSION['input_token']);
			$this->tpl->assign("FormTitle",$Lang['add']['FormTitle']);
			$this->tpl->assign("FormAction",ADMIN_URL."navmenu-add");
			$this->tpl->assign("Lang",$Lang);
			$this->tpl->display('navmenu_form');
		}	
	}

	private function edit(){
		$Lang=$this->G->loadLang();
		$IntID=$this->routes->get('id');
		$IntCid=$this->routes->get('cid');
		if($_SESSION['input_token']!="" && $_SESSION['input_token']==$_POST['input_token']){
			$_SESSION['input_token']='';
			$dsw =$_POST['dsw'];
			if($dsw){
				$this->navmenu->update($dsw,array('id'=>$IntID));
				$message = array(
					'statusCode' =>200,
					"message" => $Lang['edit']['EditSuccess'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL."navmenu-index&cid=".$IntCid
				);
				$this->G->R($message);
			}
		}else{
			if($IntCid>0){
				$ListFather=$this->navmenu->getParentByCid($IntCid);			
			}else{
				$ListFather=array("id"=>"0","menu_label"=>$Lang['edit']['TopMenu']);
			}
	        $MenuGroup=$this->navmenu->getAllGroup();
	        $this->tpl->assign("MenuGroup",$MenuGroup);
			$ListOne=$this->navmenu->getOneByID($IntID);
			$this->tpl->assign("ListOne",$ListOne);
			$this->tpl->assign("ListFather",$ListFather);
			$_SESSION['input_token'] = md5(rand(100,1000));
			$this->tpl->assign("input_token",$_SESSION['input_token']);
			$this->tpl->assign("FormTitle",$Lang['edit']['FormTitle']);
			$this->tpl->assign("FormAction",ADMIN_URL."navmenu-edit&id=$IntID");
			$this->tpl->assign("Lang",$Lang);
			$this->tpl->display('navmenu_form');
		}
	}
	
	private function isview(){
		$IntID=$this->routes->get('id');
		echo $this->navmenu->isview($IntID);
	}

	private function ismain(){
		$IntID=$this->routes->get('id');
		echo $this->navmenu->ismain($IntID);
	}

	private function isoutlink(){
		$IntID=$this->routes->get('id');
		echo $this->navmenu->isoutlink($IntID);
	}

	private function del(){
		$Lang=$this->G->loadLang();
		$IntID=$this->routes->get('id');
		$Mysun=$this->navmenu->getAllbyCid($IntID);
		if($Mysun){
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['del']['HaveSunMenu'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."navmenu-manage&cid=".$Mysun['parent_id']
			);
			$this->G->R($message);
		}else{
			$this->navmenu->delByID($IntID);
			$message = array(
				'statusCode' =>200,
				"message" => $Lang['del']['DelSuccess'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."navmenu-manage&cid=0"
			);
			$this->G->R($message);
		}
	}


/**
 * 菜单分组管理
 */
    
    //分组列表
    private function group(){
    	$Lang=$this->G->loadLang();
		$ListAll=$this->navmenu->getAllGroup();
		if($ListAll){
			$this->tpl->assign("FormTitle",$Lang['group']['FormTitle']);
			$this->tpl->assign('ListAll',$ListAll);
			$this->tpl->assign("Lang",$Lang);
			$this->tpl->display('navmenugroup_list');
		}else{
            $message = array(
                'statusCode' =>300,
                "message" => $Lang['group']['NoGroup'],
                "callbackType" =>'forward',
                "forwardUrl" =>ADMIN_URL."navmenu-addgroup"
            );
            $this->G->R($message);
        }
	}

	/**
     * 时间：2018-06-05
     * 作者：牛哥 tinwin@vip.qq.com
     * 功能：新建菜单分组
     */
    private function addgroup(){
    	$Lang=$this->G->loadLang();
    	if($_SESSION['input_token']!="" && $_SESSION['input_token']==$_POST['input_token']){
			$_SESSION['input_token']='';
			$dsw =$_POST['dsw'];
			if($dsw){
				$this->navmenu->savegroup($dsw);
				$message = array(
					'statusCode' =>200,
					"message" => $Lang['addgroup']['AddSuccess'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL."navmenu-group"
				);
				$this->G->R($message);
			}
		}else{
			$IntCid=0;
	        $ListFather=array("id"=>"0","menu_label"=>$Lang['addgroup']['TopMenu']);
			$this->tpl->assign("ListFather",$ListFather);
			$_SESSION['input_token'] = md5(rand(100,1000));
			$this->tpl->assign("input_token",$_SESSION['input_token']);
			$this->tpl->assign("FormTitle",$Lang['addgroup']['FormTitle']);
			$this->tpl->assign("FormAction",ADMIN_URL."navmenu-addgroup");
			$this->tpl->assign("Lang",$Lang);
			$this->tpl->display('navmenugroup_form');
		}		
	}

    //编辑分组
    private function editgroup(){
    	$Lang=$this->G->loadLang();
    	$IntID=$this->routes->get('id');
    	if($_SESSION['input_token']!="" && $_SESSION['input_token']==$_POST['input_token']){
			$_SESSION['input_token']='';
			$dsw =$_POST['dsw'];
			if($dsw){
				$this->navmenu->updategroup($dsw,array('id'=>$IntID));
				$message = array(
					'statusCode' =>200,
					"message" => $Lang['editgroup']['EditSuccess'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL."navmenu-group"
				);
				$this->G->R($message);
			}
		}else{
			$ListOne=$this->navmenu->getOneGroup(array('id'=>$IntID));
			$this->tpl->assign("ListOne",$ListOne);
			$_SESSION['input_token'] = md5(rand(100,1000));
			$this->tpl->assign("input_token",$_SESSION['input_token']);
			$this->tpl->assign("FormTitle",$Lang['editgroup']['FormTitle']);
			$this->tpl->assign("FormAction",ADMIN_URL."navmenu-editgroup&id=$IntID");
			$this->tpl->assign("Lang",$Lang);
			$this->tpl->display('navmenugroup_form');
		}
	}
    
    private function delgroup(){
    	$Lang=$this->G->loadLang();
		$IntID=$this->routes->get('id');
        $issys=$this->navmenu->getOneGroup(array('id'=>$IntID));
		if($issys['issys']==1){
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['delgroup']['SysGroup'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."navmenu-group"
			);
			$this->G->R($message);
		}else{
			$this->navmenu->delgroup(array('id'=>$IntID));
			$message = array(
				'statusCode' =>200,
				"message" => $Lang['delgroup']['DelSuccess'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."navmenu-group"
			);
			$this->G->R($message);
		}		
	}
    //是否系统字段(菜单分组)
    private function issys(){
		$IntID=$this->routes->get('id');
		echo $this->navmenu->issys($IntID);
	}
}
?>
