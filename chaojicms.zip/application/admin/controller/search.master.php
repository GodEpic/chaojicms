<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：2018-03-03
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：搜索模块控制器
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}

	private function index(){
		$Lang=$this->G->loadLang();
		$this->tpl->assign("FormTitle",$Lang['index']['FormTitle']);
		$this->tpl->assign("FormAction",ADMIN_URL."search-manage");
		$this->tpl->assign("Lang",$Lang);
		$this->tpl->display('search_index');
	}

	private function manage(){
		$key=urlencode($_POST['searchkeywords']);
		header("refresh:0;url=".ADMIN_URL."search-searchkey&key=".$key);
	}

	private function searchkey(){
		$Lang=$this->G->loadLang();
		$page = $this->routes->get('page');
		$page = $page>0?$page:1;
		$key=$this->routes->get('key');
		$ListAll=$this->search->getAllArtByKey($key,$page);
		if($ListAll&&$key){
			$this->tpl->assign("FormTitle",$Lang['searchkey']['FormTitle']);
			$this->tpl->assign("FormAction",ADMIN_URL."search-tagsadd&key=".$key);
			$this->tpl->assign('key',$key);
			$this->tpl->assign('ListAll',$ListAll);
			$this->tpl->assign("Lang",$Lang);
			$this->tpl->display('search_manage');
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['searchkey']['NoResult'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."search"
			);
			$this->G->R($message);
		}
	}

	private function keywordslist(){
		$Lang=$this->G->loadLang();
		$page = $this->routes->get('page');
		$page = $page>0?$page:1;
		$ListAll=$this->search->getList($page,10,'','','search_time desc');
		$this->tpl->assign("FormTitle",$Lang['keywordslist']['FormTitle']);
		$this->tpl->assign("FormAction",ADMIN_URL."search-dels");
		$this->tpl->assign('ListAll',$ListAll);
		$this->tpl->assign("Lang",$Lang);
		$this->tpl->display('search_list');
	}

	private function isview(){
		$IntID=$this->routes->get('id');
		echo $this->search->isview($IntID);
	}

	private function del(){
		$Lang=$this->G->loadLang();
		$IntID=$this->routes->get('id');
		$this->search->del($IntID);
		$message = array(
			'statusCode' =>200,
			"message" => $Lang['del']['DelSuccess'],
			"callbackType" =>'forward',
			"forwardUrl" =>ADMIN_URL."search-keywordslist"
		);
		$this->G->R($message);
	}

	private function dels(){
		$Lang=$this->G->loadLang();
		$SelectCheckbox = $_POST['SelectCheckbox'];
		if(is_array($SelectCheckbox)){
			foreach($SelectCheckbox as $value){
				$this->search->del($value);
			}
			$message = array(
				'statusCode' =>200,
				"message" => $Lang['dels']['DelSuccess'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."search-keywordslist"
			);
			$this->G->R($message);
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['dels']['NotSelect'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."search-keywordslist"
			);
			$this->G->R($message);
		}
	}

	private function tagsadd(){
		$Lang=$this->G->loadLang();
		$key = $this->routes->get('key');
		$SelectCheckbox = $_POST['SelectCheckbox'];
		if($SelectCheckbox){
			$aid=implode(",",$SelectCheckbox);
			$jk=$this->tags->getTagByLabel($key);
			if(!$jk){
				$dsw=array(
					'tag_label'=>$key,
					'tag_article'=>$aid
				);
				$this->tags->addTag($dsw);
				$message = array(
					'statusCode' =>200,
					"message" => $Lang['tagsadd']['AddSuccess'],
					"callbackType" =>'forward',
					"forwardUrl" =>"goback"
				);
				$this->G->R($message);
			}else{
				$this->tags->updateArtTags($jk['tag_id'],$aid);
				$message = array(
					'statusCode' =>300,
					"message" => $Lang['tagsadd']['UpdateSuccess'],
					"callbackType" =>'forward',
					"forwardUrl" =>"goback"
				);
				$this->G->R($message);
			}
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['tagsadd']['NotSelect'],
				"callbackType" =>'forward',
				"forwardUrl" =>"goback"
			);
			$this->G->R($message);
		}
	}
}
?>
