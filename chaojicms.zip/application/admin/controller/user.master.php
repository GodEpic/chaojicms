<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：2017-10-07
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：后台用户登录管理控制器
 *
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}
	
	private function index(){
		$Lang=$this->G->loadLang();
		$page = $this->routes->get('page');
		$page = $page>0?$page:1;
		$ListAll=$this->user->getList($page,10);
		$this->tpl->assign("FormTitle",$Lang['index']['FormTitle']);
		$this->tpl->assign("FormAction",ADMIN_URL."user-select");
		$this->tpl->assign('ListAll',$ListAll);
		$this->tpl->assign('Lang',$Lang);
		$this->tpl->display('user_list');
	}

	private function search(){
		$Lang=$this->G->loadLang();
		$skey=$this->routes->post('searchkeywords');
		$page = $this->routes->get('page');
		$page = $page>0?$page:1;
		$ListAll=$this->user->getList($page,10,"username like '%$skey%' or nickname like '%$skey%'");
		$this->tpl->assign("FormTitle",$skey.$Lang['search']['FormTitle']);
		$this->tpl->assign('ListAll',$ListAll);
		$this->tpl->assign('Lang',$Lang);
		$this->tpl->display('user_list');
	}

	private function add(){
		$Lang=$this->G->loadLang();
		if($_SESSION['input_token']!="" && $_SESSION['input_token']==$_POST['input_token']){
			$_SESSION['input_token']='';
			$dsw =$_POST['dsw'];
			$dsw['psd']=$this->G->loadclass('tinwin')->SetPsd($dsw['psd']);
			$dsw['endtime']=time();
			$dsw['enduser']=$_SESSION['tinwinsession']['uid'];
			$dsw['addtime']=time();
			$dsw['adduser']=$_SESSION['tinwinsession']['uid'];
			if($dsw){
				$this->user->save($dsw);
				$message = array(
					'CodeType' =>200,
					"message" => $Lang['add']['AddSuccess'],
					"callbackType" => 'forward',
					"forwardUrl" => ADMIN_URL."user-manage"	
				);
				$this->G->R($message);
			}
		}else{
			$_SESSION['input_token'] = md5(rand(100,1000));
			$this->tpl->assign("input_token",$_SESSION['input_token']);
			$this->tpl->assign("FormTitle",$Lang['add']['FormTitle']);
			$this->tpl->assign("FormAction",ADMIN_URL."user-add");
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('user_form');
		}
	}

	private function edit(){
		$Lang=$this->G->loadLang();
		if($_SESSION['input_token']!="" && $_SESSION['input_token']==$_POST['input_token']){
			$_SESSION['input_token']='';
			$IntID=$this->routes->get('id');
			$dsw =$_POST['dsw'];
			if($dsw['psd']!=""){
				$dsw['psd']=$this->G->loadclass('tinwin')->SetPsd($dsw['psd']);
			}else{
				unset($dsw['psd']);
			}
			$dsw['endtime']=time();
			$dsw['enduser']=$_SESSION['tinwinsession']['uid'];
			$dsw['addtime']=time();
			$dsw['adduser']=$_SESSION['tinwinsession']['uid'];
			if($dsw){
				$this->user->update($dsw,array('id'=>$IntID));
				$message = array(
					'CodeType' =>200,
					"message" => "更新成功",
					"callbackType" => 'forward',
					"forwardUrl" => ADMIN_URL."user-manage"	
				);
				$this->G->R($message);
			}
		}else{
			$IntID=$this->routes->get('id');
			if(!$IntID)$IntID=$_SESSION['tinwinsession']['uid'];
			$ListOne=$this->user->getOneByID($IntID);
			if($ListOne){
				$this->tpl->assign("ListOne",$ListOne);
				$_SESSION['input_token'] = md5(rand(100,1000));
				$this->tpl->assign("input_token",$_SESSION['input_token']);
				if($IntID==$_SESSION['tinwinsession']['uid']){
					$this->tpl->assign("FormTitle",$Lang['edit']['Myself']);
				}else{
					$this->tpl->assign("FormTitle",'【'.$ListOne['nickname'].'】'.$Lang['edit']['EditData']);
				}
				$this->tpl->assign("FormAction",ADMIN_URL."user-edit&id=$IntID");
				$this->tpl->assign('Lang',$Lang);
				$this->tpl->display('user_form');
			}
		}	
	}

	private function del(){
		$Lang=$this->G->loadLang();
		$IntID=$this->routes->get('id');
		if($IntID!=$_SESSION['tinwinsession']['uid']){
			$this->user->del($IntID);
			$message = array(
				'statusCode' =>200,
				"message" => $Lang['del']['DelSuccess'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."user"
			);
			$this->G->R($message);
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['del']['DelMyself'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."user"
			);
			$this->G->R($message);
		}	
	}


	private function isadmin(){
		$IntID=$this->routes->get('id');
		echo $this->user->isadmin($IntID);
	}

	//登录记录
	private function loginlog(){
		$Lang=$this->G->loadLang();
		$page = $this->routes->get('page');
		$page = $page>0?$page:1;
		$ListAll=$this->G->loadclass('log')->getList($page,PAGED,array('login_status'=>1));
		$this->tpl->assign("FormTitle",$Lang['loginlog']['FormTitle']);
		$this->tpl->assign('ListAll',$ListAll);
		$this->tpl->assign('Lang',$Lang);
		$this->tpl->display('user_loginlog');
	}

	private function loginlogno(){
		$Lang=$this->G->loadLang();
		$page = $this->routes->get('page');
		$page = $page>0?$page:1;
		$ListNot=$this->G->loadclass('log')->getList($page,PAGED,array('login_status'=>0));
		$this->tpl->assign("FormTitle",$Lang['loginlogno']['FormTitle']);
		$this->tpl->assign('ListAll',$ListNot);
		$this->tpl->assign('Lang',$Lang);
		$this->tpl->display('user_loginlog');
	}
}
?>
