<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 创建:2018-02-28
 * 作者:牛哥 Tinwin@vip.qq.com
 * 功能:文件操作类，可操作php等文件
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "getDir";
		$this->$action();
		exit;
	}

	private function getDir(){
		$Lang=$this->G->loadLang();
		if($this->routes->get('mypath')){
			$mypath=$this->routes->get('mypath')."/";
		}else{
			$mypath="/";
		}
		$mypath=str_replace("..","",$mypath);//防止查看根目录的前一目录
		$ListAll = $this->files->listDir(".".$mypath);
        $TinwinPath = $this->tinwin->TinwinPath($mypath);
        $this->tpl->assign('TinwinPath',$TinwinPath);
		$this->tpl->assign('ListAll',$ListAll);
		$this->tpl->assign('mypath',$mypath);
		$this->tpl->assign('Lang',$Lang);
		$this->tpl->display('file_list');
	}
    

	//删除文件
	private function fileDel(){
		$Lang=$this->G->loadLang();
		$mypath=$this->routes->get('mypath');
		$mypath=str_replace("..","",$mypath);
		$mydir=dirname($mypath);
		if(file_exists(".".$mypath)){
			$this->files->delFile(".".$mypath);
			$message = array(
				'statusCode' =>200,
				"message" => $Lang['fileDel']['DelSuccess'],
				"callbackType" =>'forward',
				"forwardUrl" =>MyAppUrl."file-getDir&mypath=".$mydir
			);
			$this->G->R($message);
		}		
	}

	//删除文件夹
	private function dirDel(){
		$Lang=$this->G->loadLang();
		$mypath=$this->routes->get('mypath');
		$mypath=str_replace("..","",$mypath);
		$mydir=dirname($mypath);
		if(file_exists(".".$mypath)){
			$this->files->delfolder(".".$mypath);
			$message = array(
				'statusCode' =>200,
				"message" => $Lang['dirDel']['DelSuccess'],
				"callbackType" =>'forward',
				"forwardUrl" =>MyAppUrl."file-getDir&mypath=".$mydir
			);
			$this->G->R($message);
		}		
	}

	//读取文件
	private function fileEdit(){
		$Lang=$this->G->loadLang();
		$mypath=$this->routes->get('mypath');
		$mypath=str_replace("..","",$mypath);
        $mydir=dirname($mypath);
        if($_SESSION['input_token']!="" && $_SESSION['input_token']==$_POST['input_token']){
			$_SESSION['input_token']='';
			if(file_exists(".".$mypath)&&$this->files->isWriteFile(".".$mypath)){
				$Content=$_POST['content'];
				$this->files->writeFile(".".$mypath,$Content);
				$message = array(
					'statusCode' =>200,
					"message" => $Lang['fileEdit']['EditSuccess'],
					"callbackType" =>'forward',
					"forwardUrl" =>MyAppUrl."file-getDir&mypath=".$mydir
				);
				$this->G->R($message);
			}
		}else{
			if(file_exists(".".$mypath)){
				$_SESSION['input_token'] = md5(rand(100,1000));
				$this->tpl->assign("input_token",$_SESSION['input_token']);
	            $TinwinPath = $this->tinwin->TinwinPath($mydir);
	            $this->tpl->assign('TinwinPath',$TinwinPath.'<li>/ '.basename($mypath).'</li>');
	            $extname=$this->files->getFileExtName($mypath);
	            if(stripos('.txt,php,css,js',$extname)>0){
	            	$Content=$this->files->readFile(".".$mypath);
		            $this->tpl->assign('filename',basename($mypath));
					$this->tpl->assign('Content',$Content);
					$this->tpl->assign('Lang',$Lang);
					$this->tpl->assign("FormTitle",$Lang['fileEdit']['FormTitle']);
					$this->tpl->assign("FormAction",MyAppUrl."file-fileEdit&mypath=$mypath");
					$this->tpl->display('file_form');
	            }else{
	            	$message = array(
						'statusCode' =>200,
						"message" => $Lang['fileEdit']['NoEdit'],
						"callbackType" =>'forward',
						"forwardUrl" =>'goback'
					);
					$this->G->R($message);
	            }
			}
		}		
	}

	//清理缓存
	public function clear(){
		$Lang=$this->G->loadLang();
		$this->files->delfolder(DATA_HTML);
		$this->files->delfolder(DATA_COMPILE);
		$message = array(
			'statusCode' =>200,
			"message" => $Lang['clear']['ClearSuccess'],
			"callbackType" =>'forward',
			"forwardUrl" =>MyAppUrl."index"
		);
		$this->G->R($message);
	}
}
?>
