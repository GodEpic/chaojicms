<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 作者:牛哥 tinwin@vip.qq.com
 * 说明:模块管理
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}

	private function index(){
		$Lang=$this->G->loadLang();
		$AppLocalList=$this->apps->getLocalAppList();
		if($AppLocalList){
			$this->tpl->assign("FormTitle",$Lang['index']['FormTitle']);
			$this->tpl->assign("FormAction",ADMIN_URL."apps-add");
			$this->tpl->assign('AppLocalList',$AppLocalList);
			$UnInstallList=$this->apps->getUnInstall();
			$this->tpl->assign('UnInstallList',$UnInstallList);
			$InstallList=$this->apps->getAllByData();
			$this->tpl->assign('InstallList',$InstallList);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('apps_list');
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['index']['NoApp'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."apps-blank"
			);
			$this->G->R($message);
		}
	}

	private function blank(){
		$Lang=$this->G->loadLang();
		$this->tpl->assign("FormTitle",$Lang['blank']['FormTitle']);
		$this->tpl->display('blank');
	}
	
	private function add(){
		$Lang=$this->G->loadLang();
		$AppLocalList=$this->apps->getLocalAppList();
		if($AppLocalList){
			$this->tpl->assign("FormTitle",$Lang['add']['FormTitle']);
			$this->tpl->assign("FormAction",ADMIN_URL."apps-appinstall");
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->assign('ListAll',$this->apps->getUnInstall());
			$this->tpl->display('apps_add');
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['add']['NoApp'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."apps-blank"
			);
			$this->G->R($message);
		}
	}

	private function del(){
		$Lang=$this->G->loadLang();
		$AppLocalList=$this->apps->getLocalAppList();
		if($AppLocalList){
			$this->tpl->assign("FormTitle",$Lang['del']['FormTitle']);
			$this->tpl->assign("FormAction",ADMIN_URL."apps-appuninstall");
			$this->tpl->assign('AppLocalList',$AppLocalList);
			$InstallList=$this->apps->getAllByData();
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->assign('InstallList',$InstallList);
			$this->tpl->display('apps_del');
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['del']['NoApp'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."apps-blank"
			);
			$this->G->R($message);
		}
	}


    //更新
	private function upgrade(){
		$Lang=$this->G->loadLang();
		$InstallList=$this->apps->getAllByData();
		$AppLocalList=$this->apps->getLocalAppList();
		foreach($InstallList as $k=>$v){
			foreach($AppLocalList as $k1=>$v1){
				if($v1['appname']==$v['appname'] && $v1['appversion']>$v['appversion']){
					$InstallList[$k]['newversion']=$v1['appversion'];
				}
			}
		}
		foreach($InstallList as $k=>$v){
			if(empty($v['newversion'])){
				unset($InstallList[$k]);
			}
		}
		$this->tpl->assign("FormTitle",$Lang['upgrade']['FormTitle']);
		$this->tpl->assign("FormAction",ADMIN_URL."apps-appupgrade");
		$this->tpl->assign("InstallList",$InstallList);
		$this->tpl->assign('Lang',$Lang);
		$this->tpl->display('apps_upgrade');
	}
    
	//安装单个模块APP
	private function appinstall(){
		$Lang=$this->G->loadLang();
		$appname=$this->routes->get('appname');
		$mypath="./application/".$appname."/";
		$mydir=str_replace("\\","/",dirname(dirname(dirname(__FILE__))))."/".$appname."/";
		if(file_exists($mypath)){
			if(file_exists($mypath."install.lock")){
				$message = array(
					'statusCode' =>300,
					"message" => $Lang['appinstall']['Installed'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL."apps"
				);
				$this->G->R($message);
				exit;
			}else{
				$myapp=$this->apps->getLocalAppByName($appname);
                $dsw['menu_name']=$appname;
                $dsw['menu_label']=$myapp['menutitle'];
                $dsw['menu_path']=$myapp['menuurl'];
                $dsw['addtime']=time();
                $dsw['adduser']=$_SESSION['tinwinsession']['uid'];
                $dsw['endtime']=time();
                $dsw['enduser']=$_SESSION['tinwinsession']['uid'];
                $dsw['parent_id']=16;
                $dsw['isoutlink']=1;
                $dsw['menu_type']='admin';
                $this->G->loadclass('navmenu')->save($dsw);
				if(file_exists($mydir.$myapp['install'])){
					@require_once($mydir.$myapp['install']);
					unset($myapp['mypath']);
					unset($myapp['install']);
					unset($myapp['uninstall']);
					unset($myapp['upgrade']);
                    unset($myapp['menutitle']);//模块菜单标题
                    unset($myapp['menuurl']);//模块菜单地址
					$this->apps->save($myapp);
				}else{
					$message = array(
						'statusCode' =>300,
						"message" => $Lang['appinstall']['NoInstallFile'],
						"callbackType" =>'forward',
						"forwardUrl" =>ADMIN_URL."apps"
					);
					$this->G->R($message);
				}
				if($this->files->isWriteDir($mypath)){
					$this->files->writeFile($mypath."install.lock");
					$url = SoftUrl.'/index.php?api-get-apps-appinstall&appname='.$appname.'&url='.SITE_WEB.'&username='.SoftUser.'&token='.SoftToken;
					$this->tinwin->GetWebContent($url,3);
					$message = array(
						'statusCode' =>200,
						"message" => $Lang['appinstall']['InstallSuccess'],
						"callbackType" =>'forward',
						"forwardUrl" =>ADMIN_URL."apps"
					);
					$this->G->R($message);
				}else{
					$message = array(
						'statusCode' =>300,
						"message" => $Lang['appinstall']['NotOpenWritePower'],
						"callbackType" =>'forward',
						"forwardUrl" =>ADMIN_URL."apps"
					);
					$this->G->R($message);
				}				
			}
		}
	}

	/**
	 * 模块卸载
	 * 
	 */
	private function appuninstall(){
		$Lang=$this->G->loadLang();
		$appname=$this->routes->get('appname');
		$mypath="./application/".$appname."/";
		$mydir=str_replace("\\","/",dirname(dirname(dirname(__FILE__))))."/".$appname."/";
		if(is_file($mypath."install.lock")){
			$myapp=$this->apps->getLocalAppByName($appname);
            $this->G->loadclass('navmenu')->del(array('menu_name'=>$appname));
			@require_once($mydir.$myapp['uninstall']);
			$this->dbpdo->remove("apps",array('appname'=>$appname));
			if($this->files->isWriteDir($mypath)){
				if(is_file($mypath."install.lock")){
					$this->files->delFile($mypath."install.lock");
					$url = SoftUrl.'/index.php?api-get-apps-appuninstall&appname='.$appname.'&url='.SITE_WEB.'&username='.SoftUser.'&token='.SoftToken;
					$this->tinwin->GetWebContent($url,3);
				}
			}			
			$message = array(
				'statusCode' =>200,
				"message" => $Lang['appuninstall']['UninstallSuccess'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."apps"
			);
			$this->G->R($message);
		}		
	}
    
    /**
     * 模块升级
     * 
     */
	private function appupgrade(){
		$Lang=$this->G->loadLang();
		$appname=$this->routes->get('appname');
		$mypath="./application/".$appname."/";
		$mydir=str_replace("\\","/",dirname(dirname(dirname(__FILE__))))."/".$appname."/";
		if(is_file($mypath."install.lock")){
			$myapp=$this->apps->getLocalAppByName($appname);
			$oldapp=$this->apps->getOneByName($appname);
			if($myapp['appversion']>$oldapp['appversion']){
				$dsw['appversion']=$myapp['appversion'];
				$dsw['endtime']=TIME;
				$this->apps->update($dsw,array('appname'=>$appname));
				@require_once($mydir.$myapp['upgrade']);
				$message = array(
					'statusCode' =>200,
					"message" => $Lang['appupgrade']['UpgradeSuccess'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL."apps"
				);
				$this->G->R($message);
			}else{
				$message = array(
					'statusCode' =>300,
					"message" => $Lang['appupgrade']['IsNewVersion'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL."apps"
				);
				$this->G->R($message);
			}
		}
	}

	/**
	 * 已装模块
	 * 
	 */
	private function installed(){
		$Lang=$this->G->loadLang();
		$InstallList=$this->apps->getAllByData();
		foreach($InstallList as $k=>$v){
			$s=$this->apps->getLocalAppByName($v['appname']);
			$InstallList[$k]['menuurl']=$s['menuurl'];
		}
		$this->tpl->assign("FormTitle",$Lang['installed']['FormTitle']);
		$this->tpl->assign("InstallList",$InstallList);
		$this->tpl->assign('Lang',$Lang);
		$this->tpl->display('apps_installed');
	}

	/**
	 * 作者：牛哥 tinwin@vip.qq.com
	 * 时间：20181013 16:51
	 * 功能：在线安装模块
	 */
	private function online(){
		$Lang=$this->G->loadLang();
		$url = SoftUrl."/index.php?api-get-apps-index";
		$data=$this->tinwin->GetWebContent($url,3);
		$AppOnline=json_decode($data,true);
		if($AppOnline['status']=='success'){		
			$AppLocalList=$this->apps->getLocalAppList();
			foreach($AppOnline['data'] as $k=>$v){
				$AppOnline['data'][$k]['newversion']=$v['appversion'];
				//$AppOnline['data'][$k]['url']=SoftUrl.'/index.php?api-get-apps-netinstall&app_name='.$app_name.'&url='.SITE_WEB.'&username='.SoftUser.'&token='.SoftToken;
				foreach($AppLocalList as $k1=>$v1){
					if($v1['appname']==$v['appname']){
						$isinstall=$this->apps->getOneByName($v1['appname']);
						if($isinstall){
							$AppOnline['data'][$k]['local']='<a href="#" onclick='.'dswfirm("'.MyAppUrl.'apps-appuninstall&appname='.$v1['appname'].'","'.$Lang['online']['DelTips'].'")>'.$Lang['online']['DelTitle'].'</a>' ;
						}else{
							$AppOnline['data'][$k]['local']='<a href="'.MyAppUrl.'apps-appinstall&appname='.$v1['appname'].'">'.$Lang['online']['InstallTitle'].'</a>' ;
						}
						$AppOnline['data'][$k]['localversion']=$v1['appversion'];
					}
				}
			}
			$this->tpl->assign('FormTitle',$Lang['online']['FormTitle']);
			$this->tpl->assign('AppOnline',$AppOnline['data']);
			$this->tpl->assign('Lang',$Lang);
			$this->tpl->display('apps_online');
		}else{
			$message = array(
				'statusCode' =>300,
				"message" => $Lang['online']['OnlineBreak'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."apps"
			);
			$this->G->R($message);
		}
	}

	/**
	 * 时间:20181031
	 * 作者:牛哥 tinwin@vip.qq.com
	 * 说明:从网络下载并安装
	 * 
	 */
	private function netinstall(){
		$Lang=$this->G->loadLang();
		$appname=$this->routes->get('appname');
		$url = SoftUrl.'/index.php?api-get-apps-netinstall&appname='.$appname.'&url='.SITE_WEB.'&username='.SoftUser.'&token='.SoftToken;
		$data=$this->tinwin->GetWebContent($url,3);
		$DownList=json_decode($data,true);
		if($DownList['status']=='success'){
			$sdir='./application/'.$appname.'/';
			$sfile=$this->tinwin->getWebSkin($DownList['data'],$sdir);
			$s=$this->tinwin->unzip_file($sfile,$sdir);
			if($s){
				$this->files->delFile($sfile);
				$message = array(
					'statusCode' =>200,
					"message" => $Lang['netinstall']['DownSuccess'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL.'apps-appinstall&appname='.$appname
				);
				$this->G->R($message);
			}else{
				$message = array(
					'statusCode' =>300,
					"message" => $Lang['netinstall']['InstallFail'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL.'apps'
				);
				$this->G->R($message);
			}	
		}else{
			$message = array(
				'statusCode' =>300,
				'message' => '错误代码:'.$DownList['code'].$DownList['status'],
				"callbackType" =>'forward',
				"forwardUrl" =>"goback"
			);
			$this->G->R($message);
		}
	}


	/**
	 * 时间:20181031
	 * 作者:牛哥 tinwin@vip.qq.com
	 * 说明:从网络下载并升级
	 * 
	 */
	private function netupgrade(){
		$Lang=$this->G->loadLang();
		$appname=$this->routes->get('appname');
		$url = SoftUrl.'/index.php?api-get-apps-netinstall&appname='.$appname.'&url='.SITE_WEB.'&username='.SoftUser.'&token='.SoftToken;
		$data=$this->tinwin->GetWebContent($url,3);
		$DownList=json_decode($data,true);
		if($DownList['status']=='success'){
			$sdir='./application/'.$appname;
			$sfile=$this->tinwin->getWebSkin($DownList['data'],$sdir);
			$s=$this->tinwin->unzip_file($sfile,$sdir);
			if($s){
				$this->files->delFile($sfile);
				$message = array(
					'statusCode' =>200,
					"message" => $Lang['netinstall']['DownSuccess2'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL.'apps-appupgrade&appname='.$appname
				);
				$this->G->R($message);
			}else{
				$message = array(
					'statusCode' =>300,
					"message" => $Lang['netinstall']['InstallFail'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL.'apps'
				);
				$this->G->R($message);
			}	
		}else{
			$message = array(
				'statusCode' =>300,
				'message' => '错误代码:'.$DownList['code'].$DownList['status'],
				"callbackType" =>'forward',
				"forwardUrl" =>"goback"
			);
			$this->G->R($message);
		}
	}

}
?>
