<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20180726
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：系统更新控制器
 */
class action extends app{
	public function display(){
		$action = $this->routes->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}
	
	private function blank(){
		$this->tpl->display('blank');
	}
	
	private function index(){
		$Lang=$this->G->loadLang();
		$url = SoftUrl."/index.php?api-get-soft-index&user=".SoftUser."&token=".SoftToken."&url=".SITE_URL;
		$data=$this->tinwin->GetWebContent($url,3);
		$DataList=json_decode($data,true);
		if($DataList['status']=='success'){
			if($DataList['data']['soft_version']>SoftVersion){
				$this->tpl->assign('FormTitle',$Lang['index']['FormTitle']);
				$this->tpl->assign('FormBlank',$Lang['index']['FindNewVersion'].$DataList['data']['soft_version'].' <a href="'.MyAppUrl.'update-upgrade">'.$Lang['index']['UpdateNow'].'</a>');
				$this->tpl->display('blank');
			}else{
				$this->tpl->assign('FormTitle',$Lang['index']['FormTitle']);
				$this->tpl->assign('FormBlank',$Lang['index']['NotUpdate']);
				$this->tpl->display('blank');
			}
		}else{
            $message = array(
				'statusCode' =>300,
				"message" => "错误代码".$DataList['code'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."update-blank"
			);
			$this->G->R($message);
        }
	}
	
	private function checkversion(){
		$Lang=$this->G->loadLang();
		$url = SoftUrl."/index.php?api-get-soft-index&user=".SoftUser."&token=".SoftToken."&url=".SITE_WEB;
		$data=$this->tinwin->GetWebContent($url,3);
		if($data){
			$DataList=json_decode($data,true);
		}
		if($DataList['status']=='success'){
			if($DataList['data']['soft_version']>SoftVersion){
				echo $Lang['index']['FindNewVersion'].$DataList['data']['soft_version'].' <a href="'.MyAppUrl.'update-upgrade">'.$Lang['index']['UpdateNow'].'</a>';
			}else{
				echo $Lang['index']['NotUpdate'];
			}
		}else{
			echo $Lang['checkversion']['ErrorTips'].',<a href="'.ADMIN_URL.'webset-set#soft"> '.$Lang['checkversion']['Edit'].'</a>'.',<a href="'.SoftUrl.'/index.php?api-web-index-renzheng&url='.SITE_WEB.'"> '.$Lang['checkversion']['Register'].'</a>';
		}
	}

	//升级安装
	private function upgrade(){
		$url = SoftUrl."/index.php?api-get-soft-upgrade&user=".SoftUser."&token=".SoftToken."&url=".SITE_WEB."&version=".SoftVersion;
		$data=$this->tinwin->GetWebContent($url,3);
		$DataList=json_decode($data,true);
		if($DataList['status']=='success'){
			$sdir='./';
			$sfile=$this->tinwin->getWebSkin($DataList['data'],$sdir);
			$s=$this->tinwin->unzip_file($sfile,$sdir);
			if($s){
				$this->files->delFile($sfile);
				$message = array(
					'statusCode' =>200,
					"message" => $Lang['index']['UpgradeSuccess'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL.'index'
				);
				$this->G->R($message);
			}else{
				$message = array(
					'statusCode' =>300,
					"message" => $Lang['index']['UpgradeFail'],
					"callbackType" =>'forward',
					"forwardUrl" =>ADMIN_URL.'index'
				);
				$this->G->R($message);
			}
		}else{
            $message = array(
				'statusCode' =>300,
				"message" => "错误代码".$DataList['code'],
				"callbackType" =>'forward',
				"forwardUrl" =>ADMIN_URL."update-index"
			);
			$this->G->R($message);
        }
	}
}
?>
