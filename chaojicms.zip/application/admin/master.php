<?php
class app
{
	public $G;
	public function __construct(&$G){
		$this->G = $G;
		$this->apps = $this->G->loadclass('apps');
		$this->routes = $this->G->loadclass('routes');
		$this->dbpdo = $this->G->loadclass('dbpdo');
		$this->dbsqli = $this->G->loadclass('dbsqli');
		$this->tpl = $this->G->loadclass('tpl');
		$this->files = $this->G->loadclass('files');
		$this->search = $this->G->loadclass('search');
		$this->category = $this->G->loadclass('category');
		$this->article = $this->G->loadclass('article');
		$this->tinwin = $this->G->loadclass('tinwin');
		$this->data = $this->G->loadclass('databackup');
		$this->tags = $this->G->loadclass('tags');
		$this->user = $this->G->loadclass('user','admin');
		$this->navmenu = $this->G->loadclass('navmenu');
		$this->webconfig = $this->G->loadclass('webconfig');
		if($_SESSION['tinwinsession']['isadmin']!=1&&$this->routes->url(2)!='login'){
			header("refresh:0;url=".ADMIN_URL."login");//跳转页面，注意路径
			exit;
		}
		$this->tpl->assign('navmenu',$this->navmenu->getAllByType('admin'));
		$this->tpl->assign('MenuTree',$this->navmenu->getTree());
		$this->tpl->assign("ListApps",$this->apps->getAllByData());
		$this->tpl->assign('CatTree',$this->category->getTree());
		$web=$this->webconfig->getWebConfig();
		$soft['config']=$this->tinwin->readArrFile(DATA_PATH .'soft.php');
		define('SoftUser',$web['website']['soft_user']);
		define('SoftToken',$web['website']['soft_token']);
		define('SoftVersion',$soft['config']['soft_version']);
		define('SoftUrl',$soft['config']['soft_url']);
	}
}
?>