<?php
!defined('IN_DSW') && exit('大神你要飞呀');
return array(
    'applabel'=>'超级CMS系统后台',
    'appname'=>'admin',
	'appversion'=>'1.46',
    'appdate'=>'2019-03-18',
    'type' => 'services',
    'description' => '超级CMS系统后台',
    'author'=>'牛哥',
    'appimg'=>'icon.png',
    'url'=>'http://www.chaojicms.com',
    'install'=>'install.php',
    'uninstall'=>'uninstall.php',
    'upgrade'=>'upgrade.php',
    'menutitle'=>'超级CMS系统后台',
    'menuurl'=>'index.php?admin-master-index'
);
?>