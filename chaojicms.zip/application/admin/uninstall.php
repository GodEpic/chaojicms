<?php
!defined('IN_DSW') && exit('大神请勿乱策');
$sql="";
$this->dbpdo->exec($sql);
?>