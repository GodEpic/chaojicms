<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181106 15:50
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：站点配置中文简体语言包
 */
return array(
	'website'=>array(
		'Welcome'=>'welcome',
		'adminhome'=>'Home',
		'Logout'=>'logout',
		'LogoutTips'=>'Sure you logout',
		'EditProfile'=>'Edit Profile',
		'OfficialWebsite'=>'Official Website',
		'FrontPage'=>'Front Page',
		'SearchTips'=>'Please input the content you want to search.',
		'SearchButton'=>'Search',
		'Version'=>'Version'
		),
	'webmenu'=>array(
		'System'=>'System',
		'SystemSet'=>'System Set',
		'MenuManage'=>'Menu Manage',
		'FileManage'=>'File Manage',
		'ModelManage'=>'Model Manage',
		'SkinManage'=>'Skin Manage',
		'Clear'=>'Clear',
		'Content'=>'Content',
		'ArticleAll'=>'Article All',
		'Category'=>'Category',
		'Search'=>'Search record management',
		'Tags'=>'Tags management',
		'Jiaodiantu'=>'Focus picture',
		'User'=>'user management',
		'UserManage'=>'user management',
		'LoginLog'=>'Logon record',
		'DataManage'=>'Database management',
		'Backup'=>'Data backup / repair / optimization',
		'Restore'=>'Data reduction',
		'Seo'=>'SEO Webmaster Tools',
		'SeoEnterUrl'=>'Search engine entry submission',
		'SeoAll'=>'SEO comprehensive query',
		'SeoOutlink'=>' Increase the outer chain ',
		'SeoFriendlink'=>'Friend chain detection',
		'SeoWhois'=>'Whois'
		),
);
?>
