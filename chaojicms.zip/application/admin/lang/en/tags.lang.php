<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181025 18:15
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：tags标签管理英文语言包
 */
return array(
	'common'=>array(
		'Home'=>'Home'
		),
	'index'=>array(
		'FormTitle'=>'Tags management list',
		'Select'=>'Select',
		'Label'=>'Label',
		'ArticleIds'=>'Article ID',
		'Del'=>'Delete',
		'DelTips'=>'Are you sure you want to delete the tags tag?',
		'ChoiceAll'=>'Select all',
		'UnSelect'=>'No choice',
		'ChoiceReverse'=>'Reverse selection',
		'Submit'=>'Delete',
		'Operation'=>'Operation'
		),
	'nav'=>array(
		'List'=>'Column List',
		'Add'=>'Column Add',
		'ArticleList'=>'All Article',
		'ArticleAdd'=>'Article add',
		'SearchRecord'=>'Search Record',
		'TagLabel'=>'Tag Label',
		'Jiaodiantu'=>'Focus picture',
		'JiaodiantuAdd'=>'Focus Add'
		),
	'del'=>array(
		'DelSuccess'=>'Delete success'
		),
	'dels'=>array(
		'DelSuccess'=>'Delete success',
		'NotSelect'=>'Great God, you have to aim at anyone, at least aim at it first.'
		),
	'edit'=>array(
		'FormTitle'=>'Tag tag editing',
		'EditSuccess'=>'Successful tag tag update',
		'EditFail'=>'Duplicate label, please reset',
		'EditNot'=>'Do not make any changes',
		),
	'form'=>array(
		'tag_label'=>'Tag label',
		'tag_labelTips'=>'Please enter the tag label content',
		'Save'=>'Save'
		),
);
?>
