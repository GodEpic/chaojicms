<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181025 18:17
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：系统更新英文语言包
 */
return array(
	'index'=>array(
		'FormTitle'=>'System update',
		'FindNewVersion'=>'Find the latest version',
		'UpdateNow'=>'Now update',
		'NotUpdate'=>'This is the latest version'
		),
	'checkversion'=>array(
		'ErrorTips'=>'The version check is abnormal. Please check whether the user name and token configuration are correct.',
		'Edit'=>'Edit',
		'Register'=>'Site registration'
		),
);
?>
