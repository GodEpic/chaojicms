<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181025 18:00
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：搜索管理英文语言包
 */
return array(
	'common'=>array(
		'Home'=>'Home'
		),
	'index'=>array(
		'FormTitle'=>'Article search',
		'Submit'=>'Search',
		'FormTips'=>'You must be accountable to others, otherwise I will not let you go.'
		),
	'nav'=>array(
		'List'=>'Column List',
		'Add'=>'Column Add',
		'ArticleList'=>'All Article',
		'ArticleAdd'=>'Article add',
		'SearchRecord'=>'Search Record',
		'TagLabel'=>'Tag Label',
		'Jiaodiantu'=>'Focus picture',
		'JiaodiantuAdd'=>'Focus Add'
		),
	'searchkey'=>array(
		'FormTitle'=>'search result',
		'NoResult'=>'No search found.',
		'SearchTips'=>'Keywords you search',
		'Select'=>'Select',
		'Inrow'=>'Inrow',
		'ArticleTitle'=>'Title of article',
		'Operation'=>'Operation',
		'DelTips'=>'Are you sure you want to delete this article?',
		'ChoiceAll'=>'Select all',
		'UnSelect'=>'No choice',
		'ChoiceReverse'=>'Reverse selection',
		'Submit'=>'Add tag label',
		),
	'keywordslist'=>array(
		'FormTitle'=>'Search keywords list',
		'Select'=>'Select',
		'SearchKey'=>'Search keywords',
		'IsResult'=>'Is there any result?',
		'SearchTime'=>'Search time',
		'SearchIp'=>'Search IP',
		'IsView'=>'Does it show',
		'Del'=>'Del',
		'YesResult'=>'Search records',
		'NoResult'=>'No record',
		'DelTips'=>'Are you sure you want to delete this search record?',
		'ChoiceAll'=>'Select all',
		'UnSelect'=>'No choice',
		'ChoiceReverse'=>'Reverse selection',
		'Submit'=>'Delete',
		),
	'del'=>array(
		'DelSuccess'=>'Delete success',
		),
	'dels'=>array(
		'DelSuccess'=>'Delete success',
		'NotSelect'=>'Great God, you want to go to heaven, there is no choice. How do I delete it?',
		),
	'tagsadd'=>array(
		'AddSuccess'=>'Successful entry of tag label',
		'UpdateSuccess'=>'The tag label has been updated.',
		'NotSelect'=>'Great God, you want to go to heaven, there is no choice. How do I operate?',
		),
);
?>
