<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181025 16:00
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：数据备份管理中文简体语言包
 */
return array(
	'common'=>array(
		'Home'=>'Home',
		'DataOperation'=>'Database operation'
		),
	'table'=>array(
		'Select'=>'Select',
		'TableName'=>'Table Name',
		'Remark'=>'Remark',
		'RecodeNum'=>'Record',
		'Size'=>'Size',
		'DataEngine'=>'Database engine',
		'Code'=>'Code',
		'AddTime'=>'Creation time',
		'ViewField'=>'View the field',
		'ChoiceAll'=>'Select all',
		'UnSelect'=>'No choice',
		'ChoiceReverse'=>'Reverse selection',
		'Backup'=>'Backup data table',
		'Optimize'=>'Optimized data table',
		'Repair'=>'Repair data table',
		'Analyze'=>'Analysis data sheet',
		'Execute'=>'Execute',
		'FieldName'=>'Field name',
		'FidldLabel'=>'Field label',
		'FieldType'=>'Field type',
		'FieldDefault'=>'Field defaults'
		),
	'index'=>array(
		'FormTitle'=>'Data backup optimization',
		'NotDatabase'=>"It's not yet recorded. You should be the first one."
		),
	'dotype'=>array(
		'NotSelect'=>'Error, please choose the list again',
		),
	'fieldlist'=>array(
		'FormTitle'=>'Field list',
		),
	'backuplist'=>array(
		'FormTitle'=>'Data restore',
		'NoRecord'=>'No backup records',
		'BackupTime'=>'Backup time',
		'Recover'=>'Restore',
		'RecoverTips'=>'Do you want to restore the database and restore the data?',
		'Del'=>'Del',
		'DelTips'=>'Do you want to delete it?'
		),
	'recoverdata'=>array(
		'RecoverSuccess'=>'Import success',
		'NoFile'=>'file does not exist',
		),
	'del'=>array(
		'DelSuccess'=>'Delete success',
		'NoFile'=>'file does not exist',
		),
);
?>
