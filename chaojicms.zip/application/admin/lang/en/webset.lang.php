<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181025 18:25
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：登录管理英文语言包
 */
return array(
	'set'=>array(
		'Home'=>'Home',
		'FormTitle'=>'Web site settings',
		'UpdateSuccess'=>'Site updated successfully',
		'Basic'=>'Basic',
		'Seo'=>'Seo',
		'Contact'=>'Contact',
		'WebName'=>'Site name',
		'WebNameTips'=>'Please enter the name of the website.',
		'WebUrl'=>'Website access URL',
		'WebUrlTips'=>'Please input the URL: www.domain.com',
		'WebDir'=>'Website root directory',
		'WebDirTips'=>'Please enter the root directory of the website, such as:/',
		'WebIndex'=>'Home link address',
		'WebIndexTips'=>'Please input the home page link address, such as index.html',
		'Img'=>'Web site logo',
		'ImgTips'=>'The first content in the default content is thumbnail.',
		'ImgSelect'=>'Select a picture',
		'ImgChange'=>'Change a picture',
		'ImgDel'=>'Remove',
		'ImgUploadTips'=>'Incorrect upload file type, please select the correct picture file.',
		'WebCopyright'=>'Website bottom copyright area',
		'WebCopyrightTips'=>'The copyright area at the bottom of the website, such as: copyright www.chaojicms.com 2007-2018, all rights reserved.',
		'WebTongji'=>'Statistical code',
		'WebTongjiTips'=>'Please fill in the third party statistical platform JS code.',
		'WebIcp'=>'ICP record number',
		'WebIcpTips'=>'Please enter your website number, please do not leave it blank.',
		'SeoTitle'=>'Seo Title',
		'SeoTitleTips'=>'Please input the seo title. For seo optimization, please input, less than 80 characters.',
		'SeoKeywords'=>'Seo Keywords',
		'SeoKeywordsTips'=>'Please input keywords, separated in English commas, please input for seo optimization, less than 200 characters.',
		'SeoDescription'=>'Seo Description',
		'SeoDescriptionTips'=>'Please input the description, for SEO optimization, please input, less than 200 characters.',
		'WebEmail'=>'E-mail',
		'WebEmailTips'=>'Please enter the e-mail address of the website.',
		'WebQQ'=>'QQ',
		'WebQQTips'=>'Please input QQ, multiple QQ, please use English comma to separate.',
		'WebPhone'=>'Phone number',
		'WebPhoneTips'=>'Please enter your phone number, please dial in English comma.',
		'WebFax'=>'Fax number',
		'WebFaxTips'=>'Please enter the fax number.',
		'WebAddress'=>'Contact address',
		'WebAddressTips'=>'Please input your contact address.',
		'Soft'=>'Server data',
		'SoftUser'=>'User Name of ChaojiCMS Server',
		'SoftUserTips'=>'Please enter the username of the docking ChaojiCMS server ',
		'SoftToken'=>' TOKEN User of ChaojiCMS Server ',
		'SoftTokenTips'=>' Please enter the user TOKEN for docking the ChaojiCMS server ',
		'Submit'=>'Save'
		),
	'setlang'=>array(
		'SetSuccess'=>'Successful language update'
		)
);
?>
