<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181025 17:58
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：导航菜单管理英文语言包
 */
return array(
	'common'=>array(
		'Home'=>'Home'
		),
	'nav'=>array(
		'GroupManage'=>'Menu Group',
		'AddGroup'=>'Add Group',
		'MenuList'=>'Menu List',
		'AddMenu'=>'Add Menu'
		),
	'index'=>array(
		'FormTitle'=>'All menu management lists',
		'NoCategory'=>'No subclasses were found. Please add the categories first.'
		),
	'groupone'=>array(
		'FormTitle'=>'Menu management list',
		'NoMenu'=>'No menu was found in this group. Please add it first.'
		),
	'form'=>array(
		'GroupName'=>'Group Name',
		'GroupNameTips'=>'Please input group name.',
		'GroupLabel'=>'Group Label',
		'GroupLabelTips'=>'Please input group label',
		'MenuManage'=>'Menu Manage',
		'ParentName'=>'Superior column',
		'TopMenu'=>'Top menu',
		'Inrow'=>'Sort',
		'InrowTips'=>'Only allowed numbers, the smaller the number, the closer.',
		'MenuLabel'=>'Menu label',
		'MenuLabelTips'=>'Please enter menu labels',
		'MenuPath'=>'Menu path',
		'MenuPathTips'=>'Please enter menu path.',
		'Iconfont'=>'Iconfont Icon',
		'IconfontTips'=>'Please input menu Iconfont icon',
		'MenuGroup'=>'Menu grouping',
		'MenuTarget'=>'Open mode',
		'MenuTargetSelf'=>'Current window',
		'MenuTargetBlank'=>'New window',
		'Button'=>'Save',
		'Goback'=>'Goback'
		),
	'table'=>array(
		'Inrow'=>'Sort',
		'MenuName'=>'Menu Name',
		'MenuType'=>'Menu Type',
		'ViewSunMenu'=>'View submenu',
		'IsView'=>'show?',
		'IsMain'=>'Navigation menu?',
		'IsOutLink'=>'External links?',
		'Operation'=>'Operation',
		'DelTips'=>'Are you sure you want to delete this menu?',
		'GroupLabel'=>'Group Label',
		'GroupName'=>'Group Name',
		'IsSystem'=>' System field?',
		'DelGroupTips'=>'Are you sure you want to delete this Group?',
		),
	'add'=>array(
		'AddSuccess'=>'New menu success',
		'FormTitle'=>'New menu'
		),
	'edit'=>array(
		'EditSuccess'=>'Menu changes successfully',
		'FormTitle'=>'Edit menu'
		),
	'del'=>array(
		'HaveSunMenu'=>'There are submenus. Please delete the submenu first.',
		'DelSuccess'=>'Delete success'
		),
	'group'=>array(
		'FormTitle'=>'Menu grouping management list',
		'NoGroup'=>'No grouping found. Please add first.'
		),
	'addgroup'=>array(
		'AddSuccess'=>'Successful grouping',
		'TopMenu'=>'Top menu',
		'FormTitle'=>'New grouping',
		),
	'editgroup'=>array(
		'EditSuccess'=>'Menu group modified successfully',
		'FormTitle'=>'Editing and grouping',
		),
	'delgroup'=>array(
		'SysGroup'=>'System grouping cannot be deleted',
		'DelSuccess'=>'Delete success',
		),
);
?>
