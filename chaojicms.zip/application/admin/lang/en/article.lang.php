<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间:20181025 15:00
 * 作者:听云 tinwin@vip.qq.com
 * 功能:文章管理英文语言包
 */
return array(
	'common'=>array(
		'Home'=>'Home',
		'NotSelectCategory'=>'Great God please choose classification first.',
		'ArticleManage'=>'Article management',
		'Basic'=>'Basic',
		'Seo'=>'Seo',
		'Other'=>'Other'
		),
	'table'=>array(
		'Select'=>'Select',
		'Inrow'=>'Inrow',
		'Category'=>'Category',
		'ArticleTitle'=>'Title of article',
		'AddTime'=>'Newstime',
		'EndTime'=>'Update time',
		'IsImg'=>'Thumbnails?',
		'Operation'=>'Operation',
		'View'=>'Browse',
		'Edit'=>'Edit',
		'Del'=>'Del',
		'DelTips'=>'Do you really want to delete this article?',
		'ChoiceAll'=>'Select all',
		'UnSelect'=>'No choice',
		'ChoiceReverse'=>'Reverse selection',
		'Move'=>'Move',
		'Dels'=>'delete select',
		),
	'form'=>array(
		'Title'=>'Title of article',
		'TitleIsok'=>'Congratulations,you can create.',
		'TitleIsnot'=>'The title already exists, please input again',
		'CatName'=>'Column Name',
		'TitleTips'=>'Please input the title of the article.',
		'Content'=>'Content of the article',
		'Inrow'=>'Position ranking',
		'InrowTips'=>'Only allowed numbers, the smaller the number, the closer.',
		'Img'=>'Thumbnail',
		'ImgTips'=>'The first content in the default content is thumbnail.',
		'ImgSelect'=>'Select a picture',
		'ImgChange'=>'Change a picture',
		'ImgDel'=>'Remove',
		'ImgUploadTips'=>'Incorrect upload file type, please select the correct picture file.',
		'SeoTitle'=>'Seo Title',
		'SeoTitleTips'=>'Please input the seo title. For seo optimization, please input, less than 80 characters.',
		'SeoKeywords'=>'Seo Keywords',
		'SeoKeywordsTips'=>'Please input keywords, separated in English commas, please input for seo optimization, less than 200 characters.',
		'SeoDescription'=>'Seo Description',
		'SeoDescriptionTips'=>'Please input the description, for SEO optimization, please input, less than 200 characters.',
		'SeoTags'=>'Tag label',
		'SeoTagsTips'=>'Please enter the tag tag and use English comma to separate it. For SEO optimization, input is less than 200 characters.',
		'View'=>'Times of browsing',
		'ViewTips'=>'Only allowed numbers, the smaller the number, the closer.',
		'Addtime'=>'Newstime',
		'OutFrom'=>'Source',
		'OutUrl'=>'External link url',
		'OutUrlTips'=>'Please input the external link URL and bring HTTP.',
		'SaveButton'=>'Save',
		),
	'nav'=>array(
		'List'=>'Column List',
		'Add'=>'Column Add',
		'ArticleList'=>'All Article',
		'ArticleAdd'=>'Article add',
		'SearchRecord'=>'Search Record',
		'TagLabel'=>'Tag Label',
		'Jiaodiantu'=>'Focus picture',
		'JiaodiantuAdd'=>'Focus Add'
		),
	'manage'=>array(
		'FormTitle'=>'All articles management list',
		),
	'manage_one'=>array(
		'NotSearchArticle'=>"If you haven't found the article, please add the article first",
		'ManageList'=>'Article management list',
		),
	'add'=>array(
		'AddSuccess'=>'Article added success',
		'FormTitle'=>'New article',
		),
	'edit'=>array(
		'EditSuccess'=>'Edit success',
		'FormTitle'=>"Editor's article",
		),
	'CheckTitle'=>array(
		'InputTitle'=>'Please input the title.',
		),
	'del'=>array(
		'DelSuccess'=>'Delete success',
		'DelNot'=>'Delete failed. Article does not exist.',
		),
	'movecat'=>array(
		'MoveSuccessLeft'=>'Successfully moved ',
		'MoveSuccessRight'=>' records',
		'MoveNotSelect'=>'Big God, who are you going to take? You have to choose your goal.',
		),
);
?>
