<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181025 18:10
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：模板管理英文语言包
 */
return array(
	'common'=>array(
		'Home'=>'Home'
		),
	'nav'=>array(
		'Index'=>'Local',
		'Net'=>'Network'
		),
	'index'=>array(
		'IsEnable'=>'Already enabled',
		'InUse'=>'Being used',
		'EnableSkin'=>'Enable template',
		'DelSkin'=>'Delete template',
		'DelSkinTips'=>'After deleting, all files in the template are deleted. Are you sure you want to delete them?',
		'FormTitle'=>'Foreground template setup',
		'NotSkin'=>'No template is found. Please install a set of templates first.',
		'SkinName'=>'Name：',
		'SkinVersion'=>'Version：',
		'SkinAuthor'=>'Template：',
		'UiAuthor'=>'UI：',
		'HtmlAuthor'=>'HTML：',
		'SkinUrl'=>'Url：',
		'Edit'=>'Edit'
		),
	'del'=>array(
		'DelSuccess'=>'Delete success',
		'NotSkin'=>'No template is found. Do not mess around'
		),
	'isEnable'=>array(
		'EnableSuccess'=>'Enable success'
		),
	'net'=>array(
		'FormTitle'=>'Online template',
		'WebBreak'=>'There is no template available on the server. Please try again later.',
		'Tips'=>'After clicking online installation, do not refresh, otherwise the installation is not successful. When the installation is completed, it will automatically jump.',
		'Price'=>'Price：',
		'Author'=>'Author：',
		'View'=>'Preview',
		'NetInstall'=>'Online installation',
		'Sold'=>'Sold：'
		),
	'netinstall'=>array(
		'InstallSuccess'=>'Installation success',
		'InstallFail'=>'Failed to install template'
		),
);
?>
