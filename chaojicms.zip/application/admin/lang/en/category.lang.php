<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181025 15:29
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：分类管理中文简体语言包
 */
return array(
	'common'=>array(
		'Home'=>'Home',
		'NavCategory'=>'Column management',
		'Basic'=>'Basic',
		'Seo'=>'Seo',
		'Other'=>'Other'
		),
	'form'=>array(
		'AppName'=>'The module of',
		'AppArticle'=>'Article module',
		'AppTips'=>'Please input module name.',
		'CatName'=>'Column name',
		'CatNameTips'=>'Please input category names.',
		'ParentCatName'=>'Superior column',
		'TopCatName'=>'Top column',
		'CatalogName'=>'Directory name',
		'CatalogNameTips'=>'Please input directory name, English plus number, English beginning.',
		'CatSkin'=>'Template file',
		'CatSkinTips'=>'Please enter template file name without extension name.',
		'ArticleSkin'=>'Article Details Page Template File',
		'ArticleSkinTips'=>'Please enter template file name without extension name.',
		'Img'=>'Thumbnail',
		'ImgTips'=>'The first content in the default content is thumbnail.',
		'ImgSelect'=>'Select a picture',
		'ImgChange'=>'Change a picture',
		'ImgDel'=>'Remove',
		'ImgUploadTips'=>'Incorrect upload file type, please select the correct picture file.',
		'SeoTitle'=>'Seo Title',
		'SeoTitleTips'=>'Please input the seo title. For seo optimization, please input, less than 80 characters.',
		'SeoKeywords'=>'Seo Keywords',
		'SeoKeywordsTips'=>'Please input keywords, separated in English commas, please input for seo optimization, less than 200 characters.',
		'SeoDescription'=>'Seo Description',
		'SeoDescriptionTips'=>'Please input the description, for SEO optimization, please input, less than 200 characters.',
		'SeoTags'=>'Tag label',
		'SeoTagsTips'=>'Please enter the tag tag and use English comma to separate it. For SEO optimization, input is less than 200 characters.',
		'View'=>'Times of browsing',
		'ViewTips'=>'Only allowed numbers',
		'CatUrl'=>'Link address',
		'CatUrlTips'=>'Please enter the link address. If it is external address, please add http.',
		'OutLink'=>'External links',
		'InLink'=>'Internal link',
		'IsView'=>'Does it show',
		'YesView'=>'Display',
		'NoView'=>'Not display',
		'MenuView'=>'Menu display',
		'IndexView'=>'Home displays',
		'CatPrice'=>'Price',
		'CatPriceTips'=>'It can be used to restrict some catalogues, and can only be previewed through purchase.',
		'SaveButton'=>'Save',
		),
	'nav'=>array(
		'List'=>'Column List',
		'Add'=>'Column Add',
		'ArticleList'=>'All Article',
		'ArticleAdd'=>'Article add',
		'SearchRecord'=>'Search Record',
		'TagLabel'=>'Tag Label',
		'Jiaodiantu'=>'Focus picture',
		'JiaodiantuAdd'=>'Focus Add'
		),
	'table'=>array(
		'Inrow'=>'Sort',
		'CategoryName'=>'column Name',
		'ArticleList'=>'List of articles',
		'CategorySun'=>'Subclass',
		'CategoryAppname'=>'Model',
		'IsView'=>'Does it show',
		'IsHome'=>'Home displays',
		'IsMenu'=>'Menu display',
		'Operation'=>'Operation',
		'Add'=>'Add article',
		'View'=>'Browse',
		'Edit'=>'Edit',
		'Del'=>'Del',
		'DelTips'=>'Are you sure you want to delete this column?'
		),
	'manage'=>array(
		'FormTitle'=>'Manage',
		'NotSunCategory'=>'No sub column was found, please add sub column first.'
		),
	'add'=>array(
		'FormTitle'=>'Add new column',
		'CatalogNameRepeat'=>'The directory name already exists. Please reset it.',
		'AddSuccess'=>'New column success'
		),
	'edit'=>array(
		'FormTitle'=>'Edit column',
		'EditSuccess'=>'Column modification success'
		),
	'del'=>array(
		'DelSuccess'=>'Delete success',
		'IsArticleInCat'=>'There are articles in this column. Please clean up the article first.',
		'IsCategoryInCat'=>'There are sub columns in this column. Please delete the sub column first.'
		),
);
?>
