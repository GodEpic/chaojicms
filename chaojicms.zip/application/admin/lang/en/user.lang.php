<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181017 16:50
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：用户管理中文简体语言包
 */
return array(
	'common'=>array(
		'Home'=>'Home'
		),
	'nav'=>array(
		'UserManage'=>'User list',
		'AddUser'=>'New user',
		),
	'index'=>array(
		'FormTitle'=>'User management list',
		'Username'=>'User name',
		'Nickname'=>'Nickname',
		'UserType'=>'User type',
		'RegisterTime'=>'Register Time',
		'Operation'=>'Operation',
		'Manage'=>'Manage',
		'DefaultUser'=>'DefaultUser',
		'DelTips'=>'Cannot be restored after deletion',
		),
	'search'=>array(
		'FormTitle'=>' search results',
		'SearchTips'=>'Please enter the user name or nickname you want to find.',
		'SearchButton'=>'Search'
		),
	'form'=>array(
		'Username'=>'User name',
		'UsernameTips'=>'Please enter user name (English).',
		'Nickname'=>'Nickname',
		'NicknameTips'=>'Please enter user nicknames.',
		'Psd'=>'Login password',
		'PsdEditTips'=>'No change, please leave blank.',
		'PsdAddTips'=>'Please enter user login password.',
		'Submit'=>'Save'
		),
	'add'=>array(
		'FormTitle'=>'New user',
		'AddSuccess'=>'Add success'
		),
	'edit'=>array(
		'Myself'=>'Personal data editor',
		'EditData'=>'Data Editor'
		),
	'del'=>array(
		'DelSuccess'=>'Delete success',
		'DelMyself'=>'Great God, why do you take things too hard and commit suicide?'
		),
	'loginnav'=>array(
		'loginlog'=>'Login success',
		'loginlogno'=>'Login failure'
		),
	'logintable'=>array(
		'Username'=>'Username',
		'LoginTime'=>'login time',
		'LoginIp'=>'Login ip',
		'Del'=>'Delete',
		'DelTips'=>'Cannot be restored after deletion'
		),
	'loginlog'=>array(
		'FormTitle'=>'Login successful user list',
		),
	'loginlogno'=>array(
		'FormTitle'=>'Login failed user list'
		),
);
?>
