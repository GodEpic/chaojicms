<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181025 14:31
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：模块管理英文语言包
 */
return array(
	'common'=>array(
		'Home'=>'Home',
		'AppName'=>'Name：',
		'AppVersion'=>'Version：',
		'AppAuthor'=>'Author：',
		'Install'=>'Install',
		'InstallTips'=>'Do you install now?',
		'UnInstall'=>'UnInstall',
		'UnInstallTips'=>'Do you want to uninstall and delete the current module data after unloading?',
		'Manage'=>'Manage',
		'InstallOnline'=>'Online installation',
		'AppNow'=>'Current',
		'Upgrade'=>'Upgrade',
		'UpgradeOnline'=>'Online Upgrade',
		'UpgradeTips'=>'Do you want to upgrade now?',
		'NewVersionLabel'=>'Latest version：'
		),
	'nav'=>array(
		'Index'=>'All local modules',
		'Del'=>'Uninstall',
		'Add'=>'Install',
		'Upgrade'=>'Upgrade',
		'Installed'=>'Installed',
		'Online'=>'Online',
		),
	'index'=>array(
		'FormTitle'=>'Module management list',
		'NoApp'=>'No new module found'
		),
	'blank'=>array(
		'FormTitle'=>'Module management list',
		),
	'add'=>array(
		'FormTitle'=>'Install new module',
		'NoApp'=>'No new module found'
		),
	'del'=>array(
		'FormTitle'=>'Unload module',
		'NoApp'=>'No new module found'
		),
	'upgrade'=>array(
		'FormTitle'=>'Upgrade module',
		),
	'appinstall'=>array(
		'Installed'=>'The module has been installed. Do not duplicate installation and reinstall. Please delete install.lock first.',
		'NoInstallFile'=>'Setup file does not exist. Please try again later',
		'InstallSuccess'=>'Installation success',
		'NotOpenWritePower'=>'The directory has no write permission. Please open the write permission and try again.'
		),
	'appuninstall'=>array(
		'UninstallSuccess'=>'Uninstall success',
		),
	'appupgrade'=>array(
		'UpgradeSuccess'=>'Update Successful',
		'IsNewVersion'=>'It is the latest version, and does not need updating.'
		),
	'installed'=>array(
		'FormTitle'=>'Installed module',
		),
	'online'=>array(
		'DelTips'=>'Do you want to uninstall and delete the current module data after unloading?',
		'DelTitle'=>'uninstall',
		'InstallTitle'=>'install',
		'FormTitle'=>'Online installation',
		'OnlineBreak'=>'There is no template available on the server. Please try again later.'
		),
	'netinstall'=>array(
		'DownSuccess'=>' Download Successful, Start Installation',
		'DownSuccess2'=>' Download Successful, Start Upgrade',
		'InstallFail'=>' Installation failed',
		'UpgradeSuccess'=>' Upgrade success'
	)
);
?>
