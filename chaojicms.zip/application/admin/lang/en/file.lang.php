<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181025 17:29
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：文件管理英文语言包
 */
return array(
	'common'=>array(
		'Home'=>'Home'
		),
	'table'=>array(
		'Select'=>'Select',
		'FileName'=>'File Name',
		'FileSize'=>'File Size',
		'FilePath'=>'File Path',
		'EndTime'=>'Modify time',
		'Operation'=>'Operation',
		'DelDir'=>'Del',
		'DelDirTips'=>'Are you sure you want to delete this folder?',
		'EditFile'=>'Edit',
		'DelFile'=>'Del',
		'DelFileTips'=>'Are you sure you want to delete this file?'
		),
	'form'=>array(
		'EditTips'=>'The file is currently edited.:',
		'FileContent'=>'Document content',
		'Save'=>'Save'
		),
	'fileDel'=>array(
		'DelSuccess'=>'Delete success'
		),
	'dirDel'=>array(
		'DelSuccess'=>'Delete success'
		),
	'fileEdit'=>array(
		'FormTitle'=>'File editing',
		'EditSuccess'=>'Edit success',
		'NoEdit'=>'Can not edit, can only edit txt, php, css, JS files'
		),
	'clear'=>array(
		'ClearSuccess'=>'Clear success'
		),
);
?>
