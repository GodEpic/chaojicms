<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181025 17:53
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：后台默认首页英文语言包
 */
return array(
	'common'=>array(
		'Home'=>'Home'
		),
	'index'=>array(
		'Admin'=>'For website security, please modify the background access file /admin.php in time.',
		'AdminDir'=>'For website security, please modify the background access directory admin in time.'
		),
);
?>
