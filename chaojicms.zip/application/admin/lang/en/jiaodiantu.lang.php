<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20190109 15:00
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：焦点图中文简体语言包
 */
return array(
	'common'=>array(
		'Home'=>'Home',
		'NavCategory'=>'Focus management',
		'Basic'=>'Basic',
		'Seo'=>'Seo',
		'Other'=>'Other'
		),
	'nav'=>array(
		'List'=>'Column List',
		'Add'=>'Column Add',
		'ArticleList'=>'All Article',
		'ArticleAdd'=>'Article add',
		'SearchRecord'=>'Search Record',
		'TagLabel'=>'Tag Label',
		'Jiaodiantu'=>'Focus picture',
		'JiaodiantuAdd'=>'Focus Add'
	),
	'form'=>array(
		'Inrow'=>'Position ranking',
		'InrowTips'=>'Only allowed numbers, the smaller the number, the closer.',
		'Img'=>'Thumbnail',
		'ImgTips'=>'The first content in the default content is thumbnail.',
		'ImgSelect'=>'Select a picture',
		'ImgChange'=>'Change a picture',
		'ImgDel'=>'Remove',
		'ImgUploadTips'=>'Incorrect upload file type, please select the correct picture file.',
		'LinkUrlLabel'=>'Link url',
		'LinkUrlTips'=>'Please fill in the picture and click on the link address ',
		'IsView'=>'Does it show',
		'YesView'=>'Display',
		'NoView'=>'Not display',
		'SaveButton'=>'Save',
	),
	'add'=>array(
		'FormTitle'=>'Focus Add'
		),
	'edit'=>array(
		'FormTitle'=>'Focus Edit'
		),
	'index'=>array(
		'FormTitle'=>'Focus List'
		),
	'operation'=>array(
		'AddSuccess'=>'Add success',
		'EditSuccess'=>'Edit success',
		'DelSuccess'=>'Delete success',
	),
);
?>
