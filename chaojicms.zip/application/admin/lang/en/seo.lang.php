<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181025 18:09
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：SEO工具英文语言包
 */
return array(
	'index'=>array(
		'Message'=>'Seo Station Master Tool Module is a unique module of Super CMS. It was proposed by the SEO Research Center (bbs. moonseo. cn) and combined with the practical experience of many teachers. Extract some common functions of SEO personnel to view data directly in the background.'
		),
	'all'=>array(
		'FormTitle'=>'SEO comprehensive information query'
		),
	'enterurl'=>array(
		'FormTitle'=>'Major search engine portal'
		),
	'doamin'=>array(
		'FormTitle'=>'Domain name information list'
		),
	'friendlink'=>array(
		'IsLink'=>'Anti chain',
		'NotLink'=>'No reverse chain',
		'WebBreak'=>'Unable to link URL',
		'AppNotInstall'=>'If you do not install the link module, please install the module first.',
		'FormTitle'=>'Friend chain detection'
		),
);
?>
