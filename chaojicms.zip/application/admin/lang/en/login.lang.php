<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181025 17:55
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：登录管理英文语言包
 */
return array(
	'index'=>array(
		'FormTitle'=>'Administrator login',
		'UsernameTips'=>'enter one user name',
		'PsdTips'=>'Please input a password',
		'Submit'=>'Login'
		),
	'checklogin'=>array(
		'LoginError'=>'Incorrect user name or password. Please login again.'
		),
);
?>
