<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181017 10:29
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：文件管理中文简体语言包
 */
return array(
	'common'=>array(
		'Home'=>'后台首页'
		),
	'table'=>array(
		'Select'=>'选择',
		'FileName'=>'文件名',
		'FileSize'=>'文件大小',
		'FilePath'=>'文件路径',
		'EndTime'=>'修改时间',
		'Operation'=>'操作',
		'DelDir'=>'删除',
		'DelDirTips'=>'确定要删除该文件夹吗？',
		'EditFile'=>'编辑',
		'DelFile'=>'删除',
		'DelFileTips'=>'确定要删除该文件吗？'
		),
	'form'=>array(
		'EditTips'=>'当前正在编辑文件:',
		'FileContent'=>'文件内容',
		'Save'=>'保存'
		),
	'fileDel'=>array(
		'DelSuccess'=>'删除成功'
		),
	'dirDel'=>array(
		'DelSuccess'=>'删除成功'
		),
	'fileEdit'=>array(
		'FormTitle'=>'文件编辑',
		'EditSuccess'=>'编辑成功',
		'NoEdit'=>'不能编辑，只能编辑txt,php,css,js文件'
		),
	'clear'=>array(
		'ClearSuccess'=>'清理成功'
		),
);
?>
