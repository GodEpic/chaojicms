<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181017 15:20
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：SEO工具中文简体语言包
 */
return array(
	'index'=>array(
		'Message'=>'seo站长工具模块是超级CMS特有的模块，由SEO研究中心（bbs.moonseo.cn）提出，结合多位老师的实战经验。提取出一些SEO人员常用的功能在后台直接查看数据。'
		),
	'all'=>array(
		'FormTitle'=>'SEO综合信息查询'
		),
	'enterurl'=>array(
		'FormTitle'=>'各大搜索引擎入口网址'
		),
	'doamin'=>array(
		'FormTitle'=>'域名信息列表'
		),
	'friendlink'=>array(
		'IsLink'=>'有反链',
		'NotLink'=>'无反链',
		'WebBreak'=>'无法链接网址',
		'AppNotInstall'=>'未安装友情链接模块，请先安装该模块',
		'FormTitle'=>'友链检测'
		),
);
?>
