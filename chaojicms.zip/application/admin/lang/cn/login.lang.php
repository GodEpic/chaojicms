<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181017 11:00
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：登录管理中文简体语言包
 */
return array(
	'index'=>array(
		'FormTitle'=>'管理员登录',
		'UsernameTips'=>'请输入用户名',
		'PsdTips'=>'请输入密码',
		'Submit'=>'登录'
		),
	'checklogin'=>array(
		'LoginError'=>'用户名或密码错误，请重新登录'
		),
);
?>
