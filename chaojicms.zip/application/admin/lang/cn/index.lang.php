<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181017 10:50
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：后台默认首页中文简体语言包
 */
return array(
	'common'=>array(
		'Home'=>'后台首页'
		),
	'index'=>array(
		'Admin'=>'为了网站安全，请及时修改后台访问文件/admin.php',
		'AdminDir'=>'为了网站安全，请及时修改后台访问目录admin'
		),
);
?>
