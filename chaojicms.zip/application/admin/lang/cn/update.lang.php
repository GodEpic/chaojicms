<?php
if(!defined('IN_DSW')){exit('大神请返回地球，我们需要你');}
/*
 * 时间：20181017 16:30
 * 作者：牛哥 tinwin@vip.qq.com
 * 功能：系统更新中文简体语言包
 */
return array(
	'index'=>array(
		'FormTitle'=>'系统更新',
		'FindNewVersion'=>'发现最新版本',
		'UpdateNow'=>'现在升级',
		'NotUpdate'=>'当前已是最新版',
		'UpgradeSuccess'=>'升级成功',
		'UpgradeFail'=>'升级失败'
		),
	'checkversion'=>array(
		'ErrorTips'=>'版本检测异常,请查看用户名和token配置是否正确',
		'Edit'=>'编辑',
		'Register'=>'站点注册'
		),
);
?>
