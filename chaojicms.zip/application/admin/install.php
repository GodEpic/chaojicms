<?php
!defined('IN_DSW') && exit('大神请勿乱策');
/*1.33 $sql="
ALTER TABLE `".DB_PREFIX."category` ADD `article_skin` VARCHAR(100) NOT NULL DEFAULT 'article_view' COMMENT '文章详情页皮肤' AFTER `cat_skin`;";*/
$this->dbpdo->exec($sql);
?>