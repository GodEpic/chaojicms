<?php
class user_admin{
	public $G;
	public function __construct(&$G){
		$this->G = $G;
	}

	public function _init(){
		$this->dbpdo=$this->G->loadclass('dbpdo');
		$this->routes = $this->G->loadclass('routes');
		$this->pages = $this->G->loadclass('pages');
	}
	
	//用户登录
	public function getLogin($dsw){
		return $this->dbpdo->getOne('user','*',$dsw);
	}

	//通过用户名获取ID
	public function getUidByNick($nickname){
		return $this->dbpdo->getOne('user','id',array('nickname'=>$nickname));
	}

	//通过用户ID获取用户信息
	public function getOneByID($IntID){
		return $this->dbpdo->getOne('user','*',array('id'=>$IntID));
	}

	//通过用户ID获取用户信息
	public function getNickByID($IntID){
		return $this->dbpdo->getOne('user','nickname',array('id'=>$IntID));
	}

	//新增用户
	public function save($args){
		$this->dbpdo->insert_data("user",$args);
		return $this->dbpdo->getInsertId();
	}

	//获取所有用户
	public function getAll(){
		return $this->dbpdo->query("user",'*','','','inrow');
	}

	//获取所有用户分页形式
	public function getList($Spage=1,$Snumber=PAGED,$condition="",$UrlStyle=""){
		$rs['data']=$this->dbpdo->query("user",'*',$condition,"","","",strval(intval($Spage-1)*$Snumber),$Snumber);
		$t=$this->dbpdo->getOne("user",'count(*) AS total',$condition);
		$Intpages = $this->pages->set_page_info($t['total'],$Snumber,$UrlStyle);
		if($rs){
			$rs['pages']=$Intpages;
			$rs['total'] = $t['total'];
			return $rs;
		}
	}

	//删除用户
	public function del($IntID){
		return $this->dbpdo->remove("user",array("id"=>$IntID));
	}

	public function update($dsw,$condition=array()){
		return $this->dbpdo->update_data('user',$dsw,$condition);
	}
	

	public function isadmin($IntID){
		$Strok="";
		$list=$this->dbpdo->getOne("user","*",array('id' => $IntID));
		if($list['isadmin']==0){
			$row=array(
				'endtime'=>time(),
				'enduser'=>$_SESSION['tinwinsession']['uid'],
				'isadmin'=>1
			);
			$Strok='管理员';
		}else{
			$row=array(
				'endtime'=>time(),
				'enduser'=>$_SESSION['tinwinsession']['uid'],
				'isadmin'=>0
			);
			$Strok='普通用户';
		}
		$this->dbpdo->update_data('user',$row,array('id' => $IntID));
		return $Strok;
	}
}
?>
