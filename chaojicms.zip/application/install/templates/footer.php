<?php !defined('IN_DSW') && exit('大神请按规矩来'); ?>
<footer> &copy; 2008-<?php echo date("Y") ?> <a href="<?php echo SOFTURL;?>" target="_blank"><?php echo SOFTNAME;?></a></footer>