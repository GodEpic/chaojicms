<?php !defined('IN_DSW') && exit('大神请按规矩来');
$scriptName2 = !empty($_SERVER["REQUEST_URI"]) ? $scriptName2 = $_SERVER["REQUEST_URI"] : $scriptName2 = $_SERVER["PHP_SELF"];
$rootpath2 = @preg_replace("/\/application\/(I|i)nstall\/index\.php(.*)$/", "", $scriptName2);
?>
<!doctype html>
<html>
    <head>
        <meta charset="UTF-8" />
        <title><?php echo $Title; ?></title>
        <link rel="stylesheet" href="./css/install.css?v=9.0" />
		<script src="./js/jquery.js?v=9.0"></script>
    </head>
    <body>
        <div class="wrap">
            <?php require './templates/header.php'; ?>
            <section class="section">
                <div class="">
                    <div class="success_tip cc"><span class="f16 b" style="padding-right:20px;">安装完成，"点击进入" </span><a href="<?php echo $rootpath2; ?>/index.php?admin-master-login" class="f16 b" style="padding-right:20px;">后台管理</a> <a href="<?php echo $rootpath2; ?>/index.php" class="f16 b">前台首页</a></div>
                    <div class=""> </div>
                </div>
            </section>
        </div>
        <?php require './templates/footer.php'; ?>
    </body>
	<script type="text/javascript">
		$(document).ready(function(){
			$.post("<?php echo SOFTURL;?>/index.php?api-get-index-url&url=<?php echo SITE_WEB;?>&stype=<?php echo SOFTTYPE;?>");
		});
	</script>
</html>
