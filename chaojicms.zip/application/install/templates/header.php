<?php !defined('IN_DSW') && exit('大神请按规矩来'); ?>
<header>
    <h1 class="logo"><span><?php echo SOFTNAME;?></span></h1>
    <div class="icon_install">安装向导</div>
    <div class="version"><?php echo VERSION;?></div>
</header>