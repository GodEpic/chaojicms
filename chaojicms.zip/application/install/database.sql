-- 主机: localhost
-- 生成日期: 2018 广05 朿19 旿14:05
-- 服务器版本: 5.5.53
-- PHP 版本: 5.6.27

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `tinwin11`
--

-- --------------------------------------------------------

--
-- 表的结构 `dsw_apps`
--

CREATE TABLE IF NOT EXISTS `dsw_apps` (
  `appname` varchar(30) NOT NULL COMMENT '模块名称',
  `applabel` varchar(60) NOT NULL DEFAULT '' COMMENT '模块标签',
  `appfile` varchar(100) NOT NULL COMMENT '文件',
  `appimg` varchar(240) NOT NULL DEFAULT '' COMMENT '模块缩略图',
  `isview` int(1) NOT NULL DEFAULT '0' COMMENT '模块状态',
  `author` varchar(50) NOT NULL COMMENT '作者',
  `iscore` int(1) NOT NULL DEFAULT '0' COMMENT '是否核心模块',
  `appversion` varchar(10) NOT NULL COMMENT '版本',
  `appsetting` text NOT NULL COMMENT '模块设置',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `ismenu` int(1) NOT NULL DEFAULT '1' COMMENT '是否在导航菜单',
  `addtime` int(10) NOT NULL COMMENT '安装时间',
  `endtime` int(10) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`appname`),
  KEY `appstatus` (`isview`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='模块管理' ;

--
-- 表的结构 `dsw_apps_upgrade`
--

CREATE TABLE IF NOT EXISTS `dsw_apps_upgrade` (
  `appname` varchar(30) NOT NULL COMMENT '模块名称',
  `appversion` varchar(10) NOT NULL COMMENT '版本',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `addtime` int(10) NOT NULL COMMENT '安装时间',
  PRIMARY KEY (`appname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='模块升级记录' ;


--
-- 表的结构 `dsw_article`
--

CREATE TABLE IF NOT EXISTS `dsw_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inrow` int(11) NOT NULL COMMENT '排序',
  `addtime` int(11) NOT NULL COMMENT '创建时间',
  `adduser` int(11) NOT NULL COMMENT '创建者',
  `endtime` int(11) NOT NULL COMMENT '更新时间',
  `enduser` int(11) NOT NULL COMMENT '更新用户',
  `cat_id` int(11) NOT NULL COMMENT '分类ID',
  `title` varchar(80) NOT NULL COMMENT '文章标题',
  `seo_title` varchar(100) NOT NULL COMMENT 'SEO标题',
  `seo_description` varchar(255) NOT NULL COMMENT 'SEO描述',
  `seo_keywords` varchar(255) NOT NULL COMMENT 'SEO关键词',
  `seo_tags` varchar(255) NOT NULL COMMENT 'tag标签',
  `seo_relation` text NOT NULL COMMENT '相关文章',
  `content` text NOT NULL COMMENT '文章内容',
  `img` varchar(255) NOT NULL COMMENT '文章缩略图',
  `out_from` varchar(30) NOT NULL COMMENT '来源',
  `out_url` varchar(255) NOT NULL COMMENT '外部网址',
  `view` int(11) NOT NULL COMMENT '阅读次数',
  `zan` int(11) DEFAULT NULL COMMENT '点赞量',
  `zan_uid` text COMMENT '点赞的用户ID',
  `fixedtime` int(11) NOT NULL COMMENT '定时发送',
  `attribute` varchar(255) NOT NULL COMMENT '文章属性',
  `isview` int(1) NOT NULL COMMENT '是否显示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 COMMENT='文章';

-- --------------------------------------------------------
CREATE TABLE `dsw_article_attribute` (
  `att_name` varchar(100) NOT NULL COMMENT '名称',
  `att_label` varchar(255) NOT NULL COMMENT '描述',
  PRIMARY KEY (`att_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文章属性' ;

--
-- 表的结构 `dsw_category`
--

CREATE TABLE IF NOT EXISTS `dsw_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inrow` int(11) NOT NULL COMMENT '排序',
  `appname` varchar(50) NOT NULL DEFAULT 'article' COMMENT '所属应用',
  `parent_id` int(11) NOT NULL COMMENT '父ID',
  `cat_name` varchar(100) NOT NULL COMMENT '分类名称',
  `catalog_name` varchar(30) NOT NULL COMMENT '目录名',
  `cat_url` varchar(100) NOT NULL COMMENT '链接地址',
  `cat_img` varchar(255) NOT NULL COMMENT '分类缩略图',
  `cat_skin` varchar(100) NOT NULL COMMENT '栏目皮肤',
  `article_skin` varchar(100) NOT NULL COMMENT '文章详情页皮肤',
  `cat_price` int(11) NOT NULL DEFAULT '0' COMMENT '价格',
  `seo_title` varchar(100) NOT NULL COMMENT 'SEO标题',
  `seo_keywords` varchar(255) NOT NULL COMMENT 'SEO关键词',
  `seo_description` varchar(255) NOT NULL COMMENT 'SEO描述',
  `cat_view` int(11) NOT NULL COMMENT '浏览次数',
  `ismenu` int(11) NOT NULL DEFAULT '0' COMMENT '是否在菜单显示1为显示，0为不显示',
  `isview` int(1) NOT NULL COMMENT '是否显示',
  `isindex` int(1) NOT NULL COMMENT '在首页显示',
  `isoutlink` int(1) NOT NULL DEFAULT '0' COMMENT '是否为外部链接',
  `rank` int(3) NOT NULL COMMENT '等级,层级',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='栏目分类' AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

INSERT INTO `dsw_category` (`id`, `inrow`, `appname`, `parent_id`, `cat_name`, `catalog_name`, `cat_url`, `cat_img`, `cat_skin`, `cat_price`, `seo_title`, `seo_keywords`, `seo_description`, `ismenu`, `isview`, `isindex`, `isoutlink`, `rank`) VALUES
(1, 0, 'article', 0, '关于我们', 'about', '', '', 'about', 0, '关于我们', '', '', 0, 1, 0, 0, 1),
(2, 0, 'article', 0, '新闻中心', 'news', '', '', '', 0, '', '', '', 0, 1, 0, 0, 1),
(3, 0, 'article', 0, '联系我们', 'contactus', '', '', 'contactus', 0, '', '', '', 0, 1, 0, 0, 1),
(4, 0, 'article', 0, '服务', 'service', '', '', 'service', 0, '', '', '', 0, 1, 0, 0, 1),
(5, 0, 'article', 0, '成功案例', 'case', '', '', 'case', 0, '', '', '', 0, 1, 0, 0, 1);
--
-- 表的结构 `dsw_navmenu`
--
CREATE TABLE IF NOT EXISTS `dsw_jiaodiantu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(255) NOT NULL COMMENT '图片地址',
  `linkurl` varchar(255) NOT NULL COMMENT '链接地址',
  `isview` int(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `inrow` int(2) NOT NULL COMMENT '排序',
  `addtime` int(10) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `dsw_navmenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inrow` int(10) DEFAULT '0' COMMENT '排序',
  `adduser` int(11) DEFAULT '0' COMMENT '首次添加人员',
  `addtime` int(10) DEFAULT '0' COMMENT '首次添加时间',
  `enduser` int(11) DEFAULT '0' COMMENT '更新人员',
  `endtime` int(10) DEFAULT '0' COMMENT '更新时间',
  `menu_name` varchar(30) DEFAULT '空' COMMENT '菜单名称，英文',
  `menu_label` varchar(30) DEFAULT '空' COMMENT '菜单标签，中文',
  `menu_path` varchar(200) DEFAULT '空' COMMENT '菜单路径',
  `menu_img` varchar(255) NOT NULL COMMENT '导航图片',
  `parent_id` int(10) DEFAULT '0' COMMENT '上级菜单',
  `menu_target` varchar(30) NOT NULL COMMENT '打开方式',
  `menu_type` varchar(10) NOT NULL COMMENT 'admin后台菜单，home前台菜单，tinwin特殊菜单',
  `rank` int(10) DEFAULT '0' COMMENT '层级，顶级菜单为1，每增加一层下级菜单加1',
  `ismain` int(1) DEFAULT '0' COMMENT '是否主导航',
  `isview` int(1) DEFAULT '1' COMMENT '是否显示（1显示，0不显示）',
  `isoutlink` int(1) NOT NULL DEFAULT '0' COMMENT '是否为外部链接（1为外部链接）',
  `iconfont` varchar(50) NOT NULL COMMENT 'iconfont图标',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 COMMENT='菜单' ;

--
-- 转存表中的数据 `dsw_navmenu`
--
INSERT INTO `dsw_navmenu` (`id`, `inrow`, `adduser`, `addtime`, `enduser`, `endtime`, `menu_name`, `menu_label`, `menu_path`, `menu_img`, `parent_id`, `menu_target`, `menu_type`, `rank`, `ismain`, `isview`, `isoutlink`, `iconfont`) VALUES
(1, 1, 0, 0, 1, 1524917878, 'system', '系统设置', 'main', '', 0, '', 'admin', 0, 1, 1, 0, 'glyphicon glyphicon-cog'),
(2, 1, 0, 0, 0, 0, 'webset', '系统基本设置', 'webset', '', 1, '', 'admin', 0, 0, 1, 0, ''),
(3, 2, 0, 0, 0, 0, 'navmenu', '菜单管理', 'navmenu', '', 1, '', 'admin', 0, 0, 1, 0, ''),
(4, 3, 0, 0, 0, 0, 'filemanage', '文件管理器', 'file', '', 1, '', 'admin', 0, 0, 1, 0, ''),
(5, 4, 0, 0, 0, 0, 'fileclear', '清除缓存', 'file-clear', '', 1, '', 'admin', 0, 0, 1, 0, ''),
(6, 2, 0, 0, 1, 1524918255, 'articlemanage', '内容管理', 'article', '', 0, '', 'admin', 0, 1, 1, 0, 'glyphicon glyphicon-th-list'),
(7, 1, 0, 0, 0, 0, 'articlemanage', '所有文章列表', 'article', '', 6, '', 'admin', 0, 0, 1, 0, ''),
(8, 2, 0, 0, 0, 0, 'catmanage', '栏目管理', 'category', '', 6, '', 'admin', 0, 0, 1, 0, ''),
(9, 3, 0, 0, 0, 0, 'searchlist', '搜索记录管理', 'search-keywordslist', '', 6, '', 'admin', 0, 0, 1, 0, ''),
(10, 4, 0, 0, 0, 0, 'tags', 'tags管理', 'tags', '', 6, '', 'admin', 0, 0, 1, 0, ''),
(11, 3, 0, 0, 0, 0, 'appindex', '模块管理', 'apps-index', '', 1, '', 'admin', 0, 0, 1, 0, ''),
(12, 5, 0, 0, 1, 1524919178, 'usermanage', '用户管理', 'user', '', 0, '', 'admin', 0, 1, 1, 0, 'glyphicon glyphicon-user'),
(13, 1, 0, 0, 0, 0, 'usermanage', '用户管理', 'user-manage', '', 12, '', 'admin', 0, 0, 1, 0, ''),
(14, 2, 0, 0, 0, 0, '空', '登录记录', 'user-loginlog', '', 12, '', 'admin', 0, 0, 1, 0, ''),
(16, 4, 0, 0, 0, 0, 'main', '已装模块', 'main', '', 0, '', 'admin', 0, 1, 1, 0, 'glyphicon glyphicon-cloud-download'),
(17, 3, 0, 0, 0, 1524919326, '空', '模板管理', 'skin', '', 1, '', 'admin', 0, 0, 1, 0, ''),
(18, 6, 0, 0, 1, 1525423129, '空', '数据库管理', 'database', '', 0, '', 'admin', 0, 1, 1, 0, 'glyphicon glyphicon-tasks'),
(19, 1, 0, 0, 0, 0, '空', '数据备份/修复/优化', 'data-index', '', 18, '', 'admin', 0, 0, 1, 0, ''),
(20, 2, 0, 0, 0, 0, '空', '数据还原', 'data-backuplist', '', 18, '', 'admin', 0, 0, 1, 0, ''),
(21, 7, 0, 0, 1, 1525762992, '空', 'SEO站长工具', 'seo', '', 0, '', 'admin', 0, 1, 1, 0, 'glyphicon glyphicon-magnet'),
(22, 1, 0, 0, 0, 0, '空', '搜索引擎入口提交', 'seo-enterurl', '', 21, '', 'admin', 0, 0, 1, 0, ''),
(23, 2, 0, 0, 0, 0, '空', 'SEO综合查询', 'seo-all', '', 21, '', 'admin', 0, 0, 1, 0, ''),
(24, 3, 0, 0, 0, 0, '空', '域名whois', 'seo-whois', '', 21, '', 'admin', 0, 0, 1, 0, ''),
(25, 4, 0, 0, 0, 0, '空', '友链检测', 'seo-friendlink', '', 21, '', 'admin', 0, 0, 1, 0, ''),
(26, 5, 0, 0, 0, 0, '空', '焦点图管理', 'jiaodiantu', '', 6, '', 'admin', 0, 0, 1, 0, '');
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `dsw_navmenu_group` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `inrow` int(5) NOT NULL COMMENT '排序',
  `group_name` varchar(10) NOT NULL COMMENT '菜单分类名称',
  `group_label` varchar(30) NOT NULL COMMENT '菜单分类标签',
  `issys` int(1) NOT NULL DEFAULT '0' COMMENT '是否系统字段 1是，0不是',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='菜单分类' AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `dsw_navmenu_group`
--

INSERT INTO `dsw_navmenu_group` (`id`, `inrow`, `group_name`, `group_label`, `issys`) VALUES
(1, 1, 'admin', '后台菜单', 1),
(2, 2, 'home', '前台菜单', 1);
--
-- 表的结构 `dsw_search`
--

CREATE TABLE IF NOT EXISTS `dsw_search` (
  `search_id` int(11) NOT NULL AUTO_INCREMENT,
  `search_keywords` varchar(255) NOT NULL COMMENT '搜索关键词',
  `search_type` varchar(10) NOT NULL COMMENT '搜索类型',
  `search_time` int(10) NOT NULL COMMENT '搜索时间',
  `search_ip` varchar(100) NOT NULL COMMENT 'IP',
  `issearch` int(1) NOT NULL DEFAULT '1' COMMENT '是否有搜索结果',
  `isview` int(1) NOT NULL DEFAULT '1' COMMENT '是否显示,1为显示,0为不显示',
  PRIMARY KEY (`search_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 COMMENT='搜索记录' ;

-- --------------------------------------------------------

--
-- 表的结构 `dsw_tags`
--

CREATE TABLE IF NOT EXISTS `dsw_tags` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_label` varchar(100) NOT NULL COMMENT '标签名称',
  `tag_article` text COMMENT '文章标签',
  PRIMARY KEY (`tag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 COMMENT='tag标签' ;

-- --------------------------------------------------------

--
-- 表的结构 `dsw_uploadfile`
--

CREATE TABLE IF NOT EXISTS `dsw_uploadfile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inrow` int(10) DEFAULT '0' COMMENT '排序',
  `adduser` int(11) DEFAULT '0' COMMENT '首次添加人员',
  `addtime` int(10) DEFAULT '0' COMMENT '首次添加时间',
  `enduser` int(11) DEFAULT '0' COMMENT '更新人员',
  `endtime` int(10) DEFAULT '0' COMMENT '更新时间',
  `file_name` varchar(100) DEFAULT '空' COMMENT '文件名称',
  `file_url` varchar(255) DEFAULT '空' COMMENT '文件网址路径',
  `file_type` varchar(15) DEFAULT '空' COMMENT '文件类型',
  `file_size` int(11) NOT NULL COMMENT '文件大小',
  `file_ext` varchar(10) NOT NULL COMMENT '附件扩展名',
  `aid` int(11) NOT NULL DEFAULT '0' COMMENT '文章ID',
  `cid` int(11) NOT NULL DEFAULT '0' COMMENT '分类ID',
  `ip` varchar(50) NOT NULL COMMENT 'IP地址',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 COMMENT='上传文件管理' ;

-- --------------------------------------------------------

--
-- 表的结构 `dsw_user`
--

CREATE TABLE IF NOT EXISTS `dsw_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inrow` int(10) DEFAULT '0' COMMENT '排序',
  `adduser` int(11) DEFAULT '0' COMMENT '首次添加人员',
  `addtime` int(10) DEFAULT '0' COMMENT '首次添加时间',
  `enduser` int(11) DEFAULT '0' COMMENT '更新人员',
  `endtime` int(10) DEFAULT '0' COMMENT '更新时间',
  `username` varchar(100) NOT NULL DEFAULT '空' COMMENT '用户名',
  `psd` varchar(200) NOT NULL DEFAULT '空' COMMENT '密码',
  `nickname` varchar(30) DEFAULT '空' COMMENT '网名',
  `issuper` int(1) DEFAULT '0' COMMENT '是否超级管理，1为超级管理，0为普通用户（默认）',
  `isadmin` int(1) DEFAULT '0' COMMENT '是否后台管理，1为后台管理，0为普通用户（默认）',
  `isdel` int(1) DEFAULT '0' COMMENT '是否删除，1为删除，0为有效',
  `istjr` int(1) DEFAULT '0' COMMENT '是否推荐人',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 COMMENT='用户表' ;

-- --------------------------------------------------------

--
-- 表的结构 `dsw_userlogin`
--

CREATE TABLE IF NOT EXISTS `dsw_userlogin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL COMMENT '用户名',
  `addtime` int(10) DEFAULT '0' COMMENT '首次添加时间',
  `login_ip` varchar(50) DEFAULT '空' COMMENT '登陆IP',
  `login_status` int(1) NOT NULL COMMENT '登陆状态：1为成功，0为失败',
  `remark` text COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 COMMENT='用户登录记录' ;

-- --------------------------------------------------------

--
-- 表的结构 `dsw_user_level`
--

CREATE TABLE IF NOT EXISTS `dsw_user_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inrow` int(10) DEFAULT '0' COMMENT '排序',
  `adduser` int(11) DEFAULT '0' COMMENT '首次添加人员',
  `addtime` int(10) DEFAULT '0' COMMENT '首次添加时间',
  `enduser` int(11) DEFAULT '0' COMMENT '更新人员',
  `endtime` int(10) DEFAULT '0' COMMENT '更新时间',
  `uid` int(11) DEFAULT '0' COMMENT '用户ID',
  `parent_id` int(10) DEFAULT '1' COMMENT '父ID',
  `user_sun` text COMMENT '子用户',
  `menu_level` text COMMENT '菜单访问权限',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 COMMENT='用户权限' ;

-- --------------------------------------------------------

--
-- 表的结构 `dsw_webconfig`
--

CREATE TABLE IF NOT EXISTS `dsw_webconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inrow` int(10) DEFAULT '0' COMMENT '排序',
  `adduser` int(11) DEFAULT '0' COMMENT '首次添加人员',
  `addtime` int(11) DEFAULT '0' COMMENT '首次添加时间',
  `enduser` int(11) DEFAULT '0' COMMENT '更新人员',
  `endtime` int(11) DEFAULT '0' COMMENT '更新时间',
  `varname` varchar(30) NOT NULL DEFAULT '' COMMENT '名称',
  `varlabel` varchar(200) NOT NULL DEFAULT '' COMMENT '标签',
  `appname` varchar(30) NOT NULL DEFAULT '' COMMENT '对应APP，网站为website',
  `value` text COMMENT '名称所对应的值',
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '是否有效',
  `issys` int(1) NOT NULL DEFAULT '0' COMMENT '是否是系统字段，1是，0不是',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 COMMENT='网站配置' ;

--
-- 转存表中的数据 `dsw_webconfig`
--

INSERT INTO `dsw_webconfig` (`id`, `inrow`, `adduser`, `addtime`, `enduser`, `endtime`, `varname`, `varlabel`, `appname`, `value`, `status`, `issys`) VALUES
(1, 0, 0, 0, 0, 0, 'web_lang', '网站语言', 'website', 'cn', 1, 1),
(2, 0, 0, 0, 0, 0, 'web_name', '网站名称', 'website', '演示站点 ', 1, 1),
(3, 0, 0, 0, 0, 0, 'web_dir', '网站目录', 'website', '/', 1, 1),
(4, 0, 0, 0, 0, 0, 'homeskin', '网站前台模板目录', 'website', 'default', 1, 1),
(5, 0, 0, 0, 0, 0, 'adminskin', '网站后台模板目录', 'website', 'default', 1, 1),
(6, 0, 0, 0, 0, 0, 'web_title', '网站标题', 'website', '演示站点', 1, 1),
(7, 0, 0, 0, 0, 0, 'web_logo', '网站logo', 'website', '/static/images/logo.png', 1, 1),
(8, 0, 0, 0, 0, 0, 'seo_title', 'seo标题', 'website', '超级CMS演示站点', 1, 1),
(9, 0, 0, 0, 0, 0, 'seo_keywords', 'seo关键词', 'website', '超级CMS,CMS,懂网站优化的系统', 1, 1),
(10, 0, 0, 0, 0, 0, 'seo_description', 'seo描述', 'website', '超级CMS内容管理系统（以下简称产品）由SEO研究中心为了解决网站优化问题而研发的一套产品，本产品采用面向对象方式自助研发的MVC框架开发，它是一款高效开源的内容管理系统，产品基于PHP+MYSQL架构，可运行在Windows、Linux、MacOSX、Solaris等各种平台上', 1, 1),
(11, 0, 0, 0, 0, 0, 'web_copyright', '网站底部版权区域', 'website', 'copyright © 2007-2018 www.chaojicms.com 版权所有', 1, 1),
(12, 0, 0, 0, 0, 0, 'web_index', '首页链接地址', 'website', 'index.html', 1, 1),
(13, 0, 0, 0, 0, 0, 'web_email', '网站email', 'website', '', 1, 1),
(14, 0, 0, 0, 0, 0, 'web_url', '网站网址', 'website', 'http://www.chaojicms.com', 1, 1),
(15, 0, 0, 0, 0, 0, 'web_qq', '网站QQ', 'website', '', 1, 1),
(16, 0, 0, 0, 0, 0, 'web_phone', '电话号码', 'website', '', 1, 1),
(17, 0, 0, 0, 0, 0, 'web_fax', '传真号码', 'website', '', 1, 1),
(18, 0, 0, 0, 0, 0, 'web_address', '联系地址', 'website', '', 1, 1),
(19, 0, 0, 0, 0, 0, 'web_tongji', '统计代码', 'website', '', 1, 1),
(20, 0, 0, 0, 0, 0, 'web_icp', '备案号', 'website', '湘ICP备16014093号-2', 1, 1),
(21, 0, 0, 0, 0, 0, 'soft_user', '服务端用户名', 'website', '', 1, 1),
(22, 0, 0, 0, 0, 0, 'soft_token', '服务端token', 'website', '', 1, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
