<?php
include_once(dirname(__FILE__)."/data/common.inc.php");
header('Location:index.php?'.ADMINNAME.'-master-login');
?>