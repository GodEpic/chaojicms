<?php
!defined('IN_DSW') && exit('大神你要飞呀');
return array(
    //软件信息
	'soft_type'=>'free',
    'soft_version'=>'2.18',     // 系统版本
    'soft_name' => '超级CMS-营销型网站管理系统',  // 系统名称
    'soft_date' => '2019-03-19',    // 更新日期
    'soft_url'=>'http://www.chaojicms.com' //系统版本检测地址
);
?>