<?php
!defined('IN_DSW') && exit('大神你要飞呀');
return array(
    //数据库配置
    'db_type'   => 'mysql',     // 数据库类型
    'db_host' => '127.0.0.1',  // 服务器地址
    'db_name' => 'chaojicms',    // 数据库名
    'db_user' => 'root',      // 用户名
    'db_pwd' => 'root',          // 密码
    'db_port' => 3306,        // 端口
    'db_prefix' => 'dsw_',      // 数据库表前缀
    'db_charset'=>'utf8'
);
?>