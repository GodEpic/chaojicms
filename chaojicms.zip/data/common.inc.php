<?php
//set_time_limit(0);
//括号里边的数字是执行时间，如果为零说明永久执行直到程序结束，如果为大于零的数字，则不管程序是否执行完成，到了设定的秒数，程序结束。 
date_default_timezone_set("Asia/Shanghai");//默认是英国时间

define('WEB_CHARSET','utf-8');//网站编码
define('WEB_KEY',md5(base64_encode($_SERVER['SERVER_NAME'])));//网站隐私数据加密码
define('CIIKIE_PATH','/');//CIIKIE作用域
define('TIME',time());
define('USERWX',FALSE);//判断是否微信
define('COOKIS_PRE','tinwin_');//COOKIE前缀
define('COOKIS_PATH',ROOT_PATH.'data/cookis/');//COOKIE路径

define('APP_PATH', ROOT_PATH.'application/');

define('DATA_HTML', ROOT_PATH.'data/html/');
define('DATA_COMPILE', ROOT_PATH.'data/compile/');
define('DATA_CACHE', ROOT_PATH.'data/cache/');
define('DATA_BACKUP', ROOT_PATH.'data/backup/');

define('PAGED',10);//分页数

define('SITE_HTTP', 'http://');
define('SITE_URL', $_SERVER['SERVER_NAME']);
define('SITE_WEB', SITE_HTTP.SITE_URL);
define('UPLOAD_PATH_IMG', '/static/upload/image/'.date('Ymd').'/');

define('HOMENAME','home');
define('ADMINNAME','admin');
?>