<?php
header('Location:/application/install/index.php');
?>