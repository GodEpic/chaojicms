/*2017-08-13*/
function dswfirm(s,t){//利用对话框返回的值（true 或者 false） 
    if(confirm(t))
    {//如果是true ，那么就把页面转向
        location.href=s; 
    } 
};
function DisplayOK(obj){//加载jq load
    $(obj).load($(obj).attr("id"));
};
function choiceAll(obj){//全选 需要jq
    $("tbody").find("input").prop("checked", true);
};
function unSelect(obj){//不选 需要jq
    $("tbody").find("input").prop("checked", false);  
};
function choiceReverse(obj){//反选 需要jq
    $("tbody").find("input").each(function () {  
        $(this).prop("checked", !$(this).prop("checked"));  
    });
};

