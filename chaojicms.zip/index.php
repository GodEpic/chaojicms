<?php
session_start();
set_time_limit(0);

define('IN_DSW', true);
defined('ROOT_PATH') or define('ROOT_PATH', str_replace('\\', '/', dirname(__FILE__)).'/');
define('DATA_PATH', ROOT_PATH.'data/');
define('DEBUG',true);
if(DEBUG){    
    ini_set('display_errors','On');
}else{
	error_reporting(E_ALL);//E_ALL表示提示所有错误，0表示提示错误，运营时请设置为0;
    ini_set('display_errors','Off');
}
require ROOT_PATH."lib/chaojicms.class.php";
$chaojicms = new chaojicms;
$chaojicms->run();
?>