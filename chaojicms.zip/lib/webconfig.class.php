<?php
/*
 * 网站系统信息设置类
 * 2018-04-25
 * */
class webconfig{
	public $G;
	public function __construct(&$G){
		$this->G = $G;
	}

	public function _init(){
		$this->dbpdo=$this->G->loadclass('dbpdo');
		$this->routes = $this->G->loadclass('routes');
		$this->files = $this->G->loadclass('files');
	}

	public function getAll($condition=array()){
		if(is_array($condition)&&!empty($condition)){
			return $this->dbpdo->query("webconfig",'*',$condition);
		}else{
			return $this->dbpdo->query("webconfig",'*','');
		}		
	}

	public function getWebConfig($condition=array()){
		if(is_array($condition)&&!empty($condition)){
			$rs=$this->dbpdo->query("webconfig",'*',$condition);
		}else{
			$rs=$this->dbpdo->query("webconfig",'*');
		}		
		foreach($rs as $k=>$v){
			$rslist[$v['appname']][$v['varname']]=$v['value'];
		}
		return $rslist;
	}

	public function getOne($condition=array()){
		return $this->dbpdo->getOne("webconfig",'*',$condition);
	}

	public function update($dsw=array(),$condition=array()){
		return $this->dbpdo->update_data("webconfig",$dsw,$condition);
	}
	
	public function updateLang($dsw=array(),$condition=array()){
		return $this->dbpdo->update_data("web_lang",$dsw,$condition);
	}
}
?>
