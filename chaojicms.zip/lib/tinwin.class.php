<?php
/* 
 * 特殊类 
 * 创建于 2015-03-22
 * getClientIp 获取客户端IP
 * GetWebContent 获取网页内容
 * SetPsd 设置密码
 * setArrFile 设置数组文件
 * TinwinPath 可点击路径	
 * readArrFile 读取数组文件
 * getWebSkin 下载网络皮肤文件
 * unzip_file 解压zip文件
 * make_semiangle 将全角转为半角
 */
class tinwin
{
	public $G;
	public function __construct(&$G){
		$this->G = $G;
	}

	public function _init(){
        $this->files = $this->G->loadclass('files');
	}

	//获取客户端IP 2015-03-22
	public function getClientIp(){
		if(!isset($this->e['ip'])){
			if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
				$ip = getenv("HTTP_CLIENT_IP");
			else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
				$ip = getenv("HTTP_X_FORWARDED_FOR");
			else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
				$ip = getenv("REMOTE_ADDR");
			else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
				$ip = $_SERVER['REMOTE_ADDR'];
			else
				$ip = "unknown";
			$this->e['ip'] = $ip;
		}
		return $this->e['ip'];
	}

	//获取网页内容 2015-10-21
	public function GetWebContent($url,$coding=3){
        @$ch=curl_init();
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_HEADER,0);
        curl_setopt($ch,CURLOPT_NOBODY,false); 
        curl_setopt($ch,CURLOPT_TIMEOUT,3);
        curl_setopt($ch,CURLOPT_FOLLOWLOCATION,true);
        curl_setopt($ch,CURLOPT_MAXREDIRS,20);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch,CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.0)");
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);//不验证证书文件
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
        $orders=@curl_exec($ch);
        @curl_close($ch);
        $str=$orders;
        if($coding=="1"){
                $str=iconv("UTF-8", "GB2312//IGNORE", $str);
        }elseif ($coding=="2"){//将GBK转为utf-8
                $str=iconv("GBK", "UTF-8//IGNORE", $str);
        }else{
        }
        return $str;
    }
	
	//设置加密方式 2018-04-29
	public function SetPsd($psd){
		return sha1($psd);
	}
    
    //可以点击的路径 2018-06-19
	public function TinwinPath($mypath='/'){
        $arr=explode("/", $mypath);
		foreach($arr as $k=>$v){
            if($v){
                $spath=$spath.'/'.$v; 
                $rs=$rs.'<li><a href="'.ADMIN_URL.'file-getDir&mypath='.$spath.'">/ '.$v.'</a></li>';
            }
        }
        $rs='<li>当前位置：</li><li><a href="'.ADMIN_URL.'file-getDir&mypath=/">/根目录</a></li>'.$rs;
        return $rs;
	}

	/*	
		设置数组php文件 20180717 牛哥
		setArrFile(数组，要改变的文件)
	*/
	public function setArrFile($dsw,$arrfile){
		if(!is_writable($arrfile)) die('Please chmod '.$arrfile.' to 0777 !');
		$pattern = $replacement = array();
		foreach($dsw as $k=>$v) {
			$v = trim($v);
			$configs[$k] = $v;
			$pattern[$k] = "/'".$k."'\s*=>\s*([']?)[^']*([']?)(\s*),/is";
			$replacement[$k] = "'".$k."' => \${1}".$v."\${2}\${3},";					
		}
		$str = file_get_contents($arrfile);
		$str = preg_replace($pattern, $replacement, $str);
		return file_put_contents($arrfile, $str, LOCK_EX);		
	}

	/*
		读取数组php文件 20180717 牛哥
		readArrFile(文件地址);
	*/
	public function readArrFile($arrfile){
		$arr=array();
		if(is_file($arrfile)){
			$arr=include $arrfile;
		}
		unset($arrfile);
		return $arr;
	}

	/*
		通过网络下载一个文件 20180724 牛哥
		getWebSkin(网络地址,本网站模板目录)
	*/
	public function getWebSkin($url,$updir){
		if(!file_exists($updir))$this->files->mdir($updir);
		$path = $updir.'/'.md5(rand(10,1000)).'.zip';
		if(file_exists($path))unlink($path);
		$this->files->writeFile($path,$this->files->readFile($url));
		if (file_exists($path)){
			$oldumask = umask(0) ;
			chmod( $updir, 0777 ) ;
			umask( $oldumask ) ;
		}
		return $path;
	}

	/* 解压ZIP文件 20180724 牛哥
		upzip_file(要解压的文件，解压到的目录)
	*/
	public function unzip_file($file,$sdir){
		$zip = new ZipArchive() ;
		if ($zip->open($file) !== TRUE) {
			return false;
		}
		$zip->extractTo($sdir);
		$zip->close();
		return true;
	}

	/**
	 *  将一个字串中含有全角的数字字符、字母、空格或'%+-()'字符转换为相应半角字符
	 * @access  public
	 * @param   string       $str         待转换字串
	 * @return  string       $str         处理后字串
	 */
	public function QuanjiaoToBanjiao($str){
	    $arr = array('０' => '0', '１' => '1', '２' => '2', '３' => '3', '４' => '4',
	                 '５' => '5', '６' => '6', '７' => '7', '８' => '8', '９' => '9',
	                 'Ａ' => 'A', 'Ｂ' => 'B', 'Ｃ' => 'C', 'Ｄ' => 'D', 'Ｅ' => 'E',
	                 'Ｆ' => 'F', 'Ｇ' => 'G', 'Ｈ' => 'H', 'Ｉ' => 'I', 'Ｊ' => 'J',
	                 'Ｋ' => 'K', 'Ｌ' => 'L', 'Ｍ' => 'M', 'Ｎ' => 'N', 'Ｏ' => 'O',
	                 'Ｐ' => 'P', 'Ｑ' => 'Q', 'Ｒ' => 'R', 'Ｓ' => 'S', 'Ｔ' => 'T',
	                 'Ｕ' => 'U', 'Ｖ' => 'V', 'Ｗ' => 'W', 'Ｘ' => 'X', 'Ｙ' => 'Y',
	                 'Ｚ' => 'Z', 'ａ' => 'a', 'ｂ' => 'b', 'ｃ' => 'c', 'ｄ' => 'd',
	                 'ｅ' => 'e', 'ｆ' => 'f', 'ｇ' => 'g', 'ｈ' => 'h', 'ｉ' => 'i',
	                 'ｊ' => 'j', 'ｋ' => 'k', 'ｌ' => 'l', 'ｍ' => 'm', 'ｎ' => 'n',
	                 'ｏ' => 'o', 'ｐ' => 'p', 'ｑ' => 'q', 'ｒ' => 'r', 'ｓ' => 's',
	                 'ｔ' => 't', 'ｕ' => 'u', 'ｖ' => 'v', 'ｗ' => 'w', 'ｘ' => 'x',
	                 'ｙ' => 'y', 'ｚ' => 'z',
	                 '（' => '(', '）' => ')', '〔' => '[', '〕' => ']', '【' => '[',
	                 '】' => ']', '〖' => '[', '〗' => ']', '“' => '[', '”' => ']',
	                 '‘' => '[', '’' => ']', '｛' => '{', '｝' => '}', '《' => '<',
	                 '》' => '>',
	                 '％' => '%', '＋' => '+', '—' => '-', '－' => '-', '～' => '-',
	                 '：' => ':', '。' => '.', '、' => ',', '，' => '.', '、' => '.',
	                 '；' => ',', '？' => '?', '！' => '!', '…' => '-', '‖' => '|',
	                 '”' => '"', '’' => '`', '‘' => '`', '｜' => '|', '〃' => '"',
	                 '　' => ' ');
	    return strtr($str, $arr);
	}

    public function GetWeek($date){
        //强制转换日期格式
        $date_str=date('Y-m-d',strtotime($date));
        //封装成数组
        $arr=explode("-", $date_str);
        //参数赋值
        //年
        $year=$arr[0];
        //月，输出2位整型，不够2位右对齐
        $month=sprintf('%02d',$arr[1]);
        //日，输出2位整型，不够2位右对齐
        $day=sprintf('%02d',$arr[2]);
        //时分秒默认赋值为0；
        $hour = $minute = $second = 0;   
        //转换成时间戳
        $strap = mktime($hour,$minute,$second,$month,$day,$year);
        //获取数字型星期几
        $number_wk=date("w",$strap);
        //自定义星期数组
        $weekArr=array("星期日","星期一","星期二","星期三","星期四","星期五","星期六");
        //获取数字对应的星期
        return $weekArr[$number_wk];
    }
}
?>
