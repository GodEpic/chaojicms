<?php
/*
 * 菜单导航类 
 * 2018-02-25
 * */
class navmenu{
	public $G;
	public function __construct(&$G){
		$this->G = $G;
	}

	public function _init(){
		$this->dbpdo=$this->G->loadclass('dbpdo');
		$this->routes = $this->G->loadclass('routes');
	}

	//获取所有菜单
	public function getAll($condition=''){
		return $this->dbpdo->query("navmenu",'*',$condition);
	}

	//获取所有菜单
	public function setAllByType($MenuType){
		return $this->dbpdo->query("navmenu",'*',array('menu_type'=>$MenuType),"","inrow");
	}

	//获取所有菜单
	public function getAllByType($MenuType){
			return $this->dbpdo->query("navmenu",'*',array('menu_type'=>$MenuType,'isview'=>'1'),"","inrow");
		
	}

	//根据分类ID获取所有菜单
	public function getAllbyCid($IntCid){
		return $this->dbpdo->query("navmenu",'*',array('parent_id'=>$IntCid),"","inrow");
	}

	//根据分类ID获取所有菜单
	public function getParentByCid($IntCid){
		return $this->dbpdo->getOne("navmenu",'*',array('id'=>$IntCid));
	}

    //根据条件获取一条记录
	public function getOne($condition=array()){
		return $this->dbpdo->getOne("navmenu",'*',$condition);
	}
    
	//根据分类ID获取一条记录
	public function getOneByID($IntID){
		return $this->dbpdo->getOne("navmenu",'*',array('id'=>$IntID));
	}

	//新增菜单保存
	public function save($dsw){
		return $this->dbpdo->insert_data("navmenu",$dsw);
	}

	//新增菜单保存
	public function update($dsw=array(),$condition=array()){
		return $this->dbpdo->update_data("navmenu",$dsw,$condition);
	}

	//菜单删除
	public function delByID($IntID){
		return $this->dbpdo->remove("navmenu",array("id"=>$IntID));
	}

    //菜单删除
	public function del($condition=array()){
		return $this->dbpdo->remove("navmenu",$condition);
	}
    
	//是否显示
	public function isview($IntID){
		$Strok="";
		$list=$this->dbpdo->getOne("navmenu","*",array('id' => $IntID));
		if($list['isview']==0){
			$row=array(
				'endtime'=>time(),
				'enduser'=>$_SESSION['tinwinsession']['uid'],
				'isview'=>1
			);
			$Strok='<span class="glyphicon glyphicon-eye-open"></span>';
		}else{
			$row=array(
				'endtime'=>time(),
				'enduser'=>$_SESSION['tinwinsession']['uid'],
				'isview'=>0
			);
			$Strok='<span class="glyphicon glyphicon-eye-close"></span>';
		}
		$this->dbpdo->update_data('navmenu',$row,array('id' => $IntID));
		return $Strok;
	}

	//是否主导航
	public function ismain($IntID){
		$Strok="";
		$list=$this->dbpdo->getOne("navmenu","*",array('id' => $IntID));
		if($list['ismain']==0){
			$row=array(
				'endtime'=>time(),
				'enduser'=>$_SESSION['tinwinsession']['uid'],
				'ismain'=>1
			);
			$Strok='<span class="glyphicon glyphicon-star"></span>';
		}else{
			$row=array(
				'endtime'=>time(),
				'enduser'=>$_SESSION['tinwinsession']['uid'],
				'ismain'=>0
			);
			$Strok='<span class="glyphicon glyphicon-star-empty"></span>';
		}
		$this->dbpdo->update_data("navmenu",$row,array('id' => $IntID));
		return $Strok;
	}

	//是否外链或单独菜单
	public function isoutlink($IntID){
		$Strok="";
		$list=$this->dbpdo->getOne("navmenu","*",array('id' => $IntID));
		if($list['isoutlink']==0){
			$row=array(
				'endtime'=>time(),
				'enduser'=>$_SESSION['tinwinsession']['uid'],
				'isoutlink'=>1
			);
			$Strok='<span class="glyphicon glyphicon-star"></span>';
		}else{
			$row=array(
				'endtime'=>time(),
				'enduser'=>$_SESSION['tinwinsession']['uid'],
				'isoutlink'=>0
			);
			$Strok='<span class="glyphicon glyphicon-star-empty"></span>';
		}
		$this->dbpdo->update_data("navmenu",$row,array('id' => $IntID));
		return $Strok;
	}

	public function getTree($condition='', $pid =0, $level = 0){
		$data=$this->getAll($condition);
		if(empty($data)){
			return false;
		}
		//声明静态数组,避免递归调用时,多次声明导致数组覆盖 
		static $list = [];
		foreach ($data as $key => $value){
			//第一次遍历,找到父节点为根节点的节点 也就是pid=0的节点 
			if ($value['parent_id'] == $pid){
				//父节点为根节点的节点,级别为0，也就是第一级 
				$value['level'] = $level;
				//把数组放到list中
				$value['menu_label']=str_repeat('--',$value['level']).$value['menu_label'];
				$list[] = $value;
				//把这个节点从数组中移除,减少后续递归消耗 
				unset($data[$key]);
				//开始递归,查找父ID为该节点ID的节点,级别则为原级别+1 
				$this->getTree($condition='', $value['id'], $level+1);
			}
		}
		return $list;
	}

/**
 * 菜单分组
 */
    //获取所有菜单
	public function getAllGroup($condition=array()){
		return $this->dbpdo->query("navmenu_group",'*',$condition,"","inrow");
	}
    
    //获取所有菜单
	public function getOneGroup($condition=array()){
		return $this->dbpdo->getOne("navmenu_group",'*',$condition);
	}
    
    //新增菜单分组保存
	public function savegroup($dsw){
		return $this->dbpdo->insert_data("navmenu_group",$dsw);
	}
    
    //更新菜单分组
	public function updategroup($dsw=array(),$condition=array()){
		return $this->dbpdo->update_data("navmenu_group",$dsw,$condition);
	}
    
    //分组删除
	public function delgroup($condition=array()){
		return $this->dbpdo->remove("navmenu_group",$condition);
	}
    
    //是否系统自带分组
	public function issys($IntID){
		$Strok="";
		$list=$this->dbpdo->getOne("navmenu_group","*",array('id' => $IntID));
		if($list['issys']==0){
			$row=array(
				'issys'=>1
			);
			$Strok='<span class="glyphicon glyphicon-ok-circle"></span>';
		}else{
			$row=array(
				'issys'=>0
			);
			$Strok='<span class="glyphicon glyphicon-remove-circle"></span>';
		}
		$this->dbpdo->update_data('navmenu_group',$row,array('id' => $IntID));
		return $Strok;
	}
}
?>
