<?php
/* 
 * 加载驱动类
 * */
class chaojicms{
	public $G = array();
	public $L = array();
	public $app;
	public $defaultApp = 'home';
	public function __construct()
	{
		//
	}
	//执行页面
	public function run(){
		@require_once DATA_PATH .'common.inc.php';
		$db['config']=@require_once DATA_PATH .'db_config.php';
        //$db['config']=$this->loadclass('tinwin')->readArrFile(DATA_PATH .'db_config.php');
		define('DB_HOST',$db['config']['db_host']);//数据库服务器地址 本地为：localhost
		define('DB_PORT',$db['config']['db_port']);//连接端口号 默认3306
		define('DB_USER',$db['config']['db_user']);//用户名
		define('DB_PWD',$db['config']['db_pwd']);//密码
		define('DB_NAME',$db['config']['db_name']);//数据库名称
		define('DB_CHARSET',$db['config']['db_charset']);//数据库编码格式
		define('DB_PREFIX',$db['config']['db_prefix']);//数据表前缀 提取方式$web_table=DB_PREFIX.'web';
		define('DB_TYPE',$db['config']['db_type']);//数据库类型
		header('P3P: CP=CAO PSA OUR');
		header('Content-Type: text/html; charset='.WEB_CHARSET);
		$routes = $this->loadclass('routes');
		$app = $routes->url(0);
		$this->app = $app;
		$this->module = $module = $routes->url(1);
		$this->method = $method = $routes->url(2);
		if($routes->isMobile())$module = $this->module = 'phone';
		if(!$app){
			$this->app = $app = $this->defaultApp;
		}
		if(!$module)$this->module = $module = 'web';
		if(!$method)$this->method = $method = 'index';
        if(file_exists(APP_PATH.$app.'/'.$module.'.php')){
            include APP_PATH.$app.'/'.$module.'.php';
        }
        // $web_lang=$this->loadclass('webconfig')->getOne(array('varname'=>'web_lang'));
        // if(file_exists(APP_PATH.$app.'/lang/'.$web_lang['value'].'/'.$method.'.lang.php')){
        //     include APP_PATH.$app.'/lang/'.$web_lang['value'].'/'.$method.'.lang.php';
        // }
		$modulefile = APP_PATH.$app.'/controller/'.$method.'.'.$module.'.php';
		
		if(file_exists($modulefile)){
			include $modulefile;
			$tpl = $this->loadclass('tpl');
			$tpl->assign('_app',$app);
			$tpl->assign('method',$method);
			$run = new action($this);
			$run->display();	
		}else{
			//die('找不到路径，请稍后重试'.$app);
			//header('Location:/404.html');
			$message = array(
				'WaitTime'=>3,
				'CodeType' =>300,
				"message" => '请勿乱策',
				"callbackType" => 'forward',
				"forwardUrl" => SITE_WEB
			);
			$this->R($message);	
		}
	}
	//加载核心类文件
	public function loadclass($G,$app = NULL){
		if($app)return $this->load($G,$app);
		else{
			if(!isset($this->G[$G])){
				if(file_exists('lib/'.$G.'.class.php')){
					include 'lib/'.$G.'.class.php';
				}
				else return false;
				$this->G[$G] = new $G($this);
				if(method_exists($this->G[$G],'_init'))$this->G[$G]->_init();
			}
			return $this->G[$G];
		}
	}
	
	//加载对象类文件并生成对象
	public function load($G,$app){
		if(!$app)return false;
		$o = $G.'_'.$app;
		if(!isset($this->L[$app][$o])){
			$fl = APP_PATH.$app.'/model/'.$G.'.class.php';
			if(file_exists($fl)){
				include $fl;
			}
			else return false;
			//die('加载出错，不能识别类文件'.$app.'::'.$G);
			$this->L[$app][$o] = new $o($this);
			if(method_exists($this->L[$app][$o],'_init'))$this->L[$app][$o]->_init();
		}
		return $this->L[$app][$o];
	}
	
	//加载语言文件
	public function loadLang(){
		$routes = $this->loadclass('routes');
		$web_lang=$this->loadclass('webconfig')->getOne(array('varname'=>'web_lang'));
		if(file_exists(APP_PATH.$routes->url(0).'/lang/'.$web_lang['value'].'/'.$routes->url(2).'.lang.php')){
	       return array_merge(@include APP_PATH.$routes->url(0).'/lang/'.$web_lang['value'].'/'.$routes->url(2).'.lang.php',@include APP_PATH.$routes->url(0).'/lang/'.$web_lang['value'].'/'.'config.php');
	    }
		// if(file_exists(APP_PATH.$routes->url(0).'/lang/'.$web_lang['value'].'.lang.php')){
	 //        return include APP_PATH.$routes->url(0).'/lang/'.$web_lang['value'].'.lang.php';
	 //    }
	}

	//对话框 2018-04-22 升级
	public function R($message){
		if(isset($message['WaitTime'])){
			$stop=false;
		}else{
			$message['WaitTime']=3;
			$stop=false;
		}
        if(isset($message['forwardUrl'])&&$message['forwardUrl']!='goback'){
        	$stop=false;
        }elseif($message['forwardUrl']=='goback'){
            $stop=true;
        } 
		include(APP_PATH.DIRECTORY_SEPARATOR.'message.php');
        exit;
	}
}
?>