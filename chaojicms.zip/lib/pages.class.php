<?php
/*
 * 分页类
 * 创建2012-07-05
 * 完善2017-09-14
 * */
class pages{
	public $G;
	public $datanum; //查询所有的数据总记录数 
	public $page_size; //每页显示记录的条数 
	public $currentpage;//当前页码
	public $extname;//扩展名
	public $prelabel = '<li>';//列表开始标签
	public $endlabel = '</li>';//列表结束标签
	public function __construct(&$G){
    	$this->G = $G;
    	$this->routes = $this->G->loadclass('routes');
	}
	
	//总页数 
	public function page_num() { 
		if($this->datanum == 0){
			return 1;
		}else{
			return ceil($this->datanum/$this->page_size);
		}
	} 

	//数据库查询的偏移量 
	public function start() { 
		return ($this->currentpage-1)*$this->page_size; 
	} 

	//数据输出 
	public function sqlquery() { 
		return $this->sql." limit ".$this->start().",".$this->page_size;
	} 
	
	//首页
	private function page_home($pagelabel,$extname){
		if($this->currentpage>1) { //页数不等于1
			return $this->prelabel."<a href=".$pagelabel."1".$extname.">首页</a>".$this->endlabel;
		}
	}

	//上一页
	private function pre_page($pagelabel,$extname){
		if($this->currentpage!=1&&$this->currentpage>0) { //页数不等于1,大于0是为了防止在页码为1时出现
			return $this->prelabel."<a  href=".$pagelabel.($this->currentpage-1).$extname.">上一页</a>".$this->endlabel;
		}
	}

	//显示分页
	private function display_page($pagelabel,$extname) {
		$display_page = "";
		$custyle="";
		if($this->page_num() <= 10){ //小于10页
			for ($i=1;$i<=$this->page_num();$i++)  //循环显示出页面
				{$custyle=$this->currentpage==$i?'class="select"':'';
				$display_page .= $this->prelabel."<a  $custyle href=".$pagelabel.$i.$extname.">".$i."</a></li> ";}
				return $display_page;
		}elseif($this->page_num() > 10){ //大于10页
			if($this->currentpage <= 6){
				for ($i=1;$i<=10;$i++)  //循环显示出页面
					{$custyle=$this->currentpage==$i?'class="select"':'';
				$display_page .= $this->prelabel."<a  $custyle href=".$pagelabel.$i.$extname.">".$i."</a></li> ";}
					return $display_page;
			}elseif(($this->currentpage > 6) && ($this->page_num()-$this->currentpage >= 4)){
				for ($i=$this->currentpage-5;$i<=$this->currentpage+4;$i++)  //循环显示出页面
					{$custyle=$this->currentpage==$i?'class="select"':'';
				$display_page .= $this->prelabel."<a  $custyle href=".$pagelabel.$i.$extname.">".$i."</a></li> ";}
					return $display_page;
			}elseif(($this->currentpage > 6) && ($this->page_num()-$this->currentpage < 4)){
				for ($i=$this->page_num()-9;$i<=$this->page_num();$i++)  //循环显示出页面
					{$custyle=$this->currentpage==$i?'class="select"':'';
				$display_page .= $this->prelabel."<a  $custyle href=".$pagelabel.$i.$extname.">".$i."</a></li> ";}
					return $display_page;
			}	
		}
	}

	//下一页
	private function next_page($pagelabel,$extname) {
		if ($this->currentpage < $this->page_num()) { //页数小于总页数
			return $this->prelabel."<a  href=".$pagelabel.($this->currentpage+1).$extname.">下一页</a>".$this->endlabel;
		}
	}
	
	//末页
	private function page_end($pagelabel,$extname) {
		if ($this->currentpage < $this->page_num()) { //页数小于总页数
			return $this->prelabel."<a  href=".$pagelabel.$this->page_num().$extname.">末页</a>".$this->endlabel;
		}
	}

	// 设置分页信息
	public function set_page_info($count,$page_size,$pagelabel=false,$extname=".html"){
		
		if($count>$page_size){//只有一页时,不显示页码
			$this->datanum=$count;
			$this->page_size=$page_size;
			$this->currentpage=$this->routes->get('page');
			if(!$pagelabel||$pagelabel==""){
				$extname="";
				$pagelabel = '/index.php?'.$_SERVER['QUERY_STRING'];
				$pagelabel = str_replace('&page='.$this->routes->get('page'),'',$pagelabel).'&page='.$currentpage;
			}
			//$page_info = "共".$this->datanum."条 ";
			//$page_info .= $this->prelabel."<a  href=".$pagelabel."1".$extname.">首页</a>".$this->endlabel;
			$page_info .= $this->page_home($pagelabel,$extname);
			$page_info .= $this->pre_page($pagelabel,$extname);
			$page_info .= $this->display_page($pagelabel,$extname);
			$page_info .= $this->next_page($pagelabel,$extname);
			$page_info .= $this->page_end($pagelabel,$extname);
			//$page_info .= $this->prelabel."<a  href=".$pagelabel.$this->page_num().$extname.">尾页</a>".$this->endlabel;
			//$page_info .= "第".$this->currentpage."/".$this->page_num()."页";
			return $page_info;
		}
	}
}
?>