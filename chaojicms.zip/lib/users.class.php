<?php
/*
 * 用户管理类
 * 创建于2012-06-15
 * 完善2017*/
class users{
	public $G;
	public function __construct(&$G){
		$this->G = $G;
	}

	public function _init(){
		$this->dbpdo=$this->G->loadclass('dbpdo');
		$this->routes = $this->G->loadclass('routes');
		$this->tpl = $this->G->loadclass('tpl');
		$this->strings = $this->G->loadclass('strings');
		$this->pages = $this->G->loadclass('pages');
	}

	public function getAll($condition=array()){
		return $this->dbpdo->query('user','*',$condition);
	}

	//获取所有用户分页形式
	public function getList($Spage=1,$Snumber=PAGED,$condition="",$UrlStyle=""){
		$rs['data']=$this->dbpdo->query("user",'*',$condition,"","","",strval(intval($Spage-1)*$Snumber),$Snumber);
		$t=$this->dbpdo->getOne("user",'count(*) AS total',$condition);
		$Intpages = $this->pages->set_page_info($t['total'],$Snumber,$UrlStyle);
		if($rs){
			$rs['pages']=$Intpages;
			$rs['total'] = $t['total'];
			return $rs;
		}
	}
	
	/*
	 * 根据条件获取用户信息 2018-04-30
	 * 模板获取数据方法｛Tinwin $user['uid']['nickname']｝
	 */
	public function getAllWithUid($condition=array()){
		$rs=$this->dbpdo->query('user','*',$condition);
		foreach($rs as $k=>$v){
			$ulist[$v['id']]=$rs[$k];
		}
		return $ulist;
	}

	//用户登录
	public function getLogin($dsw){
		return $this->dbpdo->getOne('user','*',$dsw);
	}

    //通过用户名获取ID
	public function getUidByNick($nickname){
		return $this->dbpdo->getOne('user','id',array('nickname'=>$nickname));
	}
    
	public function getOneByID($IntID){
		return $this->dbpdo->getOne('user','*',array('id'=>$IntID));
	}
	
	public function Register($dsw){
		$dsw['addtime']=time();
		$dsw['endtime']=time();
		$rs=$this->dbpdo->insert_data('user',$dsw);
		return $this->dbpdo->getInsertId();
	}

	public function getOne($condition=array(),$sfield="*"){
		return $this->dbpdo->getOne('user',$sfield,$condition);
	}

    //更新用户
	public function update($dsw,$condition=array()){
		return $this->dbpdo->update_data('user',$dsw,$condition);
	}

    //新增用户
	public function save($args){
		$this->dbpdo->insert_data("user",$args);
		return $this->dbpdo->getInsertId();
	}
    
	public function del($IntID){
		return $this->dbpdo->remove("user",array("id"=>$IntID));
	}
}
?>
